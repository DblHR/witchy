extends Control
class_name TutorialBridge

@onready var dialogue_overlay: DialogueOverlay = %DialogueOverlay
@onready var fallback_label: Label = %FallbackLabel

const FALLBACK_TEXTURE := preload("res://icon.svg")

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	mouse_filter = Control.MOUSE_FILTER_STOP
	if dialogue_overlay == null:
		_show_fallback_and_continue()
		return
	dialogue_overlay.process_mode = Node.PROCESS_MODE_ALWAYS
	dialogue_overlay.visible = true
	dialogue_overlay.show_sequence(_build_intro_lines(), Callable(self, "_go_to_battle"))

func _build_intro_lines() -> Array:
	var witch_portrait: Texture2D = _safe_load_texture("res://assets/pics/cards/witch_card.png")
	var slime_portrait: Texture2D = _safe_load_texture("res://assets/pics/actorSprite/slime.png")
	return [
		{
			"speaker_name": "Ведьмочка",
			"text": "О-о-о! Слизень!",
			"left_portrait": witch_portrait,
			"right_portrait": slime_portrait,
			"active_slot": "left",
		},
		{
			"speaker_name": "Ведьмочка",
			"text": "Так, надо достать блокнот и всё подробно записать! Мистер слизень, а вы мистер или мисс слизень?",
			"left_portrait": witch_portrait,
			"right_portrait": slime_portrait,
			"active_slot": "left",
		},
		{
			"speaker_name": "Слизень",
			"text": "*бульк*",
			"left_portrait": witch_portrait,
			"right_portrait": slime_portrait,
			"active_slot": "right",
		},
	]

func _safe_load_texture(path: String) -> Texture2D:
	if ResourceLoader.exists(path):
		var tex := load(path) as Texture2D
		if tex != null:
			return tex
	return FALLBACK_TEXTURE

func _show_fallback_and_continue() -> void:
	if fallback_label != null:
		fallback_label.visible = true
		fallback_label.text = "Не удалось создать окно визуальной новеллы. Переход в бой..."
	await get_tree().create_timer(0.6).timeout
	_go_to_battle()

func _go_to_battle() -> void:
	if StoryState_ != null:
		StoryState_.intro_played = true
		StoryState_.tutorial_battle_pending = true
		StoryState_.changed.emit()
	SceneRouter_.go_to_tutorial_battle()
