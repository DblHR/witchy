extends Control
class_name TutorialHintPopup

signal dismissed

@onready var body_label: Label = %BodyLabel
@onready var hint_label: Label = %HintLabel

func _ready() -> void:
	visible = false
	process_mode = Node.PROCESS_MODE_ALWAYS
	mouse_filter = Control.MOUSE_FILTER_STOP
	body_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART

func show_message(message: String, footer: String = "Нажмите в любом месте") -> void:
	body_label.text = message
	hint_label.text = footer
	visible = true

func hide_message() -> void:
	visible = false

func _input(event: InputEvent) -> void:
	if not visible or get_tree().paused:
		return
	if event is InputEventMouseButton and event.pressed and event.button_index == MOUSE_BUTTON_LEFT:
		hide_message()
		dismissed.emit()
		get_viewport().set_input_as_handled()
	elif event is InputEventScreenTouch and event.pressed:
		hide_message()
		dismissed.emit()
		get_viewport().set_input_as_handled()
