extends "res://scripts/BattleSim.gd"

@onready var tutorial_popup: TutorialHintPopup = %TutorialHintPopup
@onready var dialogue_overlay: DialogueOverlay = %TutorialDialogueOverlay
@onready var bottom_panel: Control = $"UI/BottomPanel"

const FALLBACK_TEXTURE := preload("res://icon.svg")

var _tutorial_paused: bool = true
var _witch_autoattack_count: int = 0
var _queued_tutorial_hints: Array[String] = []
var _advanced_hints_shown: bool = false
var _intro_dialogue_completed: bool = false

func _ready() -> void:
	super._ready()
	%RoomLabel.text = "Обучающий бой"
	result_label.text = ""
	end_overlay.visible = false
	if estus_button != null:
		estus_button.disabled = true
	if potion_button != null:
		potion_button.disabled = true
	if treat_button != null:
		treat_button.disabled = true
	if tutorial_popup != null and not tutorial_popup.dismissed.is_connected(_on_tutorial_popup_dismissed):
		tutorial_popup.dismissed.connect(_on_tutorial_popup_dismissed)
	_pause_battle()
	hint_label.text = ""
	call_deferred("_start_intro_dialogue")


func spawn_left_team() -> void:
	left_team.clear()
	party_units_in_order.clear()
	var witch := _make_unit("witch", 1)
	if witch != null:
		left_team.append(witch)
		party_units_in_order.append(witch)

func spawn_right_team() -> void:
	right_team.clear()
	var slime := _make_unit("base_slime", 1)
	if slime == null:
		return
	slime.make_enemy(0, 0)
	slime.max_hp = 240
	slime.hp = slime.max_hp
	slime.damage = 28
	slime.aps = 0.55
	slime.max_energy = 0
	slime.energy = 0
	right_team.append(slime)

func _process(dt: float) -> void:
	if _tutorial_paused:
		return
	super._process(dt)

func _unhandled_input(event: InputEvent) -> void:
	if _tutorial_paused:
		return
	super._unhandled_input(event)

func _do_attack(attacker: Unit, attacker_is_left: bool) -> void:
	var should_count := false
	var target_before := get_front_alive(right_team)
	var hp_before := target_before.hp if target_before != null else -1
	if not _tutorial_paused and attacker_is_left and attacker != null and not attacker.is_dead and attacker.data != null and String(attacker.data.id) == "witch" and target_before != null:
		should_count = true
	super._do_attack(attacker, attacker_is_left)
	if should_count and target_before != null and target_before.hp < hp_before:
		_witch_autoattack_count += 1
		if _witch_autoattack_count >= 3 and not _advanced_hints_shown and not ended:
			_advanced_hints_shown = true
			if left_team.size() > 0 and left_team[0] != null:
				left_team[0].energy = left_team[0].max_energy
				_update_player_cards()
				_update_meta_ui()
			_pause_battle()
			_queue_hints([
				"Когда у вас достаточно энергии, вы можете использовать умение или ультимейт. Для ультимейта понадобится ВСЯ энергия персонажа.",
				"Для активации умения нажмите кнопку A, S, D или F в зависимости от позиции персонажа — или на иконку умения снизу.",
				"Для активации ультимейта нажмите кнопку Z, X, C или V в зависимости от позиции персонажа — или на карточку персонажа снизу."
			])
			_show_next_hint()

func _end(left_won: bool) -> void:
	super._end(left_won)
	if StoryState_ != null:
		StoryState_.tutorial_battle_pending = false
		StoryState_.tutorial_battle_completed = not left_won
		StoryState_.changed.emit()

func _on_end_button_pressed() -> void:
	if not ended:
		return
	if StoryState_ != null:
		StoryState_.tutorial_battle_pending = false
		StoryState_.tutorial_battle_completed = true
		StoryState_.changed.emit()
	SceneRouter_.go_to_hub()

func _start_intro_dialogue() -> void:
	if _intro_dialogue_completed:
		return
	if dialogue_overlay == null:
		_on_intro_dialogue_finished()
		return
	_set_overlay_ui_active(true)
	dialogue_overlay.process_mode = Node.PROCESS_MODE_ALWAYS
	dialogue_overlay.visible = true
	dialogue_overlay.show_sequence(_build_intro_lines(), Callable(self, "_on_intro_dialogue_finished"))

func _build_intro_lines() -> Array:
	var witch_portrait: Texture2D = _safe_load_texture("res://assets/pics/cards/witch_card.png")
	var slime_portrait: Texture2D = _safe_load_texture("res://assets/pics/actorSprite/slime.png")
	return [
		{
			"speaker_name": "Ведьмочка",
			"text": "О-о-о! Слизень!",
			"left_portrait": witch_portrait,
			"right_portrait": slime_portrait,
			"active_slot": "left",
		},
		{
			"speaker_name": "Ведьмочка",
			"text": "Так, надо достать блокнот и всё подробно записать! Мистер слизень, а вы мистер или мисс слизень?",
			"left_portrait": witch_portrait,
			"right_portrait": slime_portrait,
			"active_slot": "left",
		},
		{
			"speaker_name": "Слизень",
			"text": "*бульк*",
			"left_portrait": witch_portrait,
			"right_portrait": slime_portrait,
			"active_slot": "right",
		},
	]

func _safe_load_texture(path: String) -> Texture2D:
	if ResourceLoader.exists(path):
		var tex := load(path) as Texture2D
		if tex != null:
			return tex
	return FALLBACK_TEXTURE

func _on_intro_dialogue_finished() -> void:
	if _intro_dialogue_completed:
		return
	_intro_dialogue_completed = true
	_queue_hints(["Персонажи на поле боя атакуют самостоятельно."])
	_show_next_hint()


func _queue_hints(messages: Array[String]) -> void:
	for message in messages:
		_queued_tutorial_hints.append(message)

func _show_next_hint() -> void:
	if tutorial_popup == null:
		_resume_battle()
		return
	if _queued_tutorial_hints.is_empty():
		_resume_battle()
		return
	_set_overlay_ui_active(true)
	tutorial_popup.show_message(_queued_tutorial_hints.pop_front())

func _on_tutorial_popup_dismissed() -> void:
	_show_next_hint()

func _pause_battle() -> void:
	_tutorial_paused = true

func _resume_battle() -> void:
	_tutorial_paused = false
	_set_overlay_ui_active(false)
	hint_label.text = ""

func _set_overlay_ui_active(active: bool) -> void:
	if bottom_panel != null:
		bottom_panel.visible = not active
