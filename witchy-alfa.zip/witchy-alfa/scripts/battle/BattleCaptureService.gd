extends RefCounted
class_name BattleCaptureService

const TREAT_CAPTURE_CHANCE := 0.20
const UNCATCHABLE_IDS := {
	"base_slime": true,
}

static func can_attempt_capture(unit: Unit, is_boss_room: bool) -> bool:
	if unit == null or unit.is_dead or unit.data == null:
		return false
	if is_boss_room:
		return false
	var unit_id := String(unit.data.id)
	return unit_id != "" and not UNCATCHABLE_IDS.has(unit_id)

static func attempt_capture(rng: RandomNumberGenerator, unit: Unit, is_boss_room: bool) -> Dictionary:
	var result := {
		"ok": false,
		"unit_id": "",
		"reason": "",
	}
	if unit == null or unit.data == null:
		result.reason = "Нет цели для лакомства."
		return result
	var unit_id := String(unit.data.id)
	result.unit_id = unit_id
	if is_boss_room:
		result.reason = "Босса лакомством поймать нельзя."
		return result
	if UNCATCHABLE_IDS.has(unit_id):
		result.reason = "Обычные слаймы на лакомство не ведутся."
		return result
	if rng == null:
		result.reason = "Нет генератора случайностей."
		return result
	if rng.randf() <= TREAT_CAPTURE_CHANCE:
		result.ok = true
		result.reason = "Существо заинтересовалось лакомством. Теперь его нужно победить."
	else:
		result.reason = "Лакомство не сработало."
	return result
