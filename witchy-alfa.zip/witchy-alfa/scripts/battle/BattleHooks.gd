extends RefCounted
class_name BattleHooks

static func on_battle_start(sim) -> void:
	DungRun.battles_started += 1
	for team in [sim.left_team, sim.right_team]:
		for u in team:
			if u != null:
				u.reset_for_battle()
	RunItemEffects.on_battle_start(sim)

static func modify_basic_attack_damage(attacker: Unit, target: Unit, base_damage: int, attacker_is_left: bool) -> int:
	var dmg := RunItemEffects.modify_basic_attack_damage(attacker, target, base_damage, attacker_is_left)
	if attacker != null and attacker.data != null and String(attacker.data.id) == "warrior":
		var stacks := _get_weakening_stacks(target)
		if stacks > 0:
			dmg = int(round(float(dmg) * (1.0 + float(stacks) * 0.10)))
	return dmg

static func after_basic_attack(attacker: Unit, target: Unit, attacker_is_left: bool) -> void:
	if attacker != null and attacker.data != null and String(attacker.data.id) == "warrior" and target != null and not target.is_dead:
		_apply_weakening_stack(target, 1)
	RunItemEffects.after_basic_attack(attacker, target, attacker_is_left)

static func _get_weakening_stacks(target: Unit) -> int:
	if target == null:
		return 0
	for eff in target.effects:
		if eff is WeakeningStacksEffect and not eff.is_finished():
			return max(0, (eff as WeakeningStacksEffect).stacks)
	return 0

static func _apply_weakening_stack(target: Unit, amount: int) -> void:
	if target == null or amount <= 0:
		return
	for eff in target.effects:
		if eff is WeakeningStacksEffect and not eff.is_finished():
			(eff as WeakeningStacksEffect).add_stacks(amount)
			return
	target.add_effect(WeakeningStacksEffect.new(amount))

static func on_ally_damaged(unit: Unit) -> void:
	RunItemEffects.on_ally_damaged(unit)

static func on_enemy_killed(enemy: Unit, room_index: int) -> void:
	RunItemEffects.on_enemy_killed(enemy, room_index)

static func on_room_cleared(team: Array[Unit]) -> void:
	RunItemEffects.on_room_cleared(team)
