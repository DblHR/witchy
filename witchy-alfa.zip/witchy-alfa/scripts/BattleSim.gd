extends Node2D


@export var debug_battle: bool = false
@export var player_card_scene: PackedScene

const BATTLE_ULT_OVERLAY_SCENE := preload("res://scenes/ui/BattleUltOverlay.tscn")
const WITCH_ABILITY_PROJECTILE_SCENE := preload("res://scenes/vfx/WitchAbilityProjectile.tscn")
const WARRIOR_ULT_SLASH_SCENE := preload("res://scenes/vfx/WarriorUltSlash.tscn")
const PLAYER_ULT_OVERLAY_IDS := {
	"warrior": true,
	"witch": true,
	"aki": true,
	"fufu": true,
	"luisa": true,
}

@onready var result_label: Label = %ResultLabel
@onready var hint_label: Label = %HintLabel
@onready var gold_label: Label = %GoldLabel
@onready var xp_label: Label = %XpLabel
@onready var end_overlay: Control = $EndLayer/EndOverlay
@onready var end_image: TextureRect = $EndLayer/EndOverlay/EndImage
@onready var end_text: Label = $EndLayer/EndOverlay/EndText
@onready var end_button: Button = $EndLayer/EndOverlay/EndButton
@onready var left_world: Node2D = $LeftSlotsWorld
@onready var right_world: Node2D = $RightSlotsWorld
@onready var cards_row: HBoxContainer = %CardsRow
@onready var card_slots: Array[Control] = [%CardSlot3, %CardSlot2, %CardSlot1, %CardSlot0]
@onready var estus_button: Button = %EstusButton
@onready var potion_button: Button = %PotionButton
@onready var treat_button: Button = %TreatButton
@onready var boss_slot: Node2D = $RightSlotsWorld/BossSlot

var _end_victory: bool = false
var _end_is_draw: bool = false
var battle_actor_scene := preload("res://scenes/BattleActor.tscn")
var player_cards: Array[PlayerCard] = []
var is_boss_room: bool = false
var left_actors: Array[BattleActor] = []
var right_actors: Array[BattleActor] = []
var left_world_slots: Array[Node2D] = []
var right_world_slots: Array[Node2D] = []
var left_team: Array[Unit] = []
var right_team: Array[Unit] = []
var party_units_in_order: Array[Unit] = []
var ended: bool = false
var _effect_ui_accum: float = 0.0
var _attack_safety_cap: int = 50
var _treat_used: bool = false
var _capture_marked_target: Unit = null
var _capture_pending_unit_id: String = ""
var _mana_clock_accum: float = 0.0
var _capture_minigame_scene := preload("res://scenes/minigames/CaptureMinigame.tscn")
var _capture_minigame: CaptureMinigame = null
var _ult_overlay: BattleUltOverlay = null
var _ult_overlay_pending_cast: Dictionary = {}

func _dbg(msg: String) -> void:
	if debug_battle:
		print("[BattleSim] ", msg)

func _is_boss_room(room: RoomParams) -> bool:
	return room != null and room.room_type == RoomParams.RoomType.BOSS

func _is_event_room(room: RoomParams) -> bool:
	return room != null and room.room_type == RoomParams.RoomType.EVENT

func _is_find_warrior_battle(room: RoomParams) -> bool:
	return room != null and room.quest_id == "find_warrior" and StoryState_ != null and StoryState_.has_flag("find_warrior_room_done") and not StoryState_.is_quest_completed("find_warrior")

func _ready() -> void:
	await get_tree().process_frame
	ended = false
	_treat_used = false
	_capture_marked_target = null
	_capture_pending_unit_id = ""
	_mana_clock_accum = 0.0
	result_label.text = ""

	var room := DungRun.get_current_room()
	if room != null:
		%RoomLabel.text = "Комната %d / %d" % [DungRun.room_index + 1, DungRun.rooms.size()]
	else:
		%RoomLabel.text = ""

	if _is_event_room(room):
		SceneRouter_.go_to_event_room()
		return

	end_overlay.visible = false
	end_button.pressed.connect(_on_end_button_pressed)
	estus_button.pressed.connect(_on_estus_pressed)
	potion_button.pressed.connect(_on_potion_pressed)
	treat_button.pressed.connect(_on_treat_pressed)

	is_boss_room = _is_boss_room(room)
	spawn_left_team()
	spawn_right_team()
	_build_bottom_cards()
	_cache_world_slots()
	_populate_world_slots()
	build_ui_and_timers()
	BattleBanter_.start_battle(self)
	BattleHooks.on_battle_start(self)
	_update_player_cards()
	_update_actors_visual()
	_update_meta_ui()
	BattleBanter_.trigger("battle_start")
	_ensure_ult_overlay()

func _build_bottom_cards() -> void:
	player_cards.clear()
	for slot in card_slots:
		for c in slot.get_children():
			c.queue_free()
		slot.visible = false

	for i in range(party_units_in_order.size()):
		var u: Unit = party_units_in_order[i]
		var slot := card_slots[i]
		slot.visible = true
		var card := player_card_scene.instantiate() as PlayerCard
		slot.add_child(card)
		card.bind(u)
		player_cards.append(card)
		card.ult_pressed.connect(func(c: PlayerCard):
			if ended:
				return
			var j := c.unit
			if j == null or j.is_dead:
				return
			if j.has_cast_block():
				hint_label.text = "Нельзя кастовать (эффект)"
				return
			var ability := j.data.ult_ability
			if ability == null:
				hint_label.text = "Ульта не задана"
				return
			_play_player_ult_overlay(j, ability)
		)
		card.skill_pressed.connect(func(c: PlayerCard):
			if ended:
				return
			var j := c.unit
			if j == null or j.is_dead:
				return
			if j.has_cast_block():
				hint_label.text = "Нельзя кастовать (эффект)"
				return
			var ability := j.data.skill_ability
			if ability == null:
				hint_label.text = "Умение не задано"
				return
			var cost := j.data.skill_cost
			if ability.cost > 0:
				cost = ability.cost
			if j.energy < cost:
				hint_label.text = "Не хватает энергии"
				return
			j.energy -= cost
			hint_label.text = "УМЕНИЕ: %s (-%d энергии)" % [j.data.skill_name, cost]
			_execute_ability(ability, j, true)
			_check_end()
			_update_player_cards()
			_update_actors_visual()
			_update_meta_ui()
		)

func _ensure_ult_overlay() -> void:
	if _ult_overlay != null and is_instance_valid(_ult_overlay):
		return
	if BATTLE_ULT_OVERLAY_SCENE == null:
		return
	_ult_overlay = BATTLE_ULT_OVERLAY_SCENE.instantiate() as BattleUltOverlay
	if _ult_overlay == null:
		return
	add_child(_ult_overlay)
	_ult_overlay.animation_finished.connect(_on_ult_overlay_animation_finished)

func _play_player_ult_overlay(caster: Unit, ability: Ability) -> void:
	if ended or caster == null or caster.is_dead or ability == null:
		return
	hint_label.text = "УЛЬТА: %s" % [caster.data.display_name]
	if not _should_play_player_ult_overlay(caster):
		_cast_ability(caster, ability, true, caster.max_energy)
		_check_end()
		return
	if _ult_overlay != null and is_instance_valid(_ult_overlay) and _ult_overlay.is_playing():
		hint_label.text = "Ульта уже проигрывается"
		return
	_ensure_ult_overlay()
	if _ult_overlay == null:
		_cast_ability(caster, ability, true, caster.max_energy)
		_check_end()
		return
	_ult_overlay_pending_cast = {
		"caster": caster,
		"ability": ability,
	}
	_ult_overlay.play_for_unit(caster)

func _should_play_player_ult_overlay(caster: Unit) -> bool:
	if caster == null or caster.data == null:
		return false
	return PLAYER_ULT_OVERLAY_IDS.has(String(caster.data.id))

func _on_ult_overlay_animation_finished(_unit: Unit) -> void:
	if _ult_overlay_pending_cast.is_empty():
		return
	var caster := _ult_overlay_pending_cast.get("caster") as Unit
	var ability := _ult_overlay_pending_cast.get("ability") as Ability
	_ult_overlay_pending_cast.clear()
	if ended or caster == null or caster.is_dead or ability == null:
		return
	_cast_ability(caster, ability, true, caster.max_energy)
	_check_end()

func _update_meta_ui() -> void:
	gold_label.text = "Gold: %d" % DungRun.gold
	xp_label.text = "LV %d  XP %d/%d" % [DungRun.party_level, DungRun.xp, DungRun.xp_to_next_level()]
	estus_button.text = "Эстус (%d/%d)" % [DungRun.estus_charges, DungRun.estus_max_charges]
	DungRun.refresh_selected_potion_charges()
	var potion_name := RunItems.get_potion_name(DungRun.selected_potion_id)
	potion_button.text = "%s (%d)" % [potion_name, DungRun.custom_potion_charges]
	if is_boss_room:
		treat_button.text = "Лакомство (босс)"
		treat_button.disabled = true
	elif _treat_used:
		treat_button.text = "Лакомство (использовано)"
		treat_button.disabled = true
	else:
		treat_button.text = "Лакомство (20%)"
		treat_button.disabled = false

func _on_estus_pressed() -> void:
	if ended or DungRun.estus_charges <= 0:
		hint_label.text = "Эстус пуст"
		return
	var target := _get_most_wounded_ally(left_team)
	if target == null:
		hint_label.text = "Некого лечить"
		return
	var pct := 0.22
	var amount = max(1, int(round(float(target.max_hp) * pct)))
	target.hp = min(target.max_hp, target.hp + amount)
	DungRun.estus_charges -= 1
	hint_label.text = "Эстус восстановил %d HP" % amount
	_update_player_cards()
	_update_actors_visual()
	_update_meta_ui()

func _on_potion_pressed() -> void:
	if ended or DungRun.custom_potion_charges <= 0:
		hint_label.text = "Зелье закончилось"
		return
	var potion_id := DungRun.selected_potion_id
	if not DungRun.consume_selected_potion_charge():
		hint_label.text = "Зелье закончилось"
		return
	var result := RunItemEffects.use_potion(self, potion_id)
	if not bool(result.get("ok", false)):
		DungRun.refund_selected_potion_charge()
	hint_label.text = String(result.get("reason", "Тип зелья не настроен"))
	_update_player_cards()
	_update_actors_visual()
	_update_meta_ui()

func _on_treat_pressed() -> void:
	if ended:
		return
	if _treat_used:
		hint_label.text = "Лакомство уже использовано в этом бою."
		return
	var target := get_front_alive(right_team)
	if target == null:
		hint_label.text = "Нет цели для лакомства."
		return
	var capture_result := BattleCaptureService.attempt_capture(DungRun.rng, target, is_boss_room)
	_treat_used = true
	if bool(capture_result.get("ok", false)):
		_capture_marked_target = null
		_capture_pending_unit_id = ""
		hint_label.text = "Лакомство сработало. Быстро поймайте сердечки!"
		_start_capture_minigame(String(capture_result.get("unit_id", "")))
	else:
		hint_label.text = String(capture_result.get("reason", "Лакомство не сработало."))
	_update_meta_ui()

func _start_capture_minigame(unit_id: String) -> void:
	if unit_id == "" or _capture_minigame_scene == null:
		hint_label.text = "Мини-игра поимки не настроена."
		return
	if _capture_minigame != null and is_instance_valid(_capture_minigame):
		_capture_minigame.queue_free()
	_capture_minigame = _capture_minigame_scene.instantiate() as CaptureMinigame
	if _capture_minigame == null:
		hint_label.text = "Не удалось открыть мини-игру поимки."
		return
	add_child(_capture_minigame)
	_capture_minigame.finished.connect(func(success: bool, hearts_clicked: int):
		_on_capture_minigame_finished(success, hearts_clicked, unit_id)
	)
	get_tree().paused = true
	_capture_minigame.start()

func _on_capture_minigame_finished(success: bool, hearts_clicked: int, unit_id: String) -> void:
	_capture_minigame = null
	get_tree().paused = false
	if not success:
		hint_label.text = "Поимка сорвалась: %d/9 сердечек." % hearts_clicked
		return
	if UnitRoster_ != null and UnitRoster_.unlock_unit(unit_id):
		var captured_data := CharDB.get_by_id(unit_id)
		hint_label.text = "Новый союзник: %s" % (captured_data.display_name if captured_data != null else unit_id)
	else:
		var captured_data := CharDB.get_by_id(unit_id)
		hint_label.text = "%s уже есть в отряде." % (captured_data.display_name if captured_data != null else unit_id)
	_update_meta_ui()

func _update_actors_visual() -> void:
	for a in left_actors:
		if a != null:
			a.update_visual()
	for a in right_actors:
		if a != null:
			a.update_visual()

func _reset_attack_accums(team: Array[Unit]) -> void:
	for u in team:
		if u != null:
			u.attack_accum = 0.0

func _populate_world_slots() -> void:
	left_actors.clear()
	right_actors.clear()
	for slot in left_world_slots:
		if slot == null:
			continue
		for c in slot.get_children():
			c.queue_free()
		slot.visible = false
	left_actors.resize(left_team.size())
	left_actors.fill(null)
	var left_start = max(0, left_world_slots.size() - left_team.size())
	for i in range(left_team.size()):
		var slot := left_world_slots[left_start + i]
		if slot == null:
			continue
		var u: Unit = left_team[i]
		if u == null:
			continue
		slot.visible = true
		var actor := battle_actor_scene.instantiate() as BattleActor
		slot.add_child(actor)
		actor.bind(u, true)
		left_actors[i] = actor

	if boss_slot != null:
		for c in boss_slot.get_children():
			c.queue_free()
		boss_slot.visible = false

	var room := DungRun.get_current_room()
	is_boss_room = _is_boss_room(room)
	if is_boss_room:
		for slot in right_world_slots:
			if slot == null:
				continue
			for c in slot.get_children():
				c.queue_free()
			slot.visible = false
		boss_slot.visible = true
		var boss_unit: Unit = right_team[0] if right_team.size() > 0 else null
		if boss_unit != null:
			var actor := battle_actor_scene.instantiate() as BattleActor
			actor.is_boss = true
			boss_slot.add_child(actor)
			actor.bind(boss_unit, false)
			right_actors.append(actor)
		return

	for i in range(right_world_slots.size()):
		var slot := right_world_slots[i]
		if slot == null:
			continue
		for c in slot.get_children():
			c.queue_free()
		var u: Unit = right_team[i] if i < right_team.size() else null
		if u == null:
			slot.visible = false
			right_actors.append(null)
			continue
		slot.visible = true
		var actor := battle_actor_scene.instantiate() as BattleActor
		slot.add_child(actor)
		actor.is_boss = false
		actor.bind(u, false)
		right_actors.append(actor)

func _cache_world_slots() -> void:
	left_world_slots.clear()
	right_world_slots.clear()
	for i in [3, 2, 1, 0]:
		left_world_slots.append(left_world.get_node_or_null("LeftSlot%d" % i) as Node2D)
	for i in range(4):
		right_world_slots.append(right_world.get_node_or_null("RightSlot%d" % i) as Node2D)

func build_ui_and_timers() -> void:
	_reset_attack_accums(left_team)
	_reset_attack_accums(right_team)

func _do_attack(attacker: Unit, attacker_is_left: bool) -> void:
	if ended or attacker == null or attacker.is_dead or attacker.has_attack_block() or not attacker.can_attack:
		return
	var effective_is_left := attacker_is_left
	var flipped := false
	if attacker.autoattack_faction_flip():
		effective_is_left = not attacker_is_left
		flipped = true
		_dbg("Charm autoattack flip: %s" % [attacker.data.display_name])
	var target_team := right_team if effective_is_left else left_team
	var target: Unit = get_front_alive(target_team)
	if flipped and target == attacker:
		target = null
		if target_team == left_team:
			for i in range(target_team.size() - 1, -1, -1):
				var candidate := target_team[i]
				if candidate == null or candidate.is_dead or candidate == attacker:
					continue
				target = candidate
				break
		else:
			for candidate in target_team:
				if candidate == null or candidate.is_dead or candidate == attacker:
					continue
				target = candidate
				break
	if target == null:
		return
	var attacker_team := left_team if attacker_is_left else right_team
	var attacker_actors := left_actors if attacker_is_left else right_actors
	var aidx := attacker_team.find(attacker)
	if aidx != -1 and aidx < attacker_actors.size():
		var aactor := attacker_actors[aidx]
		if aactor != null and aactor.has_method("play_attack_bounce"):
			aactor.call("play_attack_bounce", 1 if attacker_is_left else -1)
	var damage := BattleHooks.modify_basic_attack_damage(attacker, target, attacker.damage, attacker_is_left)
	for eff in attacker.effects:
		if eff != null and eff.has_method("on_before_attack"):
			damage = int(eff.call("on_before_attack", attacker, target, damage))
	if attacker.data != null:
		BattleBanter_.trigger("basic_attack", {"speaker_id": String(attacker.data.id)})
	var died := target.take_damage(damage)
	BattleHooks.after_basic_attack(attacker, target, attacker_is_left)
	if not attacker_is_left:
		BattleHooks.on_ally_damaged(target)
	elif died:
		BattleHooks.on_enemy_killed(target, DungRun.room_index + 1)
	_dbg("Autoattack: %s -> %s (%d)" % [attacker.data.display_name, target.data.display_name, damage])
	var target_is_left := not effective_is_left
	var target_actors := left_actors if target_is_left else right_actors
	var idx := target_team.find(target)
	if idx != -1 and idx < target_actors.size():
		var actor := target_actors[idx]
		if actor != null:
			if not died:
				actor.flash_red()
			actor.update_visual()
	attacker.energy = min(attacker.energy + 1, attacker.max_energy)
	_update_player_cards()
	_update_meta_ui()
	_check_end()

func _process_attacks(attacking: Array[Unit], attacker_is_left: bool, delta: float) -> void:
	if ended:
		return
	for u in attacking:
		if u == null or u.is_dead or not u.can_attack:
			continue
		var aps := u.get_final_aps()
		if aps <= 0.0:
			continue
		var interval := 1.0 / maxf(aps, 0.01)
		u.attack_accum += delta
		var loops := 0
		while u.attack_accum >= interval:
			u.attack_accum -= interval
			_do_attack(u, attacker_is_left)
			if ended:
				return
			loops += 1
			if loops >= _attack_safety_cap:
				u.attack_accum = 0.0
				break

func _check_end() -> void:
	var left_alive := get_front_alive(left_team) != null
	var right_alive := get_front_alive(right_team) != null
	if not left_alive and not right_alive:
		_end_null()
	elif not left_alive:
		_end(false)
	elif not right_alive:
		_end(true)

func _end(left_won: bool) -> void:
	if ended:
		return
	ended = true
	if left_won and DungRun.get_current_room() != null:
		var room := DungRun.get_current_room()
		if _is_find_warrior_battle(room):
			_finish_find_warrior_battle()
			return
		if room != null and room.room_type != RoomParams.RoomType.BOSS:
			result_label.text = "Победа!"
			BattleHooks.on_room_cleared(left_team)
			_award_unit_unlocks_on_victory()
			DungRun.save_party_state(left_team)
			_update_meta_ui()
			DungRun.prepare_next_choices()
			BattleBanter_.end_battle()
			SceneRouter_.go_to_room_choice()
			return
	_end_victory = left_won
	_end_is_draw = false
	result_label.text = "Победил игрок" if left_won else "Победил враг"
	_show_end_overlay(left_won, false)

func _finish_find_warrior_battle() -> void:
	# Quest battle should end like a normal run battle: show the victory screen first.
	# The hub post-dialogue starts only after the player presses the end button.
	_end_victory = true
	_end_is_draw = false
	result_label.text = "Победа!"
	BattleBanter_.end_battle()
	_show_end_overlay(true, false)

func _on_find_warrior_post_dialogue_finished() -> void:
	pass

func _find_actor_for_unit(u: Unit, is_left: bool) -> BattleActor:
	var arr := left_actors if is_left else right_actors
	for a in arr:
		if a != null and a.unit == u:
			return a
	return null

func _end_null() -> void:
	if ended:
		return
	ended = true
	BattleBanter_.end_battle()
	_end_victory = false
	_end_is_draw = true
	result_label.text = "Ничья"
	_show_end_overlay(false, true)

func _update_player_cards() -> void:
	for c in player_cards:
		c.update_ui()

func _process(_dt: float) -> void:
	_process_team_effects(left_team, _dt)
	_process_team_effects(right_team, _dt)
	_process_enemy_ai(_dt)
	_process_attacks(left_team, true, _dt)
	_process_attacks(right_team, false, _dt)
	_process_mana_clock(_dt)
	_check_end()
	_effect_ui_accum += _dt
	if _effect_ui_accum >= 0.2:
		_effect_ui_accum = 0.0
		_update_player_cards()
		_update_actors_visual()
		_update_meta_ui()


func _start_mana_clock_timer() -> void:
	_mana_clock_accum = 0.0

func _process_mana_clock(delta: float) -> void:
	if true:
		return
	_mana_clock_accum += delta
	while _mana_clock_accum >= 12.0:
		_mana_clock_accum -= 12.0
		RunItemEffects._grant_team_energy(left_team, 1)

func _process_team_effects(team: Array, delta: float) -> void:
	for u in team:
		if u != null:
			u.process_effects(delta)

func _get_all_alive(team: Array[Unit]) -> Array[Unit]:
	var out: Array[Unit] = []
	for u in team:
		if u != null and not u.is_dead:
			out.append(u)
	return out

func _get_most_wounded_ally(team: Array[Unit]) -> Unit:
	var best: Unit = null
	var best_ratio := 999.0
	for u in team:
		if u == null or u.is_dead:
			continue
		var ratio: float = float(u.hp) / maxf(1.0, float(u.max_hp))
		if ratio < best_ratio:
			best_ratio = ratio
			best = u
	return best

func _apply_heal(unit: Unit, amount: int, ticks: int, interval: float) -> void:
	if unit == null or unit.is_dead:
		return
	unit.add_effect(HealTickEffect.new_unscaled(amount, ticks, interval))

func _deal_damage(attacker_is_left: bool, target: Unit, amount: int, do_flash: bool = true) -> void:
	if target == null or target.is_dead:
		return
	var died := target.take_damage(amount)
	if not attacker_is_left:
		BattleHooks.on_ally_damaged(target)
	elif died and right_team.has(target):
		BattleHooks.on_enemy_killed(target, DungRun.room_index + 1)
	var enemy_team := right_team if attacker_is_left else left_team
	var enemy_actors := right_actors if attacker_is_left else left_actors
	var idx := enemy_team.find(target)
	if idx != -1 and idx < enemy_actors.size():
		var actor := enemy_actors[idx]
		if actor != null:
			if do_flash and not died:
				actor.flash_red()
			actor.update_visual()
	_update_meta_ui()

func _execute_ability(ability: Ability, caster: Unit, caster_is_left: bool) -> void:
	if caster != null and caster.data != null:
		BattleBanter_.trigger("ability_cast", {"speaker_id": String(caster.data.id)})
	var actor := _find_actor_for_unit(caster, caster_is_left)
	if actor != null:
		actor.play_cast_bounce()
	if ability == null or caster == null or caster.is_dead:
		return
	if _try_play_witch_skill_vfx(ability, caster, caster_is_left):
		return
	if _try_play_warrior_ult_vfx(ability, caster, caster_is_left):
		return
	ability.execute(self, caster, caster_is_left)

func _try_play_witch_skill_vfx(ability: Ability, caster: Unit, caster_is_left: bool) -> bool:
	if ability == null or caster == null or caster.is_dead:
		return false
	if caster.data == null or String(caster.data.id) != "witch":
		return false
	if caster.data.skill_ability != ability:
		return false
	if WITCH_ABILITY_PROJECTILE_SCENE == null:
		return false
	var caster_actor := _find_actor_for_unit(caster, caster_is_left)
	if caster_actor == null:
		return false
	var target_team := right_team if caster_is_left else left_team
	var target := get_front_alive(target_team)
	if target == null:
		return false
	var target_actor := _find_actor_for_unit(target, not caster_is_left)
	if target_actor == null:
		return false
	var fx := WITCH_ABILITY_PROJECTILE_SCENE.instantiate()
	if fx == null:
		return false
	add_child(fx)
	var start_pos := caster_actor.global_position + Vector2(26.0 if caster_is_left else -26.0, -112.0)
	var end_pos := target_actor.global_position + Vector2(-8.0 if caster_is_left else 8.0, -112.0)
	fx.impact.connect(func() -> void:
		if ended or caster == null or caster.is_dead:
			return
		ability.execute(self, caster, caster_is_left)
		_check_end()
		_update_player_cards()
		_update_actors_visual()
		_update_meta_ui()
	, CONNECT_ONE_SHOT)
	if fx.has_method("play"):
		fx.call("play", start_pos, end_pos, caster_is_left)
		return true
	fx.queue_free()
	return false

func _try_play_warrior_ult_vfx(ability: Ability, caster: Unit, caster_is_left: bool) -> bool:
	if ability == null or caster == null or caster.is_dead:
		return false
	if caster.data == null or String(caster.data.id) != "warrior":
		return false
	if caster.data.ult_ability != ability:
		return false
	if WARRIOR_ULT_SLASH_SCENE == null:
		return false
	var target_team := right_team if caster_is_left else left_team
	var target := get_front_alive(target_team)
	if target == null:
		return false
	var target_actor := _find_actor_for_unit(target, not caster_is_left)
	if target_actor == null:
		return false
	var fx := WARRIOR_ULT_SLASH_SCENE.instantiate()
	if fx == null:
		return false
	add_child(fx)
	var strike_pos := target_actor.global_position + Vector2(-8.0 if caster_is_left else 8.0, -104.0)
	fx.impact.connect(func() -> void:
		if ended or caster == null or caster.is_dead:
			return
		ability.execute(self, caster, caster_is_left)
		_check_end()
		_update_player_cards()
		_update_actors_visual()
		_update_meta_ui()
	, CONNECT_ONE_SHOT)
	if fx.has_method("play"):
		fx.call("play", strike_pos, not caster_is_left)
		return true
	fx.queue_free()
	return false

func _show_end_overlay(victory: bool, is_draw: bool) -> void:
	end_overlay.visible = true
	if is_draw:
		end_text.text = "Ничья"
		end_image.texture = null
		end_button.text = "Продолжить"
		return
	if victory:
		end_text.text = "УФФ ПОЛЕГЧЕ, КОВБОЙ <3"
		end_image.texture = preload("res://assets/pics/bigPics/endscreen/victory.png")
		end_button.text = "КОНЧИТЬ"
	else:
		end_text.text = "ЧЁ ЗА ТЕНТАКЛИ КАКОЙ ХЕНТАЙ"
		end_image.texture = preload("res://assets/pics/bigPics/endscreen/defeat.png")
		end_button.text = "КОНЧИТЬ"

func _compact_units(team: Array[Unit]) -> Array[Unit]:
	var out: Array[Unit] = []
	for u in team:
		if u != null:
			out.append(u)
	return out

func get_front_alive(team: Array[Unit]) -> Unit:
	if team == left_team:
		for i in range(team.size() - 1, -1, -1):
			var u := team[i]
			if u != null and not u.is_dead and u.hp > 0:
				return u
		return null
	for u in team:
		if u != null and not u.is_dead and u.hp > 0:
			return u
	return null

func _make_unit(id: String, level: int) -> Unit:
	var data := CharDB.get_by_id(id)
	if data == null:
		push_error("Character id NOT FOUND in CharDB: " + id)
		return null
	return Unit.new(data, level)

func spawn_left_team() -> void:
	left_team.clear()
	party_units_in_order.clear()
	var room := DungRun.get_current_room()
	if _is_find_warrior_battle(room):
		for id in ["witch", "warrior"]:
			var quest_unit := _make_unit(id, DungRun.party_level)
			if quest_unit != null:
				left_team.append(quest_unit)
		party_units_in_order = left_team.duplicate()
		return
	for i in range(DungRun.party_slot_count):
		var id := DungRun.party_ids[i]
		if id == "" or id == null:
			continue
		var unit := _make_unit(id, DungRun.party_level)
		if unit != null:
			left_team.append(unit)
	DungRun.apply_party_state(left_team)
	party_units_in_order = left_team.duplicate()

func spawn_right_team() -> void:
	var room := DungRun.get_current_room()
	right_team.clear()
	if _is_find_warrior_battle(room):
		var fufu := _make_unit("fufu", 1)
		right_team.append(fufu)
		if fufu != null:
			fufu.make_enemy(320, 0)
			fufu.reset_ai_interval(DungRun.rng)
		return
	if _is_event_room(room):
		return
	if _is_boss_room(room):
		var boss_id := room.boss_id
		if boss_id == "" or boss_id == null:
			boss_id = "fufu"
		var boss := _make_unit(boss_id, 1)
		right_team.append(boss)
		if boss != null and room != null:
			boss.make_enemy(room.hp_bonus, room.damage_bonus)
			boss.reset_ai_interval(DungRun.rng)
		return
	var enemy_count := 1
	var hp_bonus := 0
	var damage_bonus := 0
	var strong_chance := 0.0
	if room != null:
		enemy_count = room.enemy_count
		hp_bonus = room.hp_bonus
		strong_chance = room.strong_chance
		damage_bonus = room.damage_bonus
	for i in range(enemy_count):
		var id := "base_slime"
		if randf() < strong_chance:
			id = "luisa"
		right_team.append(_make_unit(id, 1))
	for u in right_team:
		if u != null:
			u.make_enemy(hp_bonus, damage_bonus)
			u.reset_ai_interval(DungRun.rng)

func _on_end_button_pressed() -> void:
	BattleBanter_.end_battle()
	if not ended:
		return
	if _end_is_draw:
		FarmState_.advance_day()
		DungRun.on_run_finished_refresh_shops()
		SceneRouter_.go_to_hub()
		return
	if _end_victory and DungRun.get_current_room() != null:
		var current_room := DungRun.get_current_room()
		if _is_find_warrior_battle(current_room):
			if StoryState_ != null:
				StoryState_.set_flag("pending_find_warrior_after_battle", true)
			FarmState_.advance_day()
			DungRun.on_run_finished_refresh_shops()
			SceneRouter_.go_to_hub()
			return
		BattleHooks.on_room_cleared(left_team)
		_award_unit_unlocks_on_victory()
		DungRun.save_party_state(left_team)
		DungRun.advance_room()
		if DungRun.is_finished():
			FarmState_.advance_day()
			DungRun.on_run_finished_refresh_shops()
			SceneRouter_.go_to_hub()
		else:
			get_tree().reload_current_scene()
		return
	FarmState_.advance_day()
	DungRun.on_run_finished_refresh_shops()
	SceneRouter_.go_to_hub()

func _award_unit_unlocks_on_victory() -> void:
	if UnitRoster_ == null:
		return
	var room := DungRun.get_current_room()
	if room != null and _is_boss_room(room):
		var boss_id := room.boss_id if room.boss_id != "" else "fufu"
		UnitRoster_.unlock_boss_once(boss_id)

func _process_enemy_ai(delta: float) -> void:
	if ended:
		return
	for u in right_team:
		if u == null or u.is_dead:
			continue
		u.ai_accum += delta
		if u.ai_accum < u.ai_interval:
			continue
		u.reset_ai_interval(DungRun.rng)
		_try_enemy_cast(u)

func _try_enemy_cast(caster: Unit) -> void:
	if caster == null or caster.is_dead or caster.has_cast_block():
		return
	var ult := caster.data.ult_ability
	if ult != null and caster.energy >= caster.max_energy:
		if _ai_can_cast(caster, ult, false) and randf() < 0.80:
			_cast_ability(caster, ult, false, caster.max_energy)
			return
	var skill := caster.data.skill_ability
	if skill != null:
		var cost := skill.cost if skill.cost > 0 else caster.data.skill_cost
		if caster.energy >= cost and _ai_can_cast(caster, skill, false) and randf() < 0.70:
			caster.energy = max(caster.energy - cost, 0)
			_execute_ability(skill, caster, false)
			_update_player_cards()
			_update_actors_visual()
			_update_meta_ui()

func _ai_can_cast(caster: Unit, ability: Ability, is_left: bool) -> bool:
	if ability == null or caster == null or caster.is_dead:
		return false
	return ability.ai_can_cast(self, caster, is_left)

func _cast_ability(caster: Unit, ability: Ability, is_left: bool, default_cost: int = 0) -> void:
	if ended or caster == null or caster.is_dead or ability == null:
		return
	if caster.has_cast_block():
		hint_label.text = "Нельзя кастовать (эффект)"
		return
	var use_full := ability.use_full_energy
	var cost := 0
	if use_full:
		if caster.energy < caster.max_energy:
			hint_label.text = "Ульта не готова"
			return
		caster.energy = 0
	else:
		cost = ability.cost if ability.cost > 0 else default_cost
		if cost > 0 and caster.energy < cost:
			hint_label.text = "Не хватает энергии"
			return
		caster.energy = max(caster.energy - cost, 0)
	_execute_ability(ability, caster, is_left)
	_update_player_cards()
	_update_actors_visual()
	_update_meta_ui()

func _try_cast_player_slot(slot_idx: int) -> void:
	if ended or slot_idx < 0 or slot_idx >= party_units_in_order.size():
		return
	var u: Unit = party_units_in_order[slot_idx]
	if u == null or u.is_dead:
		return
	if u.has_cast_block():
		hint_label.text = "Нельзя кастовать (эффект)"
		return
	var ability := u.data.skill_ability
	if ability == null:
		hint_label.text = "Умение не задано"
		return
	var cost := u.data.skill_cost
	if ability.cost > 0:
		cost = ability.cost
	_cast_ability(u, ability, true, cost)

func _try_ult_player_slot(slot_idx: int) -> void:
	if ended or slot_idx < 0 or slot_idx >= party_units_in_order.size():
		return
	var u: Unit = party_units_in_order[slot_idx]
	if u == null or u.is_dead:
		return
	if u.has_cast_block():
		hint_label.text = "Нельзя кастовать (эффект)"
		return
	var ability := u.data.ult_ability
	if ability == null:
		hint_label.text = "Ульта не задана"
		return
	_play_player_ult_overlay(u, ability)

func _unhandled_input(event: InputEvent) -> void:
	if event == null or not event.is_pressed() or event.is_echo():
		return
	if event.is_action_pressed("cast_slot_1"):
		_try_cast_player_slot(0)
	elif event.is_action_pressed("cast_slot_2"):
		_try_cast_player_slot(1)
	elif event.is_action_pressed("cast_slot_3"):
		_try_cast_player_slot(2)
	elif event.is_action_pressed("cast_slot_4"):
		_try_cast_player_slot(3)
	elif event.is_action_pressed("ult_slot_1"):
		_try_ult_player_slot(0)
	elif event.is_action_pressed("ult_slot_2"):
		_try_ult_player_slot(1)
	elif event.is_action_pressed("ult_slot_3"):
		_try_ult_player_slot(2)
	elif event.is_action_pressed("ult_slot_4"):
		_try_ult_player_slot(3)
	elif event.is_action_pressed("consumable_slot_1"):
		_on_estus_pressed()
	elif event.is_action_pressed("consumable_slot_2"):
		_on_potion_pressed()
	elif event.is_action_pressed("consumable_slot_3"):
		_on_treat_pressed()
