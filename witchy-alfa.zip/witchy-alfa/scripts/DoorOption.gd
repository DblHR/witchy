extends Area2D
class_name DoorOption

signal pressed

@onready var sprite: Sprite2D = $Sprite
@onready var label: Label = $TypeLabel

var _room: RoomParams

func set_room(r: RoomParams) -> void:
	_room = r

	# текст (preview без подробностей)
	match r.room_type:
		RoomParams.RoomType.BATTLE:
			label.text = "Битва"
		RoomParams.RoomType.BOSS:
			label.text = "Босс"
		RoomParams.RoomType.EVENT:
			match r.event_type:
				RoomParams.EventType.SHOP:
					label.text = "Магазин"
				RoomParams.EventType.NURSE:
					label.text = "Лечение"
				RoomParams.EventType.CHEST:
					label.text = "Сундук"
				RoomParams.EventType.STATUE:
					label.text = "Статуя"
				RoomParams.EventType.QUEST:
					label.text = "???"
				_:
					label.text = "Событие"
		_:
			label.text = "?"

	# спрайт двери/иконку комнаты пользователь подставит сам.
	# Здесь оставляем дефолтную текстуру пустой — чтобы не привязываться к ресурсам.
	# sprite.texture = ...

func _input_event(viewport, event, shape_idx) -> void:
	if event is InputEventMouseButton and event.pressed and event.button_index == MOUSE_BUTTON_LEFT:
		emit_signal("pressed")
