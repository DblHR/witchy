extends Node
class_name SceneRouter

# Явные пути сцен — чтобы не разносить строки по проекту.
const MAIN_MENU := "res://scenes/MainMenu.tscn" 
const HUB := "res://scenes/Hub.tscn"            
const PROLOGUE := "res://scenes/Prologue.tscn"

const SETUP := "res://scenes/Setup.tscn"
const BATTLE := "res://scenes/BattleSim.tscn"
const CARD_BATTLE := "res://scenes/card/CardBattle.tscn"
const TUTORIAL_BATTLE := "res://scenes/tutorial/TutorialBattle.tscn"
const TUTORIAL_BRIDGE := "res://scenes/tutorial/TutorialBridge.tscn"
const ROOM_CHOICE := "res://scenes/RoomChoice.tscn"
const EVENT_ROOM := "res://scenes/EventRoom.tscn"

const FARM := "res://scenes/Farm.tscn"
const ALCHEMY := "res://scripts/alchemy/Alchemy.tscn"
const SHOP_SCENE := "res://scenes/Shop.tscn"
const INVENTORY := "res://scenes/Inventory.tscn"

func go_to_setup() -> void:
	get_tree().paused = false
	get_tree().change_scene_to_file(SETUP)

func go_to_battle() -> void:
	get_tree().paused = false
	get_tree().change_scene_to_file(BATTLE)

func go_to_card_battle() -> void:
	get_tree().paused = false
	get_tree().change_scene_to_file(CARD_BATTLE)

func go_to_tutorial_battle() -> void:
	get_tree().paused = false
	get_tree().change_scene_to_file(TUTORIAL_BATTLE)

func go_to_tutorial_bridge() -> void:
	get_tree().paused = false
	get_tree().change_scene_to_file(TUTORIAL_BRIDGE)

func go_to_room_choice() -> void:
	get_tree().paused = false
	get_tree().change_scene_to_file(ROOM_CHOICE)

func go_to_event_room() -> void:
	get_tree().paused = false
	get_tree().change_scene_to_file(EVENT_ROOM)

# Эти два пока не используем, но заранее фиксируем API.
func go_to_main_menu() -> void:
	get_tree().paused = false
	get_tree().change_scene_to_file(MAIN_MENU)

func go_to_hub() -> void:
	get_tree().paused = false
	get_tree().change_scene_to_file(HUB)
	
func go_to_farm() -> void:
	get_tree().paused = false
	get_tree().change_scene_to_file(FARM)

func go_to_alchemy() -> void:
	get_tree().paused = false
	get_tree().change_scene_to_file(ALCHEMY)

func go_to_shop() -> void:
	get_tree().paused = false
	get_tree().change_scene_to_file(SHOP_SCENE)

func go_to_inventory() -> void:
	get_tree().paused = false
	get_tree().change_scene_to_file(INVENTORY)

func go_to_prologue() -> void:
	get_tree().paused = false
	get_tree().change_scene_to_file(PROLOGUE)
