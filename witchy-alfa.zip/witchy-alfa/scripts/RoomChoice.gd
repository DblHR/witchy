extends Node2D
class_name RoomChoice

const DoorOptionScene := preload("res://scenes/DoorOption.tscn")

@onready var door_slots: Array[Node2D] = [
	$DoorSlotsWorld/DoorSlot0,
	$DoorSlotsWorld/DoorSlot1,
	$DoorSlotsWorld/DoorSlot2,
]

func _ready() -> void:
	# Если выбора нет — возвращаемся в бой (страховка)
	if not DungRun.has_pending_choices():
		get_tree().change_scene_to_file("res://scenes/BattleSim.tscn")
		return

	_spawn_doors(DungRun.get_pending_choices())

func _spawn_doors(choices: Array[RoomParams]) -> void:
	# чистим
	for s in door_slots:
		for c in s.get_children():
			c.queue_free()

	# создаём двери
	for i in range(min(choices.size(), door_slots.size())):
		var room := choices[i]
		var door := DoorOptionScene.instantiate()
		door_slots[i].add_child(door)

		door.set_room(room)
		door.pressed.connect(func():
			_on_door_chosen(i)
		)

func _on_door_chosen(choice_index: int) -> void:
	DungRun.choose_pending_choice(choice_index)

	# Загружаем сцену по типу комнаты
	if DungRun.is_current_room_battle():
		get_tree().change_scene_to_file("res://scenes/BattleSim.tscn")
	else:
		get_tree().change_scene_to_file("res://scenes/EventRoom.tscn")
