extends CanvasLayer
class_name CaptureMinigame

signal finished(success: bool, hearts_clicked: int)

const WINDOW_SIZE := Vector2(430, 430)
const ROUND_TIME := 6.0
const TARGET_HEARTS := 9
const HEART_CHAR := "♥"

@onready var dimmer: ColorRect = $Dimmer
@onready var panel: Panel = $Center/Panel
@onready var hearts_layer: Control = $Center/Panel/HeartsLayer
@onready var title_label: Label = $Center/Panel/TitleLabel
@onready var info_label: Label = $Center/Panel/InfoLabel
@onready var timer_label: Label = $Center/Panel/TimerLabel
@onready var score_label: Label = $Center/Panel/ScoreLabel

var _rng := RandomNumberGenerator.new()
var _elapsed := 0.0
var _spawn_accum := 0.0
var _next_spawn_in := 0.25
var _clicked_hearts := 0
var _is_finished := false


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	layer = 120
	_rng.randomize()
	if dimmer != null:
		dimmer.mouse_filter = Control.MOUSE_FILTER_STOP
	if panel != null:
		panel.custom_minimum_size = WINDOW_SIZE
		panel.size = WINDOW_SIZE
	if get_viewport() != null and not get_viewport().size_changed.is_connected(_layout_ui):
		get_viewport().size_changed.connect(_layout_ui)
	_layout_ui()
	_update_labels()

func _layout_ui() -> void:
	var viewport_size := get_viewport().get_visible_rect().size
	if dimmer != null:
		dimmer.set_anchors_preset(Control.PRESET_FULL_RECT)
		dimmer.offset_left = 0.0
		dimmer.offset_top = 0.0
		dimmer.offset_right = 0.0
		dimmer.offset_bottom = 0.0
		dimmer.size = viewport_size
	var center := get_node_or_null("Center") as Control
	if center != null:
		center.set_anchors_preset(Control.PRESET_FULL_RECT)
		center.offset_left = 0.0
		center.offset_top = 0.0
		center.offset_right = 0.0
		center.offset_bottom = 0.0
	if panel != null:
		panel.position = ((viewport_size - WINDOW_SIZE) * 0.5).floor()
		panel.size = WINDOW_SIZE

func start() -> void:
	_elapsed = 0.0
	_spawn_accum = 0.0
	_clicked_hearts = 0
	_is_finished = false
	_next_spawn_in = _rand_spawn_interval()
	for c in hearts_layer.get_children():
		c.queue_free()
	_layout_ui()
	_update_labels()

func _process(delta: float) -> void:
	if _is_finished:
		return
	_elapsed += delta
	_spawn_accum += delta
	while _spawn_accum >= _next_spawn_in:
		_spawn_accum -= _next_spawn_in
		_spawn_heart()
		_next_spawn_in = _rand_spawn_interval()
	_update_hearts(delta)
	_update_labels()
	if _elapsed >= ROUND_TIME:
		_finish(_clicked_hearts >= TARGET_HEARTS)

func _update_labels() -> void:
	var time_left := maxf(0.0, ROUND_TIME - _elapsed)
	title_label.text = "Поимка"
	info_label.text = "Поймайте сердце: %d/%d" % [_clicked_hearts, TARGET_HEARTS]
	timer_label.text = "%.1f c" % time_left
	score_label.text = "Нужно успеть нажать 9 сердец за 6 секунд"

func _rand_spawn_interval() -> float:
	return _rng.randf_range(0.16, 0.34)

func _spawn_heart() -> void:
	if hearts_layer == null:
		return
	var heart := Button.new()
	heart.flat = true
	heart.text = HEART_CHAR
	heart.focus_mode = Control.FOCUS_NONE
	heart.mouse_default_cursor_shape = Control.CURSOR_POINTING_HAND
	heart.mouse_filter = Control.MOUSE_FILTER_STOP
	heart.process_mode = Node.PROCESS_MODE_ALWAYS
	var font_size := _rng.randi_range(20, 34)
	heart.add_theme_font_size_override("font_size", font_size)
	heart.add_theme_color_override("font_color", Color(1.0, 0.28 + _rng.randf_range(0.0, 0.18), 0.42 + _rng.randf_range(0.0, 0.16), 1.0))
	heart.add_theme_color_override("font_outline_color", Color(0.45, 0.02, 0.08, 1.0))
	heart.add_theme_constant_override("outline_size", 3)
	heart.add_theme_stylebox_override("normal", StyleBoxEmpty.new())
	heart.add_theme_stylebox_override("hover", StyleBoxEmpty.new())
	heart.add_theme_stylebox_override("pressed", StyleBoxEmpty.new())
	heart.size = Vector2(font_size + 18, font_size + 18)
	heart.custom_minimum_size = heart.size
	heart.pivot_offset = heart.size * 0.5
	heart.set_meta("speed", _rng.randf_range(120.0, 260.0))
	heart.set_meta("drift", _rng.randf_range(-26.0, 26.0))
	heart.set_meta("life", 0.0)
	var max_x := maxf(16.0, hearts_layer.size.x - heart.size.x - 16.0)
	heart.position = Vector2(_rng.randf_range(8.0, max_x), hearts_layer.size.y + heart.size.y)
	heart.pressed.connect(_on_heart_pressed.bind(heart))
	hearts_layer.add_child(heart)

func _update_hearts(delta: float) -> void:
	for child in hearts_layer.get_children():
		var heart := child as Button
		if heart == null:
			continue
		var life := float(heart.get_meta("life", 0.0)) + delta
		heart.set_meta("life", life)
		var pos := heart.position
		pos.y -= float(heart.get_meta("speed", 160.0)) * delta
		pos.x += sin(life * 4.5) * float(heart.get_meta("drift", 0.0)) * delta
		heart.position = pos
		if pos.y < -heart.size.y - 12.0:
			heart.queue_free()

func _on_heart_pressed(heart: Button) -> void:
	if _is_finished:
		return
	_clicked_hearts += 1
	if is_instance_valid(heart):
		heart.queue_free()
	if _clicked_hearts >= TARGET_HEARTS:
		_finish(true)
	else:
		_update_labels()

func _finish(success: bool) -> void:
	if _is_finished:
		return
	_is_finished = true
	finished.emit(success, _clicked_hearts)
	queue_free()
