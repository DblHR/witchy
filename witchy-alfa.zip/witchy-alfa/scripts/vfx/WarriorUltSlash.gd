extends Node2D
class_name WarriorUltSlash

signal impact
signal finished

const SPARK_COUNT := 8
const GLOW_TEX := preload("res://assets/pics/vfx/warrior_ult_slash_glow.png")
const CORE_TEX := preload("res://assets/pics/vfx/warrior_ult_slash.png")

@export var intro_duration: float = 0.075
@export var sustain_duration: float = 0.11
@export var fade_duration: float = 0.14
@export var base_scale: float = 0.28
@export var peak_scale: float = 0.36

@onready var slash_glow: Sprite2D = $SlashGlow
@onready var slash_back: Sprite2D = $SlashBack
@onready var slash_core: Sprite2D = $SlashCore
@onready var trail_far: Sprite2D = $TrailFar
@onready var trail_near: Sprite2D = $TrailNear
@onready var cut_lines: Node2D = $CutLines
@onready var sparks: Node2D = $Sparks

var _rng := RandomNumberGenerator.new()
var _did_impact := false
var _facing_left := false

func _ready() -> void:
	_rng.randomize()
	z_as_relative = false
	z_index = 24
	for spr in [slash_glow, slash_back, slash_core, trail_far, trail_near]:
		spr.texture = GLOW_TEX if spr == slash_glow else CORE_TEX
		spr.centered = true
		spr.visible = true
		spr.modulate.a = 0.0
	_build_cut_lines()
	_build_sparks()

func play(world_pos: Vector2, facing_left: bool) -> void:
	global_position = world_pos
	_facing_left = facing_left
	var dir := -1.0 if facing_left else 1.0
	scale = Vector2(base_scale * dir, base_scale)
	rotation = deg_to_rad(-11.0 if facing_left else 11.0)
	_did_impact = false

	slash_glow.position = Vector2.ZERO
	slash_back.position = Vector2.ZERO
	slash_core.position = Vector2.ZERO
	slash_glow.scale = Vector2(0.82, 0.82)
	slash_glow.modulate = Color(1.0, 0.38, 0.52, 0.0)
	slash_back.scale = Vector2(0.64, 0.64)
	slash_back.modulate = Color(0.92, 0.12, 0.22, 0.0)
	slash_core.scale = Vector2(0.52, 0.52)
	slash_core.modulate = Color(1.08, 0.98, 1.02, 0.0)

	trail_far.scale = Vector2(0.46, 0.36)
	trail_far.position = Vector2(-62.0 * dir, 12.0)
	trail_far.modulate = Color(0.95, 0.14, 0.22, 0.0)
	trail_near.scale = Vector2(0.34, 0.28)
	trail_near.position = Vector2(-34.0 * dir, 6.0)
	trail_near.modulate = Color(1.0, 0.66, 0.76, 0.0)

	for n in cut_lines.get_children():
		if n is Line2D:
			n.modulate.a = 0.0
			n.scale = Vector2.ONE * 0.82
	for n in sparks.get_children():
		if n is Sprite2D:
			n.modulate.a = 0.0
			n.scale = Vector2.ONE * 0.2
			n.position = Vector2.ZERO
			n.rotation = 0.0

	var t := create_tween()
	t.set_parallel(true)
	t.tween_property(self, "scale", Vector2(peak_scale * dir, peak_scale), intro_duration).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_OUT)
	t.tween_property(self, "rotation", deg_to_rad(3.0 if facing_left else -3.0), intro_duration + sustain_duration).set_trans(Tween.TRANS_CUBIC).set_ease(Tween.EASE_OUT)
	t.tween_property(slash_glow, "modulate:a", 0.88, intro_duration)
	t.tween_property(slash_back, "modulate:a", 0.82, intro_duration * 0.95)
	t.tween_property(slash_core, "modulate:a", 1.0, intro_duration * 0.92)
	t.tween_property(trail_far, "modulate:a", 0.28, intro_duration)
	t.tween_property(trail_near, "modulate:a", 0.42, intro_duration * 0.9)
	t.parallel().tween_property(trail_far, "position:x", -88.0 * dir, intro_duration + sustain_duration)
	t.parallel().tween_property(trail_near, "position:x", -60.0 * dir, intro_duration + sustain_duration * 0.9)
	t.finished.connect(_after_strike, CONNECT_ONE_SHOT)

func _after_strike() -> void:
	if not _did_impact:
		_did_impact = true
		emit_signal("impact")
	_emit_cut_lines()
	_emit_sparks()
	var dir := -1.0 if _facing_left else 1.0
	var t := create_tween()
	t.set_parallel(true)
	t.tween_property(self, "scale", Vector2((peak_scale + 0.03) * dir, peak_scale + 0.03), fade_duration)
	t.tween_property(slash_glow, "scale", Vector2(1.02, 1.02), fade_duration)
	t.tween_property(slash_glow, "modulate:a", 0.0, fade_duration)
	t.tween_property(slash_back, "scale", Vector2(0.78, 0.78), fade_duration * 0.95)
	t.tween_property(slash_back, "modulate:a", 0.0, fade_duration * 0.95)
	t.tween_property(slash_core, "scale", Vector2(0.62, 0.62), fade_duration * 0.9)
	t.tween_property(slash_core, "modulate:a", 0.0, fade_duration * 0.9)
	t.tween_property(trail_far, "modulate:a", 0.0, fade_duration * 0.75)
	t.tween_property(trail_near, "modulate:a", 0.0, fade_duration * 0.68)
	t.finished.connect(func() -> void:
		emit_signal("finished")
		queue_free()
	, CONNECT_ONE_SHOT)

func _build_cut_lines() -> void:
	for c in cut_lines.get_children():
		c.queue_free()
	var segments := [
		[Vector2(22, -92), Vector2(48, -124)],
		[Vector2(64, -54), Vector2(92, -80)],
		[Vector2(96, 4), Vector2(126, -10)],
		[Vector2(-62, 70), Vector2(-88, 118)],
		[Vector2(-90, 18), Vector2(-118, 60)]
	]
	for pts in segments:
		var line := Line2D.new()
		line.width = 3.0
		line.default_color = Color(1.0, 0.34, 0.42, 0.0)
		line.antialiased = true
		line.add_point(pts[0])
		line.add_point(pts[1])
		cut_lines.add_child(line)

func _emit_cut_lines() -> void:
	var delay := 0.0
	for line in cut_lines.get_children():
		if not (line is Line2D):
			continue
		line.scale = Vector2.ONE * 0.72
		var tw := create_tween()
		tw.tween_interval(delay)
		tw.tween_property(line, "modulate:a", 0.92, 0.025)
		tw.parallel().tween_property(line, "scale", Vector2.ONE * 1.02, 0.08)
		tw.tween_property(line, "modulate:a", 0.0, 0.10)
		delay += 0.012

func _build_sparks() -> void:
	for c in sparks.get_children():
		c.queue_free()
	for i in range(SPARK_COUNT):
		var spr := Sprite2D.new()
		spr.texture = GLOW_TEX
		spr.centered = true
		spr.scale = Vector2.ONE * 0.2
		spr.modulate = Color(1.0, 0.75, 0.82, 0.0)
		sparks.add_child(spr)

func _emit_sparks() -> void:
	var dir := -1.0 if _facing_left else 1.0
	for spr in sparks.get_children():
		if not (spr is Sprite2D):
			continue
		var angle := _rng.randf_range(-1.9, 0.9)
		if _facing_left:
			angle = PI - angle
		var dist := _rng.randf_range(30.0, 86.0)
		var target := Vector2(cos(angle), sin(angle)) * dist
		target.x += 18.0 * dir
		spr.position = Vector2(_rng.randf_range(-10.0, 10.0), _rng.randf_range(-12.0, 12.0))
		spr.rotation = angle
		spr.scale = Vector2(_rng.randf_range(0.02, 0.05), _rng.randf_range(0.02, 0.05))
		spr.modulate = Color(1.0, 0.56 + _rng.randf_range(0.0, 0.10), 0.72 + _rng.randf_range(0.0, 0.12), 0.82)
		var tw := create_tween()
		tw.set_parallel(true)
		tw.tween_property(spr, "position", target, _rng.randf_range(0.10, 0.16)).set_trans(Tween.TRANS_CUBIC).set_ease(Tween.EASE_OUT)
		tw.tween_property(spr, "modulate:a", 0.0, _rng.randf_range(0.10, 0.16))
		tw.tween_property(spr, "scale", Vector2.ONE * _rng.randf_range(0.01, 0.02), _rng.randf_range(0.10, 0.16))
