extends Node2D
class_name WitchAbilityProjectile

signal impact
signal finished

const SOFT_GLOW_TEX := preload("res://assets/pics/vfx/witch_soft_glow.png")
const BULLET_TEX := preload("res://assets/pics/vfx/witch_bullet_core.png")
const HEART_TEX := preload("res://assets/pics/vfx/witch_heart.png")
const STAR_TEX := preload("res://assets/pics/vfx/witch_star.png")

@export var flight_time: float = 0.20
@export var burst_duration: float = 0.26
@export var trail_max_points: int = 16
@export var trail_width: float = 28.0
@export var arc_height: float = 62.0

var _start := Vector2.ZERO
var _end := Vector2.ZERO
var _control := Vector2.ZERO
var _elapsed: float = 0.0
var _playing := false
var _bursting := false
var _emission_accum: float = 0.0
var _rng := RandomNumberGenerator.new()

@onready var trail: Line2D = $Trail
@onready var core_glow: Sprite2D = $CoreGlow
@onready var core: Sprite2D = $Core
@onready var front_glow: Sprite2D = $FrontGlow
@onready var particles: Node2D = $Particles
@onready var burst_root: Node2D = $Burst

func _ready() -> void:
	_rng.randomize()
	visible = false
	trail.clear_points()
	set_process(false)

func play(start_pos: Vector2, end_pos: Vector2, from_left: bool = true) -> void:
	_start = start_pos
	_end = end_pos
	var mid := (_start + _end) * 0.5
	var travel := _end - _start
	var side_sway := travel.normalized().orthogonal() * (_rng.randf_range(-10.0, 10.0))
	_control = mid + Vector2(0.0, -arc_height) + side_sway
	if absf(travel.x) < 120.0:
		_control.x += -18.0 if from_left else 18.0
	global_position = _start
	rotation = travel.angle()
	_elapsed = 0.0
	_playing = true
	_bursting = false
	visible = true
	trail.clear_points()
	trail.width = trail_width
	_append_trail_point(global_position)
	core.scale = Vector2(0.72, 0.72)
	core_glow.scale = Vector2(0.78, 0.78)
	front_glow.scale = Vector2(0.48, 0.48)
	core.modulate = Color(1.0, 0.88, 0.98, 0.98)
	core_glow.modulate = Color(1.0, 0.66, 0.88, 0.82)
	front_glow.modulate = Color(1.0, 0.94, 0.98, 0.95)
	set_process(true)

func _process(delta: float) -> void:
	if not _playing:
		return
	if _bursting:
		return
	_elapsed += delta
	var t := clampf(_elapsed / maxf(flight_time, 0.001), 0.0, 1.0)
	var eased := 1.0 - pow(1.0 - t, 3.0)
	var pos := _quadratic_bezier(_start, _control, _end, eased)
	global_position = pos
	var tangent := _quadratic_bezier_tangent(_start, _control, _end, eased)
	if tangent.length() > 0.001:
		rotation = tangent.angle()
	_append_trail_point(global_position)
	_update_core_pulse(t)
	_emit_trailing_particles(delta)
	if t >= 1.0:
		_start_burst()

func _quadratic_bezier(a: Vector2, b: Vector2, c: Vector2, t: float) -> Vector2:
	var u := 1.0 - t
	return (u * u * a) + (2.0 * u * t * b) + (t * t * c)

func _quadratic_bezier_tangent(a: Vector2, b: Vector2, c: Vector2, t: float) -> Vector2:
	return 2.0 * (1.0 - t) * (b - a) + 2.0 * t * (c - b)

func _append_trail_point(p: Vector2) -> void:
	trail.add_point(to_local(p))
	while trail.get_point_count() > trail_max_points:
		trail.remove_point(0)

func _update_core_pulse(t: float) -> void:
	var pulse := 0.92 + sin((_elapsed * 18.0) + (t * 4.0)) * 0.08
	core.scale = Vector2.ONE * (0.72 + pulse * 0.18)
	core_glow.scale = Vector2.ONE * (0.96 + pulse * 0.34)
	front_glow.scale = Vector2.ONE * (0.44 + pulse * 0.22)
	core_glow.modulate.a = 0.58 + pulse * 0.18
	front_glow.modulate.a = 0.72 + pulse * 0.18

func _emit_trailing_particles(delta: float) -> void:
	_emission_accum += delta
	while _emission_accum >= 0.018:
		_emission_accum -= 0.018
		_spawn_floating_particle(global_position - Vector2(_rng.randf_range(4.0, 18.0), _rng.randf_range(-6.0, 6.0)), false)
		if _rng.randf() < 0.42:
			_spawn_floating_particle(global_position - Vector2(_rng.randf_range(18.0, 42.0), _rng.randf_range(-14.0, 14.0)), true)

func _spawn_floating_particle(world_pos: Vector2, favor_symbols: bool) -> void:
	var spr := Sprite2D.new()
	var symbol_roll := _rng.randf()
	if favor_symbols and symbol_roll < 0.48:
		spr.texture = HEART_TEX
		spr.modulate = Color(1.0, 0.72 + _rng.randf_range(0.0, 0.12), 0.88 + _rng.randf_range(0.0, 0.08), 0.95)
	elif symbol_roll < 0.24:
		spr.texture = STAR_TEX
		spr.modulate = Color(1.0, 0.92 + _rng.randf_range(0.0, 0.08), 0.52 + _rng.randf_range(0.0, 0.18), 0.95)
	else:
		spr.texture = SOFT_GLOW_TEX
		spr.modulate = Color(1.0, 0.58 + _rng.randf_range(0.0, 0.18), 0.86 + _rng.randf_range(0.0, 0.12), 0.62)
	particles.add_child(spr)
	spr.global_position = world_pos
	spr.rotation = _rng.randf_range(-0.7, 0.7)
	var scale_value := _rng.randf_range(0.08, 0.20) if spr.texture == SOFT_GLOW_TEX else _rng.randf_range(0.16, 0.28)
	spr.scale = Vector2.ONE * scale_value
	var drift := Vector2(_rng.randf_range(-24.0, 10.0), _rng.randf_range(-18.0, 18.0))
	var tw := create_tween()
	tw.set_parallel(true)
	tw.tween_property(spr, "global_position", world_pos + drift, _rng.randf_range(0.24, 0.40))
	tw.tween_property(spr, "scale", spr.scale * _rng.randf_range(0.6, 1.35), _rng.randf_range(0.24, 0.40))
	tw.tween_property(spr, "modulate:a", 0.0, _rng.randf_range(0.24, 0.40))
	tw.finished.connect(func() -> void:
		if is_instance_valid(spr):
			spr.queue_free()
	, CONNECT_ONE_SHOT)

func _start_burst() -> void:
	if _bursting:
		return
	_bursting = true
	_playing = false
	trail.clear_points()
	impact.emit()
	for i in range(11):
		_spawn_burst_particle(i)
	var tw := create_tween()
	tw.set_parallel(true)
	tw.tween_property(core, "scale", Vector2.ONE * 1.65, burst_duration)
	tw.tween_property(core_glow, "scale", Vector2.ONE * 2.25, burst_duration)
	tw.tween_property(front_glow, "scale", Vector2.ONE * 1.75, burst_duration)
	tw.tween_property(core, "modulate:a", 0.0, burst_duration)
	tw.tween_property(core_glow, "modulate:a", 0.0, burst_duration)
	tw.tween_property(front_glow, "modulate:a", 0.0, burst_duration)
	tw.finished.connect(func() -> void:
		finished.emit()
		queue_free()
	, CONNECT_ONE_SHOT)

func _spawn_burst_particle(idx: int) -> void:
	var spr := Sprite2D.new()
	var use_heart := idx % 3 == 0
	var use_star := idx % 4 == 0 and not use_heart
	spr.texture = HEART_TEX if use_heart else (STAR_TEX if use_star else SOFT_GLOW_TEX)
	if use_heart:
		spr.modulate = Color(1.0, 0.72, 0.88, 1.0)
	elif use_star:
		spr.modulate = Color(1.0, 0.95, 0.62, 1.0)
	else:
		spr.modulate = Color(1.0, 0.70, 0.90, 0.84)
	burst_root.add_child(spr)
	spr.global_position = global_position + Vector2(_rng.randf_range(-6.0, 6.0), _rng.randf_range(-6.0, 6.0))
	var base_scale := _rng.randf_range(0.18, 0.34) if (use_heart or use_star) else _rng.randf_range(0.10, 0.22)
	spr.scale = Vector2.ONE * base_scale
	spr.rotation = _rng.randf_range(0.0, TAU)
	var angle := _rng.randf_range(0.0, TAU)
	var radius := _rng.randf_range(30.0, 92.0)
	var offset := Vector2.RIGHT.rotated(angle) * radius
	offset.y *= 0.78
	var tw := create_tween()
	tw.set_parallel(true)
	tw.tween_property(spr, "global_position", spr.global_position + offset, _rng.randf_range(0.24, 0.38))
	tw.tween_property(spr, "scale", spr.scale * _rng.randf_range(0.6, 1.8), _rng.randf_range(0.24, 0.38))
	tw.tween_property(spr, "modulate:a", 0.0, _rng.randf_range(0.24, 0.38))
	tw.finished.connect(func() -> void:
		if is_instance_valid(spr):
			spr.queue_free()
	, CONNECT_ONE_SHOT)
