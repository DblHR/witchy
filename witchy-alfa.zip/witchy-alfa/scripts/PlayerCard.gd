extends Control
class_name PlayerCard

signal ult_pressed(card: PlayerCard)
signal skill_pressed(card: PlayerCard)

@onready var portrait: TextureRect = %Portrait
@onready var name_label: Label = %NameLabel
@onready var hp_bar: ProgressBar = %HPBar
@onready var hp_text: Label = %HPText
@onready var en_bar: ProgressBar = %ENBar
@onready var en_text: Label = %ENText
@onready var skill_button: TextureButton = %SkillButton
@onready var click_area: Control = %ClickArea
@onready var ult_glow: TextureRect = $Content/Portrait/UltGlow

var unit: Unit

func bind(u: Unit) -> void:
	unit = u
	update_ui()

func _set_button_gray(btn: BaseButton, gray: bool) -> void:
	if gray:
		btn.modulate = Color(0.55, 0.55, 0.55, 1)
	else:
		btn.modulate = Color(1, 1, 1, 1)

func _set_ult_ready_fx(on: bool) -> void:
	# Вариант без сложной графики: белый контур/свечение через modulate на Portrait контейнер
	# Лучше всего сделать отдельный узел "UltGlow" поверх Portrait, но начнём просто.
	if on:
		portrait.modulate = Color(1.2, 1.2, 1.2, 1) # лёгкое свечение
	else:
		portrait.modulate = Color(1, 1, 1, 1)

func update_ui() -> void:
	if unit == null:
		visible = false
		return

	visible = true
	name_label.text = unit.data.display_name

	# портрет карточки (если нет card_portrait — показываем battle_texture)
	portrait.texture = unit.data.card_portrait if unit.data.card_portrait != null else unit.data.battle_texture

	# иконка скилла (если задана в ability — берём её, иначе fallback на поле skill_icon)
	if unit.data.skill_ability != null and unit.data.skill_ability.icon != null:
		skill_button.texture_normal = unit.data.skill_ability.icon
	elif unit.data.skill_icon != null:
		skill_button.texture_normal = unit.data.skill_icon

	hp_bar.max_value = unit.max_hp
	hp_bar.value = clamp(unit.hp, 0, unit.max_hp)
	hp_text.text = "%d/%d" % [unit.hp, unit.max_hp]
	_apply_hp_bar_state()

	en_bar.max_value = unit.max_energy
	en_bar.value = clamp(unit.energy, 0, unit.max_energy)
	en_text.text = "%d/%d" % [unit.energy, unit.max_energy]
	
	# 1) доступность умения (берём из ability, если задано)
	var cost := unit.data.skill_cost
	if unit.data.skill_ability != null and unit.data.skill_ability.cost > 0:
		cost = unit.data.skill_ability.cost
	var can_use := (not unit.is_dead) and unit.energy >= cost

	skill_button.disabled = not can_use
	_set_button_gray(skill_button, not can_use)

	# 2) ульта доступна, когда энергия полная (и жив)
	var ult_ready := (not unit.is_dead) and unit.energy >= unit.max_energy
	ult_glow.visible = ult_ready

func _set_progress_fill_color(bar: ProgressBar, color: Color) -> void:
	if bar == null:
		return
	var fill = bar.get("theme_override_styles/fill")
	if fill is StyleBoxFlat:
		var sb: StyleBoxFlat = (fill as StyleBoxFlat).duplicate()
		sb.bg_color = color
		bar.add_theme_stylebox_override("fill", sb)

func _apply_hp_bar_state() -> void:
	if unit == null:
		return
	var ratio := 0.0 if unit.max_hp <= 0 else float(unit.hp) / float(unit.max_hp)
	if unit.is_dead:
		_set_progress_fill_color(hp_bar, Color(0.45, 0.45, 0.45, 0.95))
		hp_text.modulate = Color(0.8, 0.8, 0.8, 1.0)
	elif ratio <= 0.30:
		_set_progress_fill_color(hp_bar, Color(0.92, 0.18, 0.18, 0.95))
		hp_text.modulate = Color(1.0, 0.85, 0.85, 1.0)
	else:
		_set_progress_fill_color(hp_bar, Color(0.18, 0.82, 0.32, 0.95))
		hp_text.modulate = Color(1, 1, 1, 1)

func _ready() -> void:
	# Чтобы клики всегда доходили до ClickArea, а не "съедались" прогресс-барами/лейблами.
	# SkillButton остаётся кликабельным.
	for n in [portrait, name_label, hp_bar, hp_text, en_bar, en_text]:
		if n != null:
			n.mouse_filter = Control.MOUSE_FILTER_IGNORE

	click_area.mouse_filter = Control.MOUSE_FILTER_STOP
	click_area.z_index = 100
	skill_button.z_index = 101

	click_area.gui_input.connect(_on_click_area_gui_input)
	skill_button.pressed.connect(func():
		emit_signal("skill_pressed", self)
	)

func _on_click_area_gui_input(event: InputEvent) -> void:
	if event is InputEventMouseButton and event.pressed and event.button_index == MOUSE_BUTTON_LEFT:
		emit_signal("ult_pressed", self)
