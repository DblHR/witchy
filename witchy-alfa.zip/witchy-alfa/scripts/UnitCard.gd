extends Control
class_name UnitCard

@onready var bars_top: VBoxContainer = %BarsTop
@onready var bars_bottom: VBoxContainer = %BarsBottom

@onready var hp_top: ProgressBar = %HPBar
@onready var en_top: ProgressBar = %ENBar
@onready var hp_bottom: ProgressBar = %HPBar2
@onready var en_bottom: ProgressBar = %ENBar2

@onready var hp_label_top: Label = %HPLabel
@onready var en_label_top: Label = %ENLabel
@onready var hp_label_bottom: Label = %HPLabel2
@onready var en_label_bottom: Label = %ENLabel2

@onready var sprite: TextureRect = %Sprite

var unit: Unit
var is_left: bool = true  # true = игрок (слева), false = враг (справа)

func _set_progress_fill_color(bar: ProgressBar, color: Color) -> void:
	if bar == null:
		return
	var fill = bar.get("theme_override_styles/fill")
	if fill is StyleBoxFlat:
		var sb: StyleBoxFlat = (fill as StyleBoxFlat).duplicate()
		sb.bg_color = color
		bar.add_theme_stylebox_override("fill", sb)

func _apply_hp_bar_state(bar: ProgressBar, label: Label) -> void:
	if unit == null or bar == null or label == null:
		return
	var ratio := 0.0 if unit.max_hp <= 0 else float(unit.hp) / float(unit.max_hp)
	if unit.is_dead:
		_set_progress_fill_color(bar, Color(0.45, 0.45, 0.45, 0.95))
		label.modulate = Color(0.8, 0.8, 0.8, 1.0)
	elif ratio <= 0.30:
		_set_progress_fill_color(bar, Color(0.92, 0.18, 0.18, 0.95))
		label.modulate = Color(1.0, 0.85, 0.85, 1.0)
	else:
		_set_progress_fill_color(bar, Color(0.18, 0.82, 0.32, 0.95))
		label.modulate = Color(1, 1, 1, 1)

func bind(u: Unit, _is_left: bool) -> void:
	unit = u
	is_left = _is_left
	_apply_side_layout()
	_apply_sprite()
	update_ui()

func _apply_side_layout() -> void:
	# Игрок: полоски снизу. Враг: полоски сверху.
	bars_bottom.visible = is_left
	bars_top.visible = not is_left

func _apply_sprite() -> void:
	if unit == null:
		sprite.texture = null
		return

	sprite.texture = unit.data.battle_texture

	# Зеркалим для правой стороны (враг)
	sprite.flip_h = is_left

func update_ui() -> void:
	if unit == null:
		return

	# Выбираем, какие бары активны (сверху или снизу)
	var hp_label: Label = hp_label_bottom if is_left else hp_label_top
	var hp_bar: ProgressBar = hp_bottom if is_left else hp_top
	hp_label.text = "%d / %d" % [unit.hp, unit.max_hp]
	hp_bar.max_value = unit.max_hp
	hp_bar.value = clamp(unit.hp, 0, unit.max_hp)
	_apply_hp_bar_state(hp_bar, hp_label)
	var en_label: Label = en_label_bottom if is_left else en_label_top
	var en_bar: ProgressBar = en_bottom if is_left else en_top
	en_label.text = "%d / %d" % [unit.energy, unit.max_energy]
	en_bar.max_value = unit.max_energy
	en_bar.value = clamp(unit.energy, 0, unit.max_energy)

	update_minimum_size()
