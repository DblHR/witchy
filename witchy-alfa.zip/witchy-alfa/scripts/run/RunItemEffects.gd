extends RefCounted
class_name RunItemEffects

static var _active_battle_items: Array[String] = []

static func on_battle_start(sim) -> void:
	_active_battle_items = DungRun.relics.duplicate()
	if _has_active_item("kebab"):
		for u in sim.left_team:
			if u != null and not u.is_dead:
				u.add_effect(HealTickEffect.new_unscaled(6, 4, 2.0))

	if _has_active_item("jelly"):
		for u in sim.left_team:
			if u != null and not u.is_dead:
				u.add_effect(HasteEffect.new(1.10, 6.0))

	if _has_active_item("apple_pie"):
		for u in sim.left_team:
			if u != null and not u.is_dead:
				u.add_effect(DamageBuffEffect.new(1, 8.0))

	var dango_buffs := _get_dango_buff_count()
	if dango_buffs > 0:
		_apply_dango_buffs(sim.left_team, dango_buffs)

static func _has_active_item(item_id: String) -> bool:
	return _active_battle_items.has(RunItems.normalize_item_id(item_id))

static func modify_basic_attack_damage(attacker: Unit, target: Unit, base_damage: int, attacker_is_left: bool) -> int:
	var dmg := base_damage
	if not attacker_is_left:
		return dmg
	var flat_bonus := 0
	if _has_active_item("mace_staff_common"):
		flat_bonus = max(flat_bonus, 2)
	if _has_active_item("mace_staff_rare"):
		flat_bonus = max(flat_bonus, 4)
	if _has_active_item("mace_staff_legendary"):
		flat_bonus = max(flat_bonus, 6)
	dmg += flat_bonus

	if attacker != null:
		var meme_result := _roll_stick_staff_damage(attacker)
		if meme_result == 0:
			return 0
		dmg *= meme_result

	if DungRun.black_statue_rooms > 0:
		dmg += 2
	return max(0, dmg)

static func after_basic_attack(attacker: Unit, target: Unit, attacker_is_left: bool) -> void:
	if attacker == null or target == null or target.is_dead:
		return
	if not attacker_is_left:
		return
	if _has_active_item("slime_staff_legendary") and DungRun.rng.randf() < 0.35:
		target.add_effect(SlowEffect.new(0.75, 3.0))
		return
	var control_strength := _get_heart_staff_rarity()
	if control_strength < 0:
		return
	var chance = [0.12, 0.18, 0.24][control_strength]
	if DungRun.rng.randf() >= chance:
		return
	if control_strength == 0:
		target.add_effect(SlowEffect.new(0.8, 2.0))
	elif control_strength == 1:
		if DungRun.rng.randf() < 0.5:
			target.add_effect(SlowEffect.new(0.75, 2.5))
		else:
			target.add_effect(CharmEffect.new(1.5))
	else:
		if DungRun.rng.randf() < 0.45:
			target.add_effect(SlowEffect.new(0.70, 3.0))
		else:
			target.add_effect(CharmEffect.new(2.0))

static func on_ally_damaged(unit: Unit) -> void:
	if unit == null or unit.is_dead:
		return
	if _has_active_item("steak") and not DungRun.guardian_cookie_used and unit.hp <= int(floor(unit.max_hp * 0.25)):
		DungRun.guardian_cookie_used = true
		unit.add_effect(HealTickEffect.new_unscaled(24, 4, 0.4))

static func on_enemy_killed(enemy: Unit, room_index: int) -> void:
	var gold_gain := 4 + room_index
	var xp_gain := 6 + room_index * 2
	DungRun.gain_gold(gold_gain)
	DungRun.gain_xp(xp_gain)
	if enemy == null or enemy.data == null:
		return
	if String(enemy.data.id) == "base_slime":
		Inventory_.add_item("slime_goop", 1)
	if DungRun.rng.randf() < 0.10:
		Inventory_.add_item("quartz", 1)

static func on_room_cleared(team: Array[Unit]) -> void:
	DungRun.rooms_cleared += 1
	if DungRun.white_statue_rooms > 0:
		for u in team:
			if u != null and not u.is_dead:
				u.hp = min(u.max_hp, u.hp + int(ceil(u.max_hp * 0.12)))
		DungRun.white_statue_rooms -= 1
	if DungRun.black_statue_rooms > 0:
		DungRun.black_statue_rooms -= 1

static func use_potion(sim, potion_id: String) -> Dictionary:
	match potion_id:
		"heal_potion":
			var target = sim._get_most_wounded_ally(sim.left_team)
			if target == null:
				return {"ok": false, "reason": "Некого лечить"}
			var amount = max(1, int(round(float(target.max_hp) * 0.40)))
			target.hp = min(target.max_hp, target.hp + amount)
			return {"ok": true, "reason": "Зелье слаймов восстановило %d HP" % amount}
		"energy_potion":
			_grant_team_energy(sim.left_team, 2)
			return {"ok": true, "reason": "Команда получила +2 энергии"}
		"battle_potion":
			for u in sim.left_team:
				if u == null or u.is_dead:
					continue
				u.add_effect(DamageBuffEffect.new(2, 4.0))
			return {"ok": true, "reason": "Команда получила временный бафф урона"}
		_:
			return {"ok": false, "reason": "Тип зелья не настроен"}

static func _grant_team_energy(team: Array[Unit], amount: int) -> void:
	for u in team:
		if u == null or u.is_dead:
			continue
		u.energy = min(u.max_energy, u.energy + amount)

static func _get_dango_buff_count() -> int:
	if _has_active_item("dango_staff_legendary"):
		return 3
	if _has_active_item("dango_staff_rare"):
		return 2
	if _has_active_item("dango_staff_common"):
		return 1
	return 0

static func _apply_dango_buffs(team: Array[Unit], buff_count: int) -> void:
	var buff_order := ["damage", "regen", "haste"]
	buff_order.shuffle()
	for i in range(min(buff_count, buff_order.size())):
		var buff_id := String(buff_order[i])
		for u in team:
			if u == null or u.is_dead:
				continue
			match buff_id:
				"damage":
					u.add_effect(DamageBuffEffect.new(2, 8.0))
				"regen":
					u.add_effect(HealTickEffect.new_unscaled(5, 4, 2.0))
				"haste":
					u.add_effect(HasteEffect.new(1.12, 8.0))

static func _get_heart_staff_rarity() -> int:
	if _has_active_item("heart_staff_legendary"):
		return 2
	if _has_active_item("heart_staff_rare"):
		return 1
	if _has_active_item("heart_staff_common"):
		return 0
	return -1

static func _roll_stick_staff_damage(attacker: Unit) -> int:
	if attacker == null:
		return 1
	if _has_active_item("stick_staff_legendary"):
		var roll := DungRun.rng.randf()
		if roll < 0.05:
			return 3
		if roll < 0.25:
			return 2
		if roll < 0.45:
			return 0
		return 1
	if _has_active_item("stick_staff_rare"):
		var roll_rare := DungRun.rng.randf()
		if roll_rare < 0.10:
			return 0
		if roll_rare < 0.20:
			return 2
		return 1
	if _has_active_item("stick_staff_common") and DungRun.rng.randf() < 0.10:
		return 0
	return 1
