extends Control
class_name CurvedTimingMeter

@export_range(0.2, 3.0, 0.05) var cycle_duration: float = 1.0
@export var ring_color: Color = Color(0.95, 0.90, 0.82, 0.22)
@export var target_color: Color = Color(0.92, 0.68, 0.38, 0.92)
@export var needle_color: Color = Color(0.82, 0.70, 0.96, 1.0)

var _running: bool = false
var _progress: float = 0.0
var _target_center: float = 0.5
var _target_width: float = 0.24

func _ready() -> void:
	set_process(false)
	queue_redraw()

func start() -> void:
	_running = true
	set_process(true)

func stop() -> void:
	_running = false
	set_process(false)
	queue_redraw()

func restart(reset_progress: bool = false) -> void:
	if reset_progress:
		_progress = 0.0
	start()

func reset_target(center: float, width: float) -> void:
	_target_center = clampf(center, 0.08, 0.92)
	_target_width = clampf(width, 0.08, 0.45)
	queue_redraw()

func submit_result() -> Dictionary:
	var distance := absf(_progress - _target_center)
	var success := distance <= (_target_width * 0.5)
	var accuracy := 1.0 - clampf(distance / maxf(_target_width * 0.5, 0.001), 0.0, 1.0)
	return {
		"success": success,
		"accuracy": accuracy,
	}

func _process(delta: float) -> void:
	if not _running:
		return
	_progress = fposmod(_progress + (delta / maxf(cycle_duration, 0.01)), 1.0)
	queue_redraw()

func _draw() -> void:
	var center := size * 0.5
	var radius := minf(size.x, size.y) * 0.34
	var width := maxf(minf(size.x, size.y) * 0.07, 10.0)
	var start_angle := -PI * 0.92
	var arc_len := PI * 0.84
	var end_angle := start_angle + arc_len

	draw_arc(center, radius, start_angle, end_angle, 72, ring_color, width, true)

	var target_start := start_angle + arc_len * clampf(_target_center - (_target_width * 0.5), 0.0, 1.0)
	var target_end := start_angle + arc_len * clampf(_target_center + (_target_width * 0.5), 0.0, 1.0)
	draw_arc(center, radius, target_start, target_end, 36, target_color, width, true)

	var needle_angle := start_angle + arc_len * _progress
	var needle_tip := center + Vector2(cos(needle_angle), sin(needle_angle)) * (radius + width * 0.1)
	draw_line(center, needle_tip, needle_color, maxf(width * 0.28, 5.0), true)
	draw_circle(center, maxf(width * 0.26, 8.0), Color(0.10, 0.08, 0.13, 0.9))
	draw_circle(needle_tip, maxf(width * 0.18, 6.0), needle_color)
