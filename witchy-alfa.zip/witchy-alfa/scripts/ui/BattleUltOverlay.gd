extends CanvasLayer
class_name BattleUltOverlay

signal animation_finished(unit: Unit)

@export var icon_size: Vector2 = Vector2(1500.0, 1650.0)
@export var start_center_position: Vector2 = Vector2(-220.0, 460.0)
@export var end_center_position: Vector2 = Vector2(220.0, 460.0)
@export var fade_in_duration: float = 0.26
@export var move_duration: float = 0.65
@export var hold_duration: float = 0.18
@export var fade_out_duration: float = 0.18
@export var easing: Tween.EaseType = Tween.EASE_OUT
@export var transition: Tween.TransitionType = Tween.TRANS_CUBIC

@onready var blocker: Control = get_node_or_null("Blocker") as Control
@onready var portrait_rect: TextureRect = get_node_or_null("Blocker/PortraitRect") as TextureRect

var _active_tween: Tween
var _is_playing: bool = false
var _current_unit: Unit = null

func _ready() -> void:
	visible = false
	layer = 30

	if blocker == null:
		push_error("BattleUltOverlay: узел 'Blocker' не найден.")
		return
	if portrait_rect == null:
		push_error("BattleUltOverlay: узел 'Blocker/PortraitRect' не найден.")
		return

	blocker.mouse_filter = Control.MOUSE_FILTER_IGNORE
	portrait_rect.mouse_filter = Control.MOUSE_FILTER_IGNORE
	portrait_rect.pivot_offset = icon_size * 0.5
	portrait_rect.size = icon_size
	_reset_visuals()

func is_playing() -> bool:
	return _is_playing

func play_for_unit(unit: Unit) -> void:
	if unit == null or unit.data == null:
		return
	if blocker == null or portrait_rect == null:
		push_warning("BattleUltOverlay: overlay не инициализирован, анимация пропущена.")
		animation_finished.emit(unit)
		return

	var texture := _resolve_texture(unit)
	if texture == null:
		push_warning("BattleUltOverlay: не найдена карточка для ульты %s" % unit.data.display_name)
		animation_finished.emit(unit)
		return

	if _active_tween != null:
		_active_tween.kill()

	_current_unit = unit
	_is_playing = true
	visible = true
	blocker.mouse_filter = Control.MOUSE_FILTER_STOP
	portrait_rect.texture = texture
	portrait_rect.size = icon_size
	portrait_rect.pivot_offset = icon_size * 0.5
	portrait_rect.position = start_center_position - icon_size * 0.5
	portrait_rect.modulate = Color(1, 1, 1, 0)

	_active_tween = create_tween()
	_active_tween.set_parallel(true)
	_active_tween.set_ease(easing)
	_active_tween.set_trans(transition)
	_active_tween.tween_property(portrait_rect, "position", end_center_position - icon_size * 0.5, move_duration)
	_active_tween.tween_property(portrait_rect, "modulate:a", 1.0, fade_in_duration)
	_active_tween.set_parallel(false)
	_active_tween.tween_interval(hold_duration)
	_active_tween.tween_property(portrait_rect, "modulate:a", 0.0, fade_out_duration)
	_active_tween.finished.connect(_finish_animation)

func _resolve_texture(unit: Unit) -> Texture2D:
	if unit == null or unit.data == null:
		return null
	if unit.data.card_portrait != null:
		return unit.data.card_portrait
	return unit.data.battle_texture

func _finish_animation() -> void:
	if blocker == null or portrait_rect == null:
		var fallback_unit := _current_unit
		_current_unit = null
		_is_playing = false
		visible = false
		animation_finished.emit(fallback_unit)
		return

	_reset_visuals()
	var finished_unit := _current_unit
	_current_unit = null
	_is_playing = false
	blocker.mouse_filter = Control.MOUSE_FILTER_IGNORE
	visible = false
	animation_finished.emit(finished_unit)

func _reset_visuals() -> void:
	if portrait_rect == null:
		return
	portrait_rect.size = icon_size
	portrait_rect.pivot_offset = icon_size * 0.5
	portrait_rect.position = start_center_position - icon_size * 0.5
	portrait_rect.modulate = Color(1, 1, 1, 0)
