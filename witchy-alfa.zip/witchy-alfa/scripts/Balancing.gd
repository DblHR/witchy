# res://scripts/Balancing.gd
extends Node
class_name Balancing

const HP_MULT: float = 9.0
const DMG_MULT: float = 6.0
const APS_MULT_GLOBAL: float = 0.7

# Для плоских значений в шагах (ability amount, heal_per_tick и т.д.)
static func scale_hp(v: int) -> int:
	return int(round(v * HP_MULT))

static func scale_damage(v: int) -> int:
	return int(round(v * DMG_MULT))

static func scale_aps(v: float) -> float:
	return v * APS_MULT_GLOBAL
