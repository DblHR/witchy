extends Control
class_name EventRoom

@onready var background: TextureRect = %Background
@onready var title_label: Label = %TitleLabel
@onready var desc_label: Label = %DescLabel
@onready var continue_button: Button = %ContinueButton
@onready var npc_sprite: TextureRect = %NpcSprite
@onready var option_buttons: Array[Button] = [%OptionButton0, %OptionButton1, %OptionButton2, %OptionButton3]
@onready var choice_overlay: Control = %ChoiceOverlay
@onready var choice_image: TextureRect = %ChoiceImage

var _showing_intro := false
var _chest_waiting_click := false
var _chest_open_message := ""
var _chest_animating := false
var _shop_grid: GridContainer
var _pending_dialogue: Dictionary = {}
var _quest_battle_start_pending := false

func _ready() -> void:
	UIThemeHelper.apply_pink_theme(self)
	background.mouse_filter = Control.MOUSE_FILTER_IGNORE
	title_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	desc_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	npc_sprite.mouse_filter = Control.MOUSE_FILTER_IGNORE
	continue_button.mouse_filter = Control.MOUSE_FILTER_STOP
	_build_shop_grid()
	var room := DungRun.get_current_room()
	if room == null or room.room_type != RoomParams.RoomType.EVENT:
		SceneRouter_.go_to_battle()
		return
	choice_overlay.visible = false
	continue_button.visible = true
	_apply_presentation(room)
	if not continue_button.pressed.is_connected(_on_continue_pressed):
		continue_button.pressed.connect(_on_continue_pressed)
	for i in range(option_buttons.size()):
		var call := Callable(self, "_on_option_pressed").bind(i)
		if not option_buttons[i].pressed.is_connected(call):
			option_buttons[i].pressed.connect(call)
	call_deferred("_begin_intro_or_refresh", room)

func _build_shop_grid() -> void:
	if _shop_grid != null:
		return
	_shop_grid = GridContainer.new()
	_shop_grid.columns = 4
	_shop_grid.visible = false
	_shop_grid.offset_left = 120.0
	_shop_grid.offset_top = 560.0
	_shop_grid.offset_right = 1800.0
	_shop_grid.offset_bottom = 870.0
	_shop_grid.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_shop_grid.add_theme_constant_override("h_separation", 14)
	_shop_grid.add_theme_constant_override("v_separation", 14)
	add_child(_shop_grid)
	for i in range(4):
		var button := _create_shop_card_button(i)
		button.visible = false
		button.pressed.connect(_on_option_pressed.bind(i))
		_shop_grid.add_child(button)

func _create_shop_card_button(slot_idx: int) -> Button:
	var button := Button.new()
	button.name = "ShopCard%d" % slot_idx
	button.custom_minimum_size = Vector2(250, 220)
	button.clip_contents = true
	var box := VBoxContainer.new()
	box.name = "Content"
	box.mouse_filter = Control.MOUSE_FILTER_IGNORE
	box.anchors_preset = Control.PRESET_FULL_RECT
	box.offset_left = 12
	box.offset_top = 12
	box.offset_right = -12
	box.offset_bottom = -12
	box.alignment = BoxContainer.ALIGNMENT_CENTER
	box.add_theme_constant_override("separation", 8)
	button.add_child(box)
	var icon := TextureRect.new()
	icon.name = "Icon"
	icon.custom_minimum_size = Vector2(110, 110)
	icon.expand_mode = TextureRect.EXPAND_FIT_WIDTH_PROPORTIONAL
	icon.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	icon.mouse_filter = Control.MOUSE_FILTER_IGNORE
	box.add_child(icon)
	var title := Label.new()
	title.name = "Title"
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	title.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	title.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	title.mouse_filter = Control.MOUSE_FILTER_IGNORE
	title.add_theme_font_size_override("font_size", 20)
	box.add_child(title)
	var price := Label.new()
	price.name = "Price"
	price.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	price.mouse_filter = Control.MOUSE_FILTER_IGNORE
	price.add_theme_font_size_override("font_size", 22)
	box.add_child(price)
	return button

func _apply_presentation(room: RoomParams) -> void:
	if AssetCatalog_ != null:
		var bg := AssetCatalog_.get_event_background(room.event_type, room.statue_variant)
		if bg != null:
			background.texture = bg
	_refresh_npc_sprite(room)

func _refresh_npc_sprite(room: RoomParams) -> void:
	if npc_sprite == null:
		return
	npc_sprite.mouse_filter = Control.MOUSE_FILTER_IGNORE
	npc_sprite.texture = null
	npc_sprite.visible = false
	npc_sprite.z_index = 2
	npc_sprite.anchor_left = 0.0
	npc_sprite.anchor_top = 0.0
	npc_sprite.anchor_right = 0.0
	npc_sprite.anchor_bottom = 0.0
	npc_sprite.offset_left = 1097.0
	npc_sprite.offset_top = 306.0
	npc_sprite.offset_right = 1757.0
	npc_sprite.offset_bottom = 1106.0
	npc_sprite.expand_mode = TextureRect.EXPAND_FIT_WIDTH_PROPORTIONAL
	npc_sprite.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED

	# NPC in shops/healing are already baked into the room background.
	# Chest is a full illustration with background, so it intentionally fills the screen.
	if room.event_type == RoomParams.EventType.CHEST:
		npc_sprite.texture = _get_npc_texture(room)
		npc_sprite.visible = npc_sprite.texture != null
		npc_sprite.anchor_left = 0.0
		npc_sprite.anchor_top = 0.0
		npc_sprite.anchor_right = 1.0
		npc_sprite.anchor_bottom = 1.0
		npc_sprite.offset_left = 0.0
		npc_sprite.offset_top = 0.0
		npc_sprite.offset_right = 0.0
		npc_sprite.offset_bottom = 0.0
		npc_sprite.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
		npc_sprite.stretch_mode = TextureRect.STRETCH_SCALE
	elif room.event_type == RoomParams.EventType.STATUE:
		npc_sprite.texture = _get_npc_texture(room)
		npc_sprite.visible = npc_sprite.texture != null

func _begin_intro_or_refresh(room: RoomParams) -> void:
	_showing_intro = false
	_pending_dialogue = {}
	if room.event_type == RoomParams.EventType.SHOP and room.event_npc_id == "lamia" and StoryState_ != null and not room.used:
		StoryState_.add_counter("lamia_visits", 1)
	var dialogue_lines: Array = []
	if StoryDialogueDB_ != null:
		if room.event_type == RoomParams.EventType.QUEST:
			_pending_dialogue = StoryDialogueDB_.pick_quest_room_dialogue(room.quest_id)
		else:
			_pending_dialogue = StoryDialogueDB_.pick_intro_for_event(room.event_type, room.statue_variant, room.event_npc_id)
		if not _pending_dialogue.is_empty():
			dialogue_lines = StoryDialogueDB_.resolve_lines(_pending_dialogue)
	if dialogue_lines.is_empty() and EventPresentationDB_ != null:
		var intro_lines: Array[String] = EventPresentationDB_.get_intro_lines(room)
		var portrait := _get_npc_texture(room)
		for line in intro_lines:
			dialogue_lines.append({
				"speaker_name": _make_title(room),
				"text": String(line),
				"center_portrait": portrait,
			})
	if dialogue_lines.is_empty():
		_refresh(room)
		return
	_showing_intro = true
	for b in option_buttons:
		b.visible = false
		b.disabled = true
	if _shop_grid != null:
		_shop_grid.visible = false
	title_label.text = _make_title(room)
	desc_label.text = ""
	continue_button.visible = false
	DialogueManager_.show_sequence(dialogue_lines, Callable(self, "_on_intro_dialogue_finished"))

func _on_intro_dialogue_finished() -> void:
	var room := DungRun.get_current_room()
	_showing_intro = false
	if not _pending_dialogue.is_empty() and StoryDialogueDB_ != null:
		var dialogue_id := String(_pending_dialogue.get("id", ""))
		if dialogue_id != "" and StoryState_ != null:
			StoryState_.mark_dialogue_seen(dialogue_id)
		var effects = _pending_dialogue.get("on_finish", {})
		StoryDialogueDB_.apply_effects(effects)
		if room != null and room.event_type == RoomParams.EventType.QUEST:
			room.used = true
			if effects is Dictionary and bool(effects.get("start_quest_battle", false)):
				_quest_battle_start_pending = true
	_pending_dialogue = {}
	if room == null:
		return
	if _quest_battle_start_pending:
		_quest_battle_start_pending = false
		room.room_type = RoomParams.RoomType.BATTLE
		SceneRouter_.go_to_battle()
		return
	_refresh(room)

func _gui_input(event: InputEvent) -> void:
	if choice_overlay.visible:
		if event is InputEventMouseButton and event.pressed and event.button_index == MOUSE_BUTTON_LEFT:
			_hide_choice_overlay()
			accept_event()
		elif event is InputEventScreenTouch and event.pressed:
			_hide_choice_overlay()
			accept_event()
		return

	if not _chest_waiting_click or _chest_animating:
		return
	if event is InputEventMouseButton and event.pressed and event.button_index == MOUSE_BUTTON_LEFT:
		_open_chest_now()
		accept_event()
	elif event is InputEventScreenTouch and event.pressed:
		_open_chest_now()
		accept_event()

func _get_npc_texture(room: RoomParams) -> Texture2D:
	if AssetCatalog_ == null:
		return null
	match room.event_type:
		RoomParams.EventType.SHOP:
			var npc_id := room.event_npc_id if room.event_npc_id != "" else "lamia"
			var tex := AssetCatalog_.get_event_npc_texture(npc_id)
			return tex if tex != null else AssetCatalog_.get_event_npc_texture("shop")
		RoomParams.EventType.NURSE:
			return AssetCatalog_.get_event_npc_texture("nurse")
		RoomParams.EventType.CHEST:
			return AssetCatalog_.get_event_npc_texture("opened_chest") if room.used else AssetCatalog_.get_event_npc_texture("chest")
		RoomParams.EventType.STATUE:
			return AssetCatalog_.get_event_npc_texture("statue_white") if room.statue_variant == RoomParams.StatueVariant.WHITE else AssetCatalog_.get_event_npc_texture("statue_black")
		RoomParams.EventType.QUEST:
			return null
		_:
			return null

func _refresh(room: RoomParams) -> void:
	_showing_intro = false
	_chest_waiting_click = false
	_chest_animating = false
	_chest_open_message = ""
	continue_button.visible = true
	continue_button.text = "ДАЛЬШЕ"
	title_label.visible = true
	desc_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_LEFT
	desc_label.vertical_alignment = VERTICAL_ALIGNMENT_TOP
	desc_label.offset_left = 120.0
	desc_label.offset_top = 180.0
	desc_label.offset_right = 980.0
	desc_label.offset_bottom = 520.0
	continue_button.offset_left = 120.0
	continue_button.offset_top = 947.0
	continue_button.offset_right = 420.0
	continue_button.offset_bottom = 1015.0
	continue_button.z_index = 100
	continue_button.mouse_filter = Control.MOUSE_FILTER_STOP
	_refresh_npc_sprite(room)
	for b in option_buttons:
		b.visible = false
		b.disabled = false
		b.text = ""
	if _shop_grid != null:
		_shop_grid.visible = false
		for c in _shop_grid.get_children():
			(c as Button).visible = false
	title_label.text = _make_title(room)
	desc_label.text = _make_desc(room)
	match room.event_type:
		RoomParams.EventType.NURSE:
			_setup_nurse(room)
		RoomParams.EventType.CHEST:
			_setup_chest(room)
		RoomParams.EventType.STATUE:
			_setup_statue(room)
		RoomParams.EventType.SHOP:
			_setup_shop(room)
		RoomParams.EventType.QUEST:
			_setup_quest(room)
	continue_button.disabled = choice_overlay.visible

func _make_title(room: RoomParams) -> String:
	match room.event_type:
		RoomParams.EventType.SHOP:
			return "Тихая лавка ламии"
		RoomParams.EventType.NURSE: return "Медсестра"
		RoomParams.EventType.CHEST: return "Сундук"
		RoomParams.EventType.STATUE:
			return "Белая статуя" if room.statue_variant == RoomParams.StatueVariant.WHITE else "Чёрная статуя"
		RoomParams.EventType.QUEST:
			return "???"
		_: return "Событие"

func _make_desc(room: RoomParams) -> String:
	var relics_text := "нет"
	if not DungRun.relics.is_empty():
		relics_text = ", ".join(DungRun.get_relic_names())
	var meta := "Gold: %d | LV %d | XP %d/%d\nРеликвии: %s\nСемечки: %d" % [
		DungRun.gold,
		DungRun.party_level,
		DungRun.xp,
		DungRun.xp_to_next_level(),
		relics_text,
		Inventory_.get_item_count("slimeflower_seed"),
	]
	match room.event_type:
		RoomParams.EventType.NURSE:
			return meta + "\nЛечит самого раненого, воскрешает первого мёртвого и пополняет эстус за золото. За заход можно выбрать только одну услугу."
		RoomParams.EventType.CHEST:
			return "Нажмите на экран, чтобы открыть сундук."
		RoomParams.EventType.STATUE:
			if room.statue_variant == RoomParams.StatueVariant.WHITE:
				return meta + "\nБелая статуя даст после-комнатное лечение на несколько следующих побед."
			return meta + "\nЧёрная статуя усилит урон с руки на несколько следующих побед."
		RoomParams.EventType.SHOP:
			return meta + "\nПодземная лавка: 4 лота, кварц и расходники встречаются чаще."
		RoomParams.EventType.QUEST:
			return meta + "\nОсобая сюжетная комната. Диалог уже изменил состояние истории."
		_:
			return meta

func _setup_nurse(room: RoomParams) -> void:
	_show_option(0, "Подлечить самого раненого (18g)")
	_show_option(1, "Воскресить союзника (40g)")
	_show_option(2, "Пополнить 1 заряд эстуса (22g)")
	for i in range(3):
		option_buttons[i].disabled = room.used

func _setup_chest(room: RoomParams) -> void:
	for b in option_buttons:
		b.visible = false
		b.disabled = true
	title_label.visible = false
	desc_label.visible = true
	desc_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	desc_label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	desc_label.offset_left = 220.0
	desc_label.offset_top = 720.0
	desc_label.offset_right = 1700.0
	desc_label.offset_bottom = 900.0
	desc_label.z_index = 20
	if room.used:
		desc_label.text = _chest_open_message if _chest_open_message != "" else "Сундук уже открыт."
		continue_button.visible = true
		continue_button.text = "ИДТИ ДАЛЬШЕ"
		continue_button.offset_left = 760.0
		continue_button.offset_right = 1160.0
		return
	continue_button.visible = false
	_chest_waiting_click = true
	desc_label.text = "Нажмите на экран, чтобы открыть сундук."

func _setup_statue(room: RoomParams) -> void:
	if room.used:
		continue_button.text = "ИДТИ ДАЛЬШЕ"
		return
	_show_option(0, "Принять дар")
	option_buttons[0].disabled = false

func _setup_quest(room: RoomParams) -> void:
	for b in option_buttons:
		b.visible = false
		b.disabled = true
	continue_button.visible = true
	continue_button.text = "ИДТИ ДАЛЬШЕ"
	desc_label.text = "???"

func _setup_shop(room: RoomParams) -> void:
	continue_button.text = "ИДТИ ДАЛЬШЕ"
	if _shop_grid == null:
		return
	_shop_grid.visible = true
	for i in range(_shop_grid.get_child_count()):
		var button := _shop_grid.get_child(i) as Button
		button.visible = true
		if i >= room.shop_item_ids.size() or room.shop_item_ids[i] == "":
			_populate_shop_card(button, "", null, 0, "", true)
			continue
		var id := room.shop_item_ids[i]
		var price := RunItems.get_item_price(id)
		var disabled := room.used or DungRun.gold < price or (RunItems.is_unique_item(id) and Inventory_ != null and Inventory_.has_item(id))
		_populate_shop_card(button, RunItems.get_item_name(id), Inventory_.get_item_icon(id) if Inventory_ != null else null, price, "%s\n[%s]\n%s" % [RunItems.get_item_name(id), RunItems.get_item_kind_label(id), RunItems.get_item_desc(id)], disabled)

func _populate_shop_card(button: Button, title_text: String, icon_tex: Texture2D, price: int, tooltip: String, disabled: bool) -> void:
	var box := button.get_node("Content") as VBoxContainer
	var icon := box.get_node("Icon") as TextureRect
	var title := box.get_node("Title") as Label
	var price_label := box.get_node("Price") as Label
	button.tooltip_text = tooltip
	button.disabled = disabled
	icon.texture = icon_tex
	title.text = "Пусто" if title_text == "" else title_text
	price_label.text = "" if title_text == "" else "%dg" % price

func _show_option(idx: int, text: String) -> void:
	option_buttons[idx].visible = true
	option_buttons[idx].text = text

func _on_option_pressed(idx: int) -> void:
	var room := DungRun.get_current_room()
	if room == null or choice_overlay.visible or _showing_intro or _chest_waiting_click:
		return
	match room.event_type:
		RoomParams.EventType.NURSE:
			_handle_nurse(room, idx)
		RoomParams.EventType.CHEST:
			_handle_chest(room)
		RoomParams.EventType.STATUE:
			_handle_statue(room)
		RoomParams.EventType.SHOP:
			_handle_shop(room, idx)
		RoomParams.EventType.QUEST:
			pass
	_refresh(room)

func _handle_nurse(room: RoomParams, idx: int) -> void:
	if room.used:
		return
	match idx:
		0:
			if not DungRun.spend_gold(18):
				desc_label.text = "Не хватает золота."
				return
			if _heal_most_wounded_party_member():
				room.used = true
				desc_label.text = "Медсестра привела самого раненого союзника в порядок."
				_show_choice_overlay("nurse_heal")
			else:
				DungRun.gain_gold(18)
				desc_label.text = "Лечить некого."
		1:
			if not DungRun.spend_gold(40):
				desc_label.text = "Не хватает золота."
				return
			if _revive_first_dead_party_member():
				room.used = true
				desc_label.text = "Один союзник воскрешён."
				_show_choice_overlay("nurse_revive")
			else:
				DungRun.gain_gold(40)
				desc_label.text = "Мёртвых союзников нет."
		2:
			if not DungRun.spend_gold(22):
				desc_label.text = "Не хватает золота."
				return
			DungRun.estus_charges = min(DungRun.estus_max_charges, DungRun.estus_charges + 1)
			room.used = true
			desc_label.text = "Фляга эстуса пополнена."
			_show_choice_overlay("nurse_estus")

func _show_choice_overlay(key: String) -> void:
	choice_image.texture = AssetCatalog_.get_event_choice_texture(key) if AssetCatalog_ != null else null
	choice_overlay.visible = true
	continue_button.disabled = true

func _hide_choice_overlay() -> void:
	choice_overlay.visible = false
	continue_button.disabled = false

func _roll_chest_rewards(room: RoomParams) -> String:
	var guaranteed_gold := 12 + room.index * 5
	DungRun.gain_gold(guaranteed_gold)
	var lines: Array[String] = ["В сундуке было %d золота." % guaranteed_gold]
	if StoryState_ != null and StoryState_.is_quest_active("lamia_headphones") and Inventory_ != null and not Inventory_.has_item("warm_headphones"):
		if DungRun.rng.randf() < 0.18:
			Inventory_.add_item("warm_headphones", 1)
			lines.append("Между монетами лежали тёплые наушники.")
	if DungRun.rng.randf() < 0.80:
		var loot_roll := DungRun.rng.randf()
		if loot_roll < 0.45:
			var quartz_amount := DungRun.rng.randi_range(1, 3)
			Inventory_.add_item("quartz", quartz_amount)
			lines.append("Доп. лут: кварц ×%d." % quartz_amount)
		elif loot_roll < 0.75:
			var seed_amount := DungRun.rng.randi_range(1, 3)
			Inventory_.add_item("slimeflower_seed", seed_amount)
			lines.append("Доп. лут: семечки ×%d." % seed_amount)
		else:
			var extra_ids := RunItems.random_item_ids(DungRun.rng, 1, DungRun.get_owned_unique_artifacts() + DungRun.relics)
			if not extra_ids.is_empty():
				var item_id := extra_ids[0]
				if RunItems.is_unique_item(item_id):
					if Inventory_ != null and not Inventory_.has_item(item_id):
						# Artifacts found during a run go to inventory only.
						# They become active relics only when selected before a new run.
						DungRun.add_owned_artifact(item_id)
						lines.append("Доп. лут: %s." % RunItems.get_item_name(item_id))
				else:
					Inventory_.add_item(item_id, 1)
					lines.append("Доп. лут: %s." % RunItems.get_item_name(item_id))
	return "\n".join(lines)

func _open_chest_now() -> void:
	var room := DungRun.get_current_room()
	if room == null or room.event_type != RoomParams.EventType.CHEST or room.used or _chest_animating:
		return
	room.used = true
	_chest_waiting_click = false
	_chest_animating = true
	desc_label.text = ""
	continue_button.visible = false
	_refresh_npc_sprite(room)
	await get_tree().create_timer(1.0).timeout
	_chest_open_message = _roll_chest_rewards(room)
	desc_label.text = _chest_open_message
	desc_label.offset_top = 630.0
	desc_label.offset_bottom = 820.0
	continue_button.visible = true
	continue_button.text = "ИДТИ ДАЛЬШЕ"
	continue_button.offset_left = 760.0
	continue_button.offset_right = 1160.0
	continue_button.offset_top = 860.0
	continue_button.offset_bottom = 940.0
	continue_button.z_index = 25
	_chest_animating = false

func _handle_chest(room: RoomParams) -> void:
	if room.used:
		continue_button.text = "ИДТИ ДАЛЬШЕ"
		return
	_open_chest_now()

func _handle_statue(room: RoomParams) -> void:
	if room.used:
		return
	room.used = true
	if room.statue_variant == RoomParams.StatueVariant.WHITE:
		DungRun.white_statue_rooms += 3
		desc_label.text = "Белая статуя благословила отхилом на 3 следующие победы."
	else:
		DungRun.black_statue_rooms += 3
		desc_label.text = "Чёрная статуя усилила урон с руки на 3 следующие победы."

func _handle_shop(room: RoomParams, idx: int) -> void:
	continue_button.text = "ИДТИ ДАЛЬШЕ"
	if idx < 0 or idx >= room.shop_item_ids.size():
		return
	var item_id := room.shop_item_ids[idx]
	if item_id == "":
		return
	var price := RunItems.get_item_price(item_id)
	if not DungRun.spend_gold(price):
		desc_label.text = "Не хватает золота."
		return
	if RunItems.is_unique_item(item_id) and Inventory_ != null and Inventory_.has_item(item_id):
		DungRun.gain_gold(price)
		desc_label.text = "Этот предмет уже куплен."
		return
	var added_ok := false
	if RunItems.is_unique_item(item_id):
		# Artifacts bought during a run go to inventory only.
		# They become active relics only when selected before a new run.
		DungRun.add_owned_artifact(item_id)
		added_ok = Inventory_ != null and Inventory_.has_item(item_id)
	else:
		added_ok = Inventory_ != null and Inventory_.add_item(item_id, 1)
	if not added_ok:
		DungRun.gain_gold(price)
		desc_label.text = "Не удалось добавить предмет в инвентарь."
		return
	room.shop_item_ids[idx] = ""
	desc_label.text = "Куплено: %s" % RunItems.get_item_name(item_id)

func _get_party_member_max_hp(slot_index: int) -> int:
	if slot_index < 0 or slot_index >= DungRun.party_ids.size():
		return 0
	var data = CharDB.get_by_id(DungRun.party_ids[slot_index])
	if data == null:
		return 0
	var base_max_hp := int(data.stats_for_level(DungRun.party_level).get("max_hp", data.base_hp))
	return base_max_hp

func _heal_most_wounded_party_member() -> bool:
	if DungRun.party_state.is_empty():
		return false
	var best_idx := -1
	var best_ratio := 999.0
	for i in range(min(4, DungRun.party_state.size())):
		var entry = DungRun.party_state[i]
		if not (entry is Dictionary):
			continue
		if bool(entry.get("dead", false)):
			continue
		var max_hp := _get_party_member_max_hp(i)
		if max_hp <= 0:
			continue
		var hp := int(entry.get("hp", max_hp))
		var ratio := float(hp) / maxf(1.0, float(max_hp))
		if ratio < best_ratio:
			best_ratio = ratio
			best_idx = i
	if best_idx == -1:
		return false
	var entry: Dictionary = DungRun.party_state[best_idx]
	var max_hp := _get_party_member_max_hp(best_idx)
	if max_hp <= 0:
		return false
	entry["hp"] = min(max_hp, int(entry.get("hp", max_hp)) + int(round(max_hp * 0.45)))
	DungRun.party_state[best_idx] = entry
	DungRun.emit_changed()
	return true

func _revive_first_dead_party_member() -> bool:
	if DungRun.party_state.is_empty():
		return false
	for i in range(min(4, DungRun.party_state.size())):
		var entry = DungRun.party_state[i]
		if not (entry is Dictionary):
			continue
		if not bool(entry.get("dead", false)):
			continue
		var max_hp := _get_party_member_max_hp(i)
		if max_hp <= 0:
			continue
		entry["dead"] = false
		entry["hp"] = max(1, int(round(max_hp * 0.35)))
		entry["energy"] = 0
		DungRun.party_state[i] = entry
		DungRun.emit_changed()
		return true
	return false

func _on_continue_pressed() -> void:
	if choice_overlay.visible:
		_hide_choice_overlay()
		return
	var room := DungRun.get_current_room()
	if room == null:
		SceneRouter_.go_to_setup()
		return
	if _showing_intro:
		return
	if _chest_waiting_click:
		return
	DungRun.prepare_next_choices()
	if DungRun.has_pending_choices():
		SceneRouter_.go_to_room_choice()
		return
	DungRun.advance_room()
	if DungRun.is_finished():
		SceneRouter_.go_to_setup()
	else:
		SceneRouter_.go_to_battle()
