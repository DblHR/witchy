extends StatusEffect
class_name HealTickEffect

var amount: int
var ticks_left: int
var interval: float
var _accum: float = 0.0

func _init(heal_amount: int, ticks: int, tick_interval: float = 1.0) -> void:
	amount = heal_amount
	ticks_left = ticks
	interval = tick_interval
	# Делаем "вечную" длительность, а завершение контролируем сами через ticks_left.
	duration = 999999.0
	time_left = duration
	icon = load("res://ui/status_icons/heal.png")
	if ui_name == "":
		ui_name = "Regen"
	


func on_apply(unit: Unit) -> void:
	if ticks_left <= 0:
		# сразу помечаем завершение
		time_left = 0.0
		return

func update(unit: Unit, delta: float) -> void:
	if ticks_left <= 0:
		time_left = 0.0
		return

	# safety: интервал <=0 не должен попадать в обычный тик
	if interval <= 0.0:
		while ticks_left > 0:
			_apply_tick(unit)
		return

	_accum += delta
	while _accum >= interval and ticks_left > 0:
		_accum -= interval
		_apply_tick(unit)

	if ticks_left <= 0:
		time_left = 0.0

func _apply_tick(unit: Unit) -> void:
	if unit.is_dead:
		ticks_left = 0
		return
	unit.hp = min(unit.hp + amount, unit.max_hp)
	ticks_left -= 1


static func new_unscaled(heal_amount: int, ticks: int, tick_interval: float = 1.0) -> HealTickEffect:
	var eff := HealTickEffect.new(1, 1, tick_interval)
	eff.amount = heal_amount
	eff.ticks_left = ticks
	eff.interval = tick_interval
	eff.duration = 999999.0
	eff.time_left = eff.duration
	return eff
