extends StatusEffect
class_name DamageBuffEffect

var flat_bonus: int = 0

func _init(flat_bonus_: int = 1, duration_: float = 5.0) -> void:
	ui_name = "Усиление урона"
	duration = duration_
	time_left = duration_
	flat_bonus = flat_bonus_
	icon = load("res://ui/status_icons/damage_buff.png")

func on_before_attack(_attacker: Unit, _target: Unit, damage: int) -> int:
	return damage + flat_bonus
