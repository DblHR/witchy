extends StatusEffect
class_name HasteEffect

var speed_multiplier: float = 1.10

func _init(speed_multiplier_: float = 1.10, duration_: float = 5.0, ui_name_: String = "") -> void:
	ui_name = "Ускорение" if ui_name_ == "" else ui_name_
	duration = duration_
	time_left = duration_
	speed_multiplier = speed_multiplier_
	icon = load("res://ui/status_icons/haste.png")

func on_apply(unit: Unit) -> void:
	unit.aps_mult *= speed_multiplier

func on_expire(unit: Unit) -> void:
	unit.aps_mult /= max(0.001, speed_multiplier)
