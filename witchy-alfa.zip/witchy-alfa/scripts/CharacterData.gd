extends Resource
class_name CharacterData

@export var id: String
@export var display_name: String
@export_enum("воин", "маг", "саппорт", "танк", "рядовой враг", "босс") var unit_class: String = "маг"
@export var tags: Array[String] = []

# Для UI/иконок/спрайтов (пока можно оставить пустым)
@export var icon: Texture2D
@export var battle_texture: Texture2D

# Базовые статы на 1 уровне (или “базовые” для компаньона)
@export var base_hp: int = 10
@export var base_damage: int = 1
@export var base_aps: float = 1.0
@export var max_energy: int = 5

# Рост (упрощённо: прибавка за каждый уровень)
@export var hp_per_level: int = 1
@export var damage_per_level: int = 0
@export var aps_per_level: float = 0.0

@export var battle_scale: float = 0.25
@export var battle_offset_y: float = -500

@export var card_portrait: Texture2D
@export var skill_icon: Texture2D

@export var skill_cost: int = 3
@export var skill_name: String = "Умение"
@export_multiline var codex_description: String = ""
@export_multiline var codex_notes: String = ""

# Data-driven abilities (альфа): если заданы, BattleSim/PlayerCard будут использовать их.
@export var skill_ability: Ability
@export var ult_ability: Ability

# Считает статы для героя/компаньона по уровню
func stats_for_level(level: int) -> Dictionary:
	var lvl: int = maxi(level, 1)
	return {
		"max_hp": int(base_hp + hp_per_level * (lvl - 1)),
		"damage": int(base_damage + damage_per_level * (lvl - 1)),
		"aps": float(base_aps + aps_per_level * (lvl - 1)),
	}
