extends Control

const MAX_SLOT_BUTTONS := 3

@onready var hub: TextureButton = %HomeButton
@onready var farm: TextureButton = %FarmButton
@onready var shop: TextureButton = %ShopButton

@onready var cauldron_art: TextureRect = %CauldronArt
@onready var cauldron_body: PanelContainer = %CauldronBody
@onready var cauldron_button: Button = %CauldronButton
@onready var brew_button: Button = %BrewButton
@onready var brew_status_label: Label = %BrewStatusLabel
@onready var action_panel: PanelContainer = %ActionPanel
@onready var action_info_label: Label = %ActionInfoLabel
@onready var create_potion_button: Button = %CreatePotionButton
@onready var recipe_book_button: Button = %RecipeBookButton
@onready var batch_option: OptionButton = %BatchOption
@onready var status_label: Label = %StatusLabel
@onready var hint_label: Label = %HintLabel
@onready var title_label: Label = %TitleLabel
@onready var subtitle_label: Label = %SubtitleLabel
@onready var slot_buttons: Array[Button] = [%IngredientSlot1, %IngredientSlot2, %IngredientSlot3]

@onready var recipe_popup: PopupPanel = %RecipePopup
@onready var recipe_list: ItemList = %RecipeList
@onready var recipe_popup_title: Label = %RecipePopupTitle
@onready var recipe_popup_body: RichTextLabel = %RecipePopupBody
@onready var recipe_select_button: Button = %RecipeSelectButton
@onready var recipe_popup_close: Button = %RecipePopupCloseButton

@onready var brew_overlay: PanelContainer = %BrewOverlay
@onready var phase_title_label: Label = %PhaseTitleLabel
@onready var phase_hint_label: Label = %PhaseHintLabel
@onready var overlay_result_label: Label = %OverlayResultLabel
@onready var overlay_action_button: Button = %OverlayActionButton
@onready var overlay_cancel_button: Button = %OverlayCancelButton
@onready var timing_meter: CurvedTimingMeter = %TimingMeter
@onready var stirring_minigame: StirringMinigame = %StirringMiniGame

var _selected_recipe_id: String = ""
var _pending_recipe_id: String = ""
var _selected_brew_amount: int = 1
var _brew_phase: String = "idle"
var _cauldron_hovered: bool = false
var _rng: RandomNumberGenerator = RandomNumberGenerator.new()

func _ready() -> void:
	_rng.randomize()
	UIThemeHelper.apply_pink_theme(self)
	hub.pressed.connect(func() -> void: SceneRouter_.go_to_hub())
	farm.pressed.connect(func() -> void: SceneRouter_.go_to_farm())
	shop.pressed.connect(func() -> void: SceneRouter_.go_to_shop())
	cauldron_button.pressed.connect(_toggle_action_panel)
	cauldron_button.mouse_entered.connect(func() -> void:
		_cauldron_hovered = true
		_refresh_cauldron_visual_state()
	)
	cauldron_button.mouse_exited.connect(func() -> void:
		_cauldron_hovered = false
		_refresh_cauldron_visual_state()
	)
	create_potion_button.pressed.connect(_open_recipe_popup)
	recipe_book_button.pressed.connect(_open_recipe_popup)
	recipe_select_button.pressed.connect(_accept_recipe_from_popup)
	recipe_popup_close.pressed.connect(func() -> void: recipe_popup.hide())
	recipe_list.item_selected.connect(_on_recipe_popup_selected)
	recipe_list.item_activated.connect(func(index: int) -> void:
		_on_recipe_popup_selected(index)
		_accept_recipe_from_popup()
	)
	batch_option.item_selected.connect(_on_batch_option_selected)
	brew_button.pressed.connect(_start_brew)
	overlay_action_button.pressed.connect(_on_overlay_action_pressed)
	overlay_cancel_button.pressed.connect(_cancel_brew_overlay)
	stirring_minigame.finished.connect(_on_stirring_finished)
	if Inventory_ != null and not Inventory_.changed.is_connected(_refresh_all):
		Inventory_.changed.connect(_refresh_all)
	_refresh_scene_copy()
	_build_recipe_popup_list()
	if _selected_recipe_id == "":
		var recipe_ids := AlchemyDB.get_recipe_ids()
		if not recipe_ids.is_empty():
			_selected_recipe_id = recipe_ids[0]
	_reset_brew_overlay()
	_refresh_all()

func _exit_tree() -> void:
	if Inventory_ != null and Inventory_.changed.is_connected(_refresh_all):
		Inventory_.changed.disconnect(_refresh_all)

func _unhandled_input(event: InputEvent) -> void:
	if _brew_phase == "timing" and event.is_action_pressed("ui_accept"):
		_attempt_timing_step()

func _refresh_scene_copy() -> void:
	title_label.text = "Алхимия"
	subtitle_label.text = "Сцена варки перенесена в Witchy как рабочая станция: котёл слева, быстрые действия справа, тайминг и помешивание внутри одной сцены."
	hint_label.text = "Выберите рецепт, проверьте ингредиенты и запускайте варку. На успех уходят один тайминг и короткое помешивание."
	create_potion_button.text = "Выбрать рецепт"
	recipe_book_button.text = "Книга рецептов"
	brew_button.text = "Готовить"
	overlay_cancel_button.text = "Отмена"

func _refresh_all() -> void:
	_build_recipe_popup_list()
	_refresh_batch_controls()
	_refresh_slots()
	_refresh_main_copy()
	_refresh_cauldron_visual_state()

func _refresh_main_copy() -> void:
	if _selected_recipe_id == "":
		action_info_label.text = "Выберите рецепт для варки."
		status_label.text = "Рецепт ещё не выбран."
		brew_status_label.text = "Котёл ждёт рецепт."
		brew_button.disabled = true
		return
	var result_item_id := AlchemyDB.get_result_item_id(_selected_recipe_id)
	var recipe_name := AlchemyDB.get_recipe_name(_selected_recipe_id)
	var max_batch := _get_recipe_max_batch(_selected_recipe_id)
	var result_name := RunItems.get_item_name(result_item_id)
	var summary := AlchemyDB.get_recipe_summary(_selected_recipe_id)
	action_info_label.text = "%s → %s\n%s" % [recipe_name, result_name, summary]
	status_label.text = "Выбран рецепт: %s. Доступно варок подряд: ×%d." % [recipe_name, max_batch]
	if max_batch > 0:
		brew_status_label.text = "Готово к варке: %s ×%d." % [result_name, _selected_brew_amount]
	else:
		brew_status_label.text = "Не хватает ингредиентов для «%s»." % recipe_name
	brew_button.disabled = max_batch <= 0
	brew_button.text = "Готовить ×%d" % _selected_brew_amount

func _refresh_slots() -> void:
	var ingredients := _get_selected_recipe_ingredients()
	for index in range(MAX_SLOT_BUTTONS):
		var button := slot_buttons[index]
		if index < ingredients.size():
			var entry: Dictionary = ingredients[index]
			button.disabled = false
			button.icon = Inventory_.get_item_icon(String(entry.get("item_id", ""))) if Inventory_ != null else null
			button.text = "%s\n%d / %d" % [
				RunItems.get_item_name(String(entry.get("item_id", ""))),
				int(entry.get("have", 0)),
				int(entry.get("need", 0)),
			]
		else:
			button.disabled = true
			button.icon = null
			button.text = "Пустой слот"

func _get_selected_recipe_ingredients() -> Array[Dictionary]:
	var out: Array[Dictionary] = []
	if _selected_recipe_id == "":
		return out
	var ingredients := AlchemyDB.get_ingredients(_selected_recipe_id)
	for item_id in ingredients.keys():
		var normalized := String(item_id)
		out.append({
			"item_id": normalized,
			"need": int(ingredients[item_id]),
			"have": Inventory_.get_item_count(normalized) if Inventory_ != null else 0,
		})
	out.sort_custom(func(a: Dictionary, b: Dictionary) -> bool:
		return RunItems.get_item_name(String(a.get("item_id", ""))) < RunItems.get_item_name(String(b.get("item_id", "")))
	)
	return out

func _toggle_action_panel() -> void:
	action_panel.visible = not action_panel.visible
	_refresh_cauldron_visual_state()

func _refresh_cauldron_visual_state() -> void:
	var highlight_active := _cauldron_hovered or action_panel.visible
	cauldron_body.visible = highlight_active
	cauldron_body.modulate = Color(1.0, 0.45, 0.45, 0.44) if highlight_active else Color(1.0, 1.0, 1.0, 1.0)
	cauldron_art.modulate = Color(1.0, 0.78, 0.78, 1.0) if highlight_active else Color(1.0, 1.0, 1.0, 1.0)
	cauldron_button.mouse_default_cursor_shape = Control.CURSOR_POINTING_HAND

func _build_recipe_popup_list() -> void:
	recipe_list.clear()
	var recipe_ids := AlchemyDB.get_recipe_ids()
	for recipe_id in recipe_ids:
		var result_item_id := AlchemyDB.get_result_item_id(recipe_id)
		var label := "%s → %s" % [AlchemyDB.get_recipe_name(recipe_id), RunItems.get_item_name(result_item_id)]
		recipe_list.add_item(label, Inventory_.get_item_icon(result_item_id) if Inventory_ != null else null)
		var idx := recipe_list.item_count - 1
		recipe_list.set_item_metadata(idx, recipe_id)
		if _get_recipe_max_batch(recipe_id) <= 0:
			recipe_list.set_item_disabled(idx, true)
	var selected_index := recipe_ids.find(_selected_recipe_id)
	if selected_index >= 0:
		recipe_list.select(selected_index)
		_on_recipe_popup_selected(selected_index)
	elif recipe_list.item_count > 0:
		recipe_list.select(0)
		_on_recipe_popup_selected(0)

func _open_recipe_popup() -> void:
	_build_recipe_popup_list()
	recipe_popup.popup_centered_ratio(0.45)

func _on_recipe_popup_selected(index: int) -> void:
	var recipe_id := String(recipe_list.get_item_metadata(index))
	recipe_popup_title.text = AlchemyDB.get_recipe_name(recipe_id)
	var result_item_id := AlchemyDB.get_result_item_id(recipe_id)
	var lines: Array[String] = []
	for entry in _get_recipe_entries(recipe_id):
		var marker := "✓" if int(entry.get("have", 0)) >= int(entry.get("need", 0)) else "✗"
		lines.append("%s %s: %d / %d" % [
			marker,
			RunItems.get_item_name(String(entry.get("item_id", ""))),
			int(entry.get("have", 0)),
			int(entry.get("need", 0)),
		])
	recipe_popup_body.text = "[b]Результат:[/b] %s\n[b]Тип:[/b] %s\n[b]Эффект:[/b] %s\n\n[b]Ингредиенты:[/b]\n%s" % [
		RunItems.get_item_name(result_item_id),
		RunItems.get_item_kind_label(result_item_id),
		RunItems.get_item_desc(result_item_id),
		"\n".join(lines),
	]
	recipe_select_button.disabled = recipe_list.is_item_disabled(index)

func _accept_recipe_from_popup() -> void:
	var selected := recipe_list.get_selected_items()
	if selected.is_empty():
		return
	var index := int(selected[0])
	if recipe_list.is_item_disabled(index):
		return
	_selected_recipe_id = String(recipe_list.get_item_metadata(index))
	recipe_popup.hide()
	_refresh_all()

func _get_recipe_entries(recipe_id: String) -> Array[Dictionary]:
	var out: Array[Dictionary] = []
	var ingredients := AlchemyDB.get_ingredients(recipe_id)
	for item_id in ingredients.keys():
		var normalized := String(item_id)
		out.append({
			"item_id": normalized,
			"need": int(ingredients[item_id]),
			"have": Inventory_.get_item_count(normalized) if Inventory_ != null else 0,
		})
	out.sort_custom(func(a: Dictionary, b: Dictionary) -> bool:
		return RunItems.get_item_name(String(a.get("item_id", ""))) < RunItems.get_item_name(String(b.get("item_id", "")))
	)
	return out

func _get_recipe_max_batch(recipe_id: String) -> int:
	if recipe_id == "" or Inventory_ == null:
		return 0
	var ingredients := AlchemyDB.get_ingredients(recipe_id)
	var max_batch := 999999
	for item_id in ingredients.keys():
		var need = max(1, int(ingredients[item_id]))
		var have := Inventory_.get_item_count(String(item_id))
		max_batch = mini(max_batch, int(floor(float(have) / float(need))))
	return maxi(0, max_batch if max_batch != 999999 else 0)

func _refresh_batch_controls() -> void:
	batch_option.clear()
	var max_batch := _get_recipe_max_batch(_selected_recipe_id)
	if max_batch <= 0:
		_selected_brew_amount = 1
		batch_option.disabled = true
		batch_option.add_item("×1")
		batch_option.select(0)
		return
	batch_option.disabled = false
	_selected_brew_amount = clampi(_selected_brew_amount, 1, max_batch)
	for amount in range(1, max_batch + 1):
		batch_option.add_item("×%d" % amount)
		batch_option.set_item_metadata(batch_option.item_count - 1, amount)
		if amount == _selected_brew_amount:
			batch_option.select(batch_option.item_count - 1)

func _on_batch_option_selected(index: int) -> void:
	if batch_option.item_count == 0:
		return
	var metadata = batch_option.get_item_metadata(index)
	_selected_brew_amount = maxi(1, int(metadata if metadata != null else index + 1))
	_refresh_main_copy()

func _start_brew() -> void:
	if _selected_recipe_id == "":
		status_label.text = "Сначала выберите рецепт."
		return
	var max_batch := _get_recipe_max_batch(_selected_recipe_id)
	if max_batch <= 0:
		status_label.text = "Для этого рецепта не хватает ингредиентов."
		_refresh_all()
		return
	_selected_brew_amount = clampi(_selected_brew_amount, 1, max_batch)
	_pending_recipe_id = _selected_recipe_id
	_brew_phase = "timing"
	brew_overlay.visible = true
	timing_meter.visible = true
	stirring_minigame.visible = false
	overlay_action_button.visible = true
	overlay_action_button.disabled = false
	overlay_action_button.text = "Внести ингредиент"
	overlay_cancel_button.text = "Отмена"
	phase_title_label.text = "Фаза 1 — тайминг"
	phase_hint_label.text = "Одного точного попадания достаточно. Нажмите кнопку ниже или Enter, когда стрелка зайдёт в подсвеченный сектор."
	overlay_result_label.text = "Подготовьте смесь."
	timing_meter.reset_target(_rng.randf_range(0.32, 0.72), 0.22)
	timing_meter.restart(true)

func _on_overlay_action_pressed() -> void:
	match _brew_phase:
		"timing":
			_attempt_timing_step()
		"finished":
			_reset_brew_overlay()
			_refresh_all()
		_:
			pass

func _attempt_timing_step() -> void:
	if _brew_phase != "timing":
		return
	var result := timing_meter.submit_result()
	if bool(result.get("success", false)):
		_begin_stirring_phase()
	else:
		_finish_brew(false, "Смесь сорвалась на фазе тайминга. Ингредиенты не списаны.")

func _begin_stirring_phase() -> void:
	_brew_phase = "stirring"
	timing_meter.stop()
	timing_meter.visible = false
	stirring_minigame.visible = true
	overlay_action_button.visible = false
	phase_title_label.text = "Фаза 2 — помешивание"
	phase_hint_label.text = "Зажмите левую кнопку мыши и сделайте короткое круговое движение по кольцу."
	overlay_result_label.text = "Стабилизируйте смесь."
	stirring_minigame.begin(0.55 + (0.08 * float(_selected_brew_amount - 1)), true, 0.18)

func _on_stirring_finished(success: bool, score: float) -> void:
	if _brew_phase != "stirring":
		return
	if not success:
		_finish_brew(false, "Помешивание не удалось. Ингредиенты не списаны.")
		return
	_complete_successful_brew(score)

func _complete_successful_brew(stir_score: float) -> void:
	if Inventory_ == null:
		_finish_brew(false, "Инвентарь недоступен.")
		return
	var ingredients := AlchemyDB.get_ingredients(_pending_recipe_id)
	for item_id in ingredients.keys():
		Inventory_.remove_item(String(item_id), int(ingredients[item_id]) * _selected_brew_amount)
	var result_item_id := AlchemyDB.get_result_item_id(_pending_recipe_id)
	Inventory_.add_item(result_item_id, _selected_brew_amount)
	var quality := _quality_from_score(stir_score)
	_finish_brew(true, "Готово: %s ×%d. Качество варки: %s." % [RunItems.get_item_name(result_item_id), _selected_brew_amount, quality])

func _quality_from_score(score: float) -> String:
	if score >= 0.9:
		return "идеальное"
	if score >= 0.72:
		return "сильное"
	return "стабильное"

func _finish_brew(success: bool, message: String) -> void:
	_brew_phase = "finished"
	stirring_minigame.cancel()
	timing_meter.stop()
	timing_meter.visible = false
	stirring_minigame.visible = false
	overlay_action_button.visible = true
	overlay_action_button.disabled = false
	overlay_action_button.text = "Закрыть"
	phase_title_label.text = "Результат варки"
	phase_hint_label.text = "Можно закрыть окно и сразу начать следующую варку."
	overlay_result_label.text = message
	status_label.text = message
	brew_status_label.text = "Последняя варка завершена успешно." if success else "Последняя варка сорвалась."

func _cancel_brew_overlay() -> void:
	_reset_brew_overlay()
	status_label.text = "Варка отменена."

func _reset_brew_overlay() -> void:
	_pending_recipe_id = ""
	_brew_phase = "idle"
	brew_overlay.visible = false
	timing_meter.stop()
	timing_meter.visible = true
	stirring_minigame.cancel()
	stirring_minigame.visible = false
	overlay_action_button.visible = true
	overlay_action_button.disabled = false
	overlay_action_button.text = "Внести ингредиент"
	overlay_result_label.text = ""
