extends Node2D
class_name CardBattle
## Карточный бой — параллельная сцена, не зависящая от логики BattleSim.
##
## Намеренно НЕ используются: BattleSim, BattleHooks, BattleBanter_, SimConfig,
## старые статусы/способности и комнаты/награды забега.
## Из общего состояния читается состав отряда из Setup (DungRun.party_ids /
## party_level / party_slot_count). Конец боя ведёт туда же, куда и в обычном бое:
## FarmState_.advance_day() -> DungRun.on_run_finished_refresh_shops() -> хаб.
## BattleActor используется как «тупой» виджет (читает только Unit/CharacterData).

const BATTLE_ACTOR_SCENE: PackedScene = preload("res://scenes/BattleActor.tscn")
const VICTORY_TEXTURE: Texture2D = preload("res://assets/pics/bigPics/endscreen/victory.png")
const DEFEAT_TEXTURE: Texture2D = preload("res://assets/pics/bigPics/endscreen/defeat.png")

# --- Правила прототипа (все числа тестовые) ----------------------------------
## Тестовый забег: комнаты слева направо.
const ROOMS := [
	{"count": 1, "hp": 36, "atk_min": 2, "atk_max": 3},
	{"count": 2, "hp": 24, "atk_min": 2, "atk_max": 3},
	{"count": 2, "hp": 30, "atk_min": 3, "atk_max": 4},
	{"count": 3, "hp": 24, "atk_min": 3, "atk_max": 4},
	{"count": 3, "hp": 30, "atk_min": 4, "atk_max": 5},
]
const ENEMY_ID := "base_slime"
const HERO_TEST_HP := 50

const ENERGY_PER_TURN := 3
const HAND_SIZE := 5
const FILLER_ATTACK_COUNT := 4
const FILLER_SHIELD_COUNT := 2

const WEAK_REDUCTION := 2          ## Слабость: удар врага слабее на 2 (но не ниже 1)
const VULN_MULT := 1.5             ## Уязвимость: +50% получаемого урона (округление вверх)
const INEI_STUN_THRESHOLD := 4     ## Иней: при 4 стаках цель оглушается на ход
const NAZHIM_MAX := 10
const LOW_HP_RATIO := 0.5          ## «мало HP» = не больше половины
## Щит держится до начала следующего хода игрока (после удара врагов).
const SHIELD_EXPIRES_ON_NEW_TURN := true

# --- Раскладка руки ----------------------------------------------------------
const HAND_CENTER_X := 960.0
const HAND_TOP_Y := 845.0
const HAND_GAP := 16.0

const ZONE_COLOR_IDLE := Color(1, 1, 1, 0.07)
const ZONE_COLOR_ACTIVE := Color(1, 0.92, 0.45, 0.20)

const COL_DAMAGE := Color(1.0, 0.35, 0.35)
const COL_SHIELD := Color(0.65, 0.85, 1.0)
const COL_HEAL := Color(0.45, 1.0, 0.55)
const COL_STATUS := Color(1.0, 0.92, 0.45)

## Ульты. Шкала героя заполняется картами; размер шкалы = cost ульты в CardLibrary.
const ULT_CHARGE_PER_CARD := 1
const ULT_CHARGE_FROM_ANY_CARD := false   ## true: любая сыгранная карта заряжает ульты ВСЕХ героев
const ULT_START_CHARGE := 0
const ULT_COLUMN_X := 20.0                ## левый край колонки ульт
const ULT_COLUMN_CENTER_Y := 520.0        ## вертикальный центр колонки
const ULT_STEP_Y := 122.0                 ## шаг между кнопками

const HINT_START := "Карты без цели — в центр, остальные — на героя или врага"

@onready var room_label: Label = %RoomLabel
@onready var hint_label: Label = %HintLabel
@onready var exit_button: Button = %ExitButton
@onready var left_world: Node2D = %LeftSlotsWorld
@onready var right_world: Node2D = %RightSlotsWorld
@onready var hud: Control = %Hud
@onready var play_zone: ColorRect = %PlayZone
@onready var target_highlight: ColorRect = %TargetHighlight
@onready var hand_layer: Control = %HandLayer
@onready var deck_button: Button = %DeckButton
@onready var discard_button: Button = %DiscardButton
@onready var end_turn_button: Button = %EndTurnButton
@onready var energy_label: Label = %EnergyLabel
@onready var end_overlay: Control = %EndOverlay
@onready var end_image: TextureRect = %EndImage
@onready var end_text: Label = %EndText
@onready var end_button: Button = %EndButton

var left_team: Array[Unit] = []
var right_team: Array[Unit] = []
var left_actors: Array[BattleActor] = []
var right_actors: Array[BattleActor] = []

var _left_world_slots: Array[Node2D] = []
var _right_world_slots: Array[Node2D] = []

var _deck := CardDeck.new()
var _hand_views: Array[CardView] = []
var _dragging: CardView = null
var _drag_grab_offset := Vector2.ZERO
var _highlights: Array[ColorRect] = []

## Щиты живут здесь, а не в Unit: Unit — старая логика, её не трогаем. Unit -> int.
var _shields: Dictionary = {}
## Статусы боя: Unit -> { ключ: int }. Ключи: burn_power, burn_turns, weak, vuln,
## nazhim, inei, inei_latch, stun.
var _fx_data: Dictionary = {}
## Намерения врагов на этот ход: Unit -> базовый урон.
var _intents: Dictionary = {}
var _energy: int = 0
var _room_index: int = 0
## Надбавки к цене карт владельца: id героя -> +N. Активные и отложенные на след. ход.
var _surcharge: Dictionary = {}
var _pending_surcharge: Dictionary = {}
## Сколько плавающих надписей уже показано над юнитом в этом действии (чтобы не налезали).
var _float_stack: Dictionary = {}

var _busy := false
var _ended := false
var _end_victory := false
var _end_is_draw := false

var _ult_charge: Dictionary = {}     ## id героя -> заряд
var _ult_cards: Dictionary = {}      ## id героя -> CardInstance ульты
var _ult_buttons: Array[UltButton] = []
var _ult_column: Control

var _pile_popup: Control
var _pile_title: Label
var _pile_flow: HFlowContainer

func _ready() -> void:
	# Как и в обычном бое — один кадр на то, чтобы контейнеры посчитали размеры.
	await get_tree().process_frame

	room_label.text = "Карточный бой"
	hint_label.text = HINT_START

	exit_button.pressed.connect(_on_exit_pressed)
	end_button.pressed.connect(_on_end_button_pressed)
	end_turn_button.pressed.connect(_on_end_turn_pressed)
	deck_button.pressed.connect(func() -> void: _open_pile(true))
	discard_button.pressed.connect(func() -> void: _open_pile(false))

	end_overlay.visible = false
	play_zone.visible = false
	play_zone.color = ZONE_COLOR_IDLE
	var zone_label := play_zone.get_node_or_null("ZoneLabel") as Label
	if zone_label != null:
		zone_label.text = "Сюда — карты\nбез выбора цели"
	target_highlight.visible = false
	_highlights = [target_highlight]

	_cache_world_slots()
	_spawn_heroes()
	_build_ult_buttons()
	_build_pile_popup()
	await _start_room(0)

# --- Команды (только данные) -------------------------------------------------

func _make_unit(id: String, level: int) -> Unit:
	var data: CharacterData = CharDB.get_by_id(id)
	if data == null:
		push_warning("CardBattle: персонаж не найден в CharDB: %s" % id)
		return null
	return Unit.new(data, level)

func _spawn_heroes() -> void:
	left_team.clear()

	var level := maxi(1, DungRun.party_level)
	var slot_count := mini(DungRun.party_slot_count, DungRun.party_ids.size())
	for i in range(slot_count):
		var id: String = DungRun.party_ids[i]
		if id == "":
			continue
		var unit := _make_unit(id, level)
		if unit != null:
			left_team.append(unit)

	# Страховка: если отряд пуст, берём ведьму, чтобы сцена не была пустой.
	if left_team.is_empty():
		var fallback := _make_unit("witch", level)
		if fallback != null:
			left_team.append(fallback)

	for u in left_team:
		u.max_hp = HERO_TEST_HP
		u.hp = HERO_TEST_HP

func _room_data(index: int) -> Dictionary:
	return ROOMS[clampi(index, 0, ROOMS.size() - 1)]

func _spawn_enemies(room_index: int) -> void:
	right_team.clear()
	_intents.clear()
	var room := _room_data(room_index)
	for i in range(int(room["count"])):
		var enemy := _make_unit(ENEMY_ID, 1)
		if enemy == null:
			continue
		enemy.make_enemy(0, 0)
		enemy.max_hp = int(room["hp"])
		enemy.hp = enemy.max_hp
		right_team.append(enemy)

## Как в старом бою: слева «передний» — последний живой в списке, справа — первый.
func _front_alive_hero() -> Unit:
	for i in range(left_team.size() - 1, -1, -1):
		var u := left_team[i]
		if u != null and not u.is_dead and u.hp > 0:
			return u
	return null

func _front_alive_enemy() -> Unit:
	for u in right_team:
		if u != null and not u.is_dead and u.hp > 0:
			return u
	return null

func _hero_by_id(id: String) -> Unit:
	if id == "":
		return null
	for u in left_team:
		if u != null and u.data != null and u.data.id == id:
			return u
	return null

func _alive_enemies() -> Array[Unit]:
	var out: Array[Unit] = []
	for u in right_team:
		if u != null and not u.is_dead and u.hp > 0:
			out.append(u)
	return out

# --- Расстановка на сцене (раскладка как в обычном бое) ----------------------

func _cache_world_slots() -> void:
	_left_world_slots.clear()
	_right_world_slots.clear()
	for i in [3, 2, 1, 0]:
		_left_world_slots.append(left_world.get_node_or_null("LeftSlot%d" % i) as Node2D)
	for i in range(4):
		_right_world_slots.append(right_world.get_node_or_null("RightSlot%d" % i) as Node2D)

func _clear_slot(slot: Node2D) -> void:
	for c in slot.get_children():
		slot.remove_child(c)
		c.queue_free()
	slot.visible = false

func _populate_world_slots() -> void:
	left_actors.clear()
	right_actors.clear()

	for slot in _left_world_slots:
		if slot != null:
			_clear_slot(slot)
	for slot in _right_world_slots:
		if slot != null:
			_clear_slot(slot)

	var left_start := maxi(0, _left_world_slots.size() - left_team.size())
	for i in range(left_team.size()):
		var idx := left_start + i
		if idx >= _left_world_slots.size():
			break
		var slot := _left_world_slots[idx]
		if slot == null:
			continue
		var actor := BATTLE_ACTOR_SCENE.instantiate() as BattleActor
		slot.visible = true
		slot.add_child(actor)
		actor.bind(left_team[i], true)
		left_actors.append(actor)

	for i in range(mini(right_team.size(), _right_world_slots.size())):
		var slot := _right_world_slots[i]
		if slot == null:
			continue
		var actor := BATTLE_ACTOR_SCENE.instantiate() as BattleActor
		slot.visible = true
		slot.add_child(actor)
		actor.is_boss = false
		actor.bind(right_team[i], false)
		right_actors.append(actor)

func _all_actors() -> Array[BattleActor]:
	var out: Array[BattleActor] = []
	out.append_array(left_actors)
	out.append_array(right_actors)
	return out

func _find_actor(unit: Unit) -> BattleActor:
	for a in _all_actors():
		if a != null and a.unit == unit:
			return a
	return null

## Убираем с актёров то, что относится к старому бою (APS, энергия), и добавляем
## щит, намерение и строку статусов.
func _setup_actor_overlays() -> void:
	for a in _all_actors():
		a.aps_label.visible = false
		a.en_bar.visible = false
		a.en_label.visible = false
		_ensure_shield_label(a)
		if right_actors.has(a):
			_ensure_intent_label(a)
			_ensure_status_label(a)

func _make_overlay_label(label_name: String, pos: Vector2, label_size: Vector2, font_size: int, color: Color) -> Label:
	var label := Label.new()
	label.name = label_name
	label.position = pos
	label.size = label_size
	label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	label.add_theme_font_size_override("font_size", font_size)
	label.add_theme_color_override("font_color", color)
	label.add_theme_color_override("font_outline_color", Color(0, 0, 0, 1))
	label.add_theme_constant_override("outline_size", 4)
	label.visible = false
	return label

func _ensure_shield_label(actor: BattleActor) -> Label:
	var label := actor.get_node_or_null("ShieldLabel") as Label
	if label == null:
		label = _make_overlay_label("ShieldLabel", Vector2(-45, -308), Vector2(90, 26), 18, COL_SHIELD)
		actor.add_child(label)
	return label

func _ensure_intent_label(actor: BattleActor) -> Label:
	var label := actor.get_node_or_null("IntentLabel") as Label
	if label == null:
		label = _make_overlay_label("IntentLabel", Vector2(-60, -350), Vector2(120, 34), 24, Color(1.0, 0.55, 0.45, 1.0))
		label.add_theme_constant_override("outline_size", 6)
		actor.add_child(label)
	return label

func _ensure_status_label(actor: BattleActor) -> Label:
	var label := actor.get_node_or_null("StatusLabel") as Label
	if label == null:
		label = _make_overlay_label("StatusLabel", Vector2(-110, -404), Vector2(220, 50), 15, Color(0.95, 0.95, 0.85, 1.0))
		label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		actor.add_child(label)
	return label

func _refresh_actor(actor: BattleActor) -> void:
	if actor == null or actor.unit == null:
		return
	var unit := actor.unit
	actor.update_visual()

	var shield := int(_shields.get(unit, 0))
	var shield_label := _ensure_shield_label(actor)
	shield_label.text = "Щит: %d" % shield
	shield_label.visible = shield > 0 and not unit.is_dead

	var intent_label := actor.get_node_or_null("IntentLabel") as Label
	if intent_label != null:
		var has_intent := _intents.has(unit) and not unit.is_dead and not _ended
		intent_label.visible = has_intent
		if has_intent:
			if _fx(unit, "stun") > 0:
				intent_label.text = "Оглушён"
				intent_label.add_theme_color_override("font_color", COL_STATUS)
			elif _fx(unit, "charm") > 0:
				intent_label.text = "Бьёт своих: %d" % _effective_intent(unit)
				intent_label.add_theme_color_override("font_color", COL_HEAL)
			else:
				intent_label.text = "Удар: %d" % _effective_intent(unit)
				var weakened := _fx(unit, "weak") > 0
				intent_label.add_theme_color_override("font_color", COL_SHIELD if weakened else Color(1.0, 0.55, 0.45, 1.0))

	var status_label := actor.get_node_or_null("StatusLabel") as Label
	if status_label != null:
		var text := _status_text(unit)
		status_label.text = text
		status_label.visible = text != "" and not unit.is_dead

func _refresh_all_actors() -> void:
	for a in _all_actors():
		_refresh_actor(a)
	_refresh_ults()

func _refresh_unit(unit: Unit) -> void:
	_refresh_actor(_find_actor(unit))

# --- Статусы -----------------------------------------------------------------

func _fx(unit: Unit, key: String) -> int:
	var d: Dictionary = _fx_data.get(unit, {})
	return int(d.get(key, 0))

func _fx_set(unit: Unit, key: String, value: int) -> void:
	var d: Dictionary = _fx_data.get(unit, {})
	d[key] = value
	_fx_data[unit] = d

func _status_text(unit: Unit) -> String:
	var parts := PackedStringArray()
	if _fx(unit, "burn_turns") > 0 and _fx(unit, "burn_power") > 0:
		parts.append("Горение %d (%d)" % [_fx(unit, "burn_power"), _fx(unit, "burn_turns")])
	if _fx(unit, "weak") > 0:
		parts.append("Слабость (%d)" % _fx(unit, "weak"))
	if _fx(unit, "vuln") > 0:
		parts.append("Уязвимость (%d)" % _fx(unit, "vuln"))
	if _fx(unit, "nazhim") > 0:
		parts.append("Нажим %d" % _fx(unit, "nazhim"))
	if _fx(unit, "inei") > 0:
		parts.append("Иней %d" % _fx(unit, "inei"))
	if _fx(unit, "charm") > 0:
		parts.append("Очарован")
	return ", ".join(parts)

## Намерение с учётом Слабости: так игрок видит реальный удар.
func _effective_intent(unit: Unit) -> int:
	var base := int(_intents.get(unit, 0))
	if _fx(unit, "weak") > 0:
		base = maxi(1, base - WEAK_REDUCTION)
	return base

## Уязвимость усиливает любой получаемый урон.
func _calc_damage(target: Unit, base: int) -> int:
	if base <= 0:
		return 0
	if _fx(target, "vuln") > 0:
		return ceili(float(base) * VULN_MULT)
	return base

# --- Начало боя, комнаты и раздача -------------------------------------------

func _start_room(index: int) -> void:
	_busy = true
	_clear_hand_views()
	_room_index = index
	room_label.text = "Комната %d / %d" % [index + 1, ROOMS.size()]
	hint_label.text = HINT_START

	_fx_data.clear()
	_shields.clear()
	_surcharge.clear()
	_pending_surcharge.clear()
	_float_stack.clear()

	_spawn_enemies(index)
	_populate_world_slots()
	_setup_actor_overlays()

	# Каждая комната — новая раздача: карты живых героев и филлеры, сброс пуст.
	var cards: Array[CardInstance] = []
	for u in left_team:
		if u == null or u.is_dead:
			continue
		cards.append_array(CardLibrary.hero_cards(u.data.id, u.data.display_name))
	cards.append_array(CardLibrary.filler_cards(FILLER_ATTACK_COUNT, FILLER_SHIELD_COUNT))
	_deck.start_battle(cards)
	_refresh_pile_buttons()

	await _begin_player_turn()

func _begin_player_turn() -> void:
	_energy = ENERGY_PER_TURN
	_surcharge = _pending_surcharge.duplicate()
	_pending_surcharge.clear()
	_roll_intents()
	_refresh_all_actors()
	await _deal_new_hand()

## Каждый живой враг заранее выбирает урон на свой ход и показывает его над собой.
func _roll_intents() -> void:
	_intents.clear()
	var room := _room_data(_room_index)
	for u in _alive_enemies():
		_intents[u] = randi_range(int(room["atk_min"]), int(room["atk_max"]))

func _clear_hand_views() -> void:
	for v in _hand_views:
		v.fly_to_and_free(_discard_pos())
	_hand_views.clear()
	_deck.discard_hand()
	_refresh_pile_buttons()

func _effective_cost(card: CardInstance) -> int:
	if card.owner_id == "":
		return card.cost
	return card.cost + int(_surcharge.get(card.owner_id, 0))

func _refresh_energy() -> void:
	energy_label.text = "Энергия: %d/%d" % [_energy, ENERGY_PER_TURN]
	for v in _hand_views:
		var cost := _effective_cost(v.card)
		v.set_cost_text(cost, cost > v.card.cost)
		v.set_affordable(cost <= _energy)

func _deal_new_hand() -> void:
	_busy = true
	var drawn := _deck.draw(HAND_SIZE)
	_refresh_pile_buttons()
	for c in drawn:
		_add_card_view(c)
	_layout_hand(true)
	_refresh_energy()
	await _wait(0.3)
	_busy = false

func _add_card_view(c: CardInstance) -> CardView:
	var v := CardView.new()
	v.setup(c, true)
	hand_layer.add_child(v)
	v.position = deck_button.get_global_rect().get_center() - CardView.CARD_SIZE * 0.5
	v.pressed.connect(_on_card_pressed)
	v.appear()
	_hand_views.append(v)
	return v

func _hand_slot_position(index: int, count: int) -> Vector2:
	var total := count * CardView.CARD_SIZE.x + (count - 1) * HAND_GAP
	var x := HAND_CENTER_X - total * 0.5 + index * (CardView.CARD_SIZE.x + HAND_GAP)
	return Vector2(x, HAND_TOP_Y)

func _layout_hand(animated: bool) -> void:
	var n := _hand_views.size()
	for i in range(n):
		var v := _hand_views[i]
		v.home_position = _hand_slot_position(i, n)
		if v == _dragging:
			continue
		if animated:
			v.move_to(v.home_position)
		else:
			v.position = v.home_position

func _wait(seconds: float) -> void:
	# Твин привязан к узлу: если сцену закрыли, ожидание просто не продолжится.
	var t := create_tween()
	t.tween_interval(seconds)
	await t.finished

func _refresh_pile_buttons() -> void:
	deck_button.text = "Колода: %d" % _deck.draw_pile.size()
	discard_button.text = "Сброс: %d" % _deck.discard_pile.size()

func _discard_pos() -> Vector2:
	return discard_button.get_global_rect().get_center() - CardView.CARD_SIZE * 0.5

# --- Перетаскивание ----------------------------------------------------------

func _on_card_pressed(v: CardView) -> void:
	if _busy or _ended or _dragging != null:
		return
	if _effective_cost(v.card) > _energy:
		hint_label.text = "Не хватает энергии"
		return
	_dragging = v
	_drag_grab_offset = get_viewport().get_mouse_position() - v.global_position
	v.begin_drag()
	hand_layer.move_child(v, -1)
	if v.card.uses_play_zone():
		play_zone.visible = true
		play_zone.color = ZONE_COLOR_IDLE
	_update_drag_feedback()

func _input(event: InputEvent) -> void:
	if _dragging == null:
		return
	if event is InputEventMouseMotion:
		_dragging.global_position = get_viewport().get_mouse_position() - _drag_grab_offset
		_update_drag_feedback()
		get_viewport().set_input_as_handled()
	elif event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT and not event.pressed:
		get_viewport().set_input_as_handled()
		_finish_drag()

func _process(_delta: float) -> void:
	# Страховка: если отпускание кнопки «потерялось» (например, пауза), не застреваем.
	if _dragging != null and not Input.is_mouse_button_pressed(MOUSE_BUTTON_LEFT):
		_finish_drag()

## Цели «центральных» карт (без выбора цели).
func _zone_targets(card: CardInstance) -> Array[Unit]:
	var out: Array[Unit] = []
	match card.target:
		CardInstance.Target.FRONT_ENEMY:
			var e := _front_alive_enemy()
			if e != null:
				out.append(e)
		CardInstance.Target.ALL_ENEMIES:
			out.append_array(_alive_enemies())
		CardInstance.Target.SELF:
			var h := _hero_by_id(card.owner_id)
			if h != null and not h.is_dead:
				out.append(h)
	return out

## Что получит карта, если отпустить её в точке. Пустой список — «не сыграть».
func _drop_targets(card: CardInstance, point: Vector2) -> Array[Unit]:
	var out: Array[Unit] = []
	match card.target:
		CardInstance.Target.FRONT_ENEMY, CardInstance.Target.ALL_ENEMIES, CardInstance.Target.SELF:
			if play_zone.get_global_rect().has_point(point):
				out = _zone_targets(card)
		CardInstance.Target.CHOSEN_ENEMY:
			var enemy := _unit_at(right_actors, point)
			if enemy != null:
				out.append(enemy)
		CardInstance.Target.CHOSEN_ALLY:
			var hero := _unit_at(left_actors, point)
			if hero != null:
				out.append(hero)
	return out

func _update_drag_feedback() -> void:
	if _dragging == null:
		return
	var card := _dragging.card
	var point := get_viewport().get_mouse_position()
	if card.uses_play_zone():
		var inside := play_zone.get_global_rect().has_point(point)
		play_zone.color = ZONE_COLOR_ACTIVE if inside else ZONE_COLOR_IDLE
	_show_highlights(_drop_targets(card, point))

func _get_highlight(i: int) -> ColorRect:
	while _highlights.size() <= i:
		var dup := target_highlight.duplicate() as ColorRect
		hud.add_child(dup)
		_highlights.append(dup)
	return _highlights[i]

func _show_highlights(units: Array[Unit]) -> void:
	var shown := 0
	for u in units:
		var actor := _find_actor(u)
		if actor == null:
			continue
		var rect := _actor_hit_rect(actor)
		var h := _get_highlight(shown)
		h.global_position = rect.position
		h.size = rect.size
		h.visible = true
		shown += 1
	for i in range(shown, _highlights.size()):
		_highlights[i].visible = false

func _hide_highlights() -> void:
	for h in _highlights:
		h.visible = false

func _actor_hit_rect(actor: BattleActor) -> Rect2:
	var rect := Rect2(actor.global_position + Vector2(-110, -260), Vector2(220, 300))
	var sprite := actor.sprite
	if sprite != null and sprite.texture != null:
		rect = sprite.get_global_transform() * sprite.get_rect()
	return rect.grow(20.0)

## Живой юнит под курсором среди актёров (если несколько — ближайший к центру).
func _unit_at(actors: Array[BattleActor], point: Vector2) -> Unit:
	var best: Unit = null
	var best_dist := INF
	for actor in actors:
		if actor == null or actor.unit == null or actor.unit.is_dead:
			continue
		var rect := _actor_hit_rect(actor)
		if not rect.has_point(point):
			continue
		var d := rect.get_center().distance_to(point)
		if d < best_dist:
			best_dist = d
			best = actor.unit
	return best

func _finish_drag() -> void:
	var v := _dragging
	if v == null:
		return
	_dragging = null
	play_zone.visible = false
	_hide_highlights()
	v.end_drag()

	var targets := _drop_targets(v.card, get_viewport().get_mouse_position())
	if not targets.is_empty():
		_play_card(v, targets)
		return
	# Не разыграна — возвращаем в руку.
	v.move_to(v.home_position)

# --- Розыгрыш карты и эффекты ------------------------------------------------

func _consume_card(v: CardView) -> void:
	_energy = maxi(0, _energy - _effective_cost(v.card))
	_deck.play_card(v.card)
	_hand_views.erase(v)
	_refresh_pile_buttons()
	v.fly_to_and_free(_discard_pos())
	_layout_hand(true)
	_refresh_energy()

func _play_card(v: CardView, targets: Array[Unit]) -> void:
	var card := v.card
	var caster := _hero_by_id(card.owner_id)
	_float_stack.clear()
	_consume_card(v)
	for e in card.effects:
		_run_effect(e, caster, targets)
	_gain_ult_charge(card.owner_id)
	_refresh_all_actors()
	hint_label.text = card.title
	_check_end()

func _run_effect(e: Dictionary, caster: Unit, targets: Array[Unit]) -> void:
	match String(e["type"]):
		"damage":
			for u in targets:
				if u.is_dead:
					continue
				var base := int(e["amount"])
				if e.has("per_nazhim"):
					base += int(e["per_nazhim"]) * _fx(u, "nazhim")
				_hit(u, base)
		"damage_per_inei":
			for u in targets:
				var stacks := _fx(u, "inei")
				if u.is_dead or stacks <= 0:
					continue
				_hit(u, int(e["per_inei"]) * stacks)
		"weak":
			for u in targets:
				if u.is_dead:
					continue
				_fx_set(u, "weak", maxi(_fx(u, "weak"), int(e["turns"])))
				_float_for(u, "Слабость", COL_STATUS)
		"vuln":
			for u in targets:
				if u.is_dead:
					continue
				_fx_set(u, "vuln", maxi(_fx(u, "vuln"), int(e["turns"])))
				_float_for(u, "Уязвимость", COL_STATUS)
		"burn":
			for u in targets:
				if u.is_dead:
					continue
				_fx_set(u, "burn_power", _fx(u, "burn_power") + int(e["power"]))
				_fx_set(u, "burn_turns", maxi(_fx(u, "burn_turns"), int(e["turns"])))
				_float_for(u, "Горение", COL_STATUS)
		"burn_extend":
			for u in targets:
				if u.is_dead or _fx(u, "burn_turns") <= 0:
					continue
				_fx_set(u, "burn_turns", _fx(u, "burn_turns") + int(e["turns"]))
				_float_for(u, "Горение +%d" % int(e["turns"]), COL_STATUS)
		"burning_bonus":
			for u in targets:
				if u.is_dead or _fx(u, "burn_turns") <= 0:
					continue
				_fx_set(u, "vuln", maxi(_fx(u, "vuln"), int(e["vuln_turns"])))
				_fx_set(u, "burn_turns", _fx(u, "burn_turns") + int(e["extend"]))
				_float_for(u, "Уязвимость", COL_STATUS)
		"nazhim":
			for u in targets:
				if u.is_dead:
					continue
				var n := clampi(_fx(u, "nazhim") + int(e["amount"]), 0, NAZHIM_MAX)
				_fx_set(u, "nazhim", n)
				_float_for(u, "Нажим +%d" % int(e["amount"]), COL_STATUS)
		"nazhim_cash_heal":
			for u in targets:
				var stacks := _fx(u, "nazhim")
				if u.is_dead or stacks <= 0:
					continue
				_fx_set(u, "nazhim", 0)
				if caster != null and not caster.is_dead:
					_heal(caster, stacks * int(e["per"]))
		"inei":
			for u in targets:
				if u.is_dead:
					continue
				_add_inei(u, int(e["amount"]))
		"inei_clear":
			for u in targets:
				_fx_set(u, "inei", 0)
				_fx_set(u, "inei_latch", 0)
		"shield":
			if String(e.get("to", "target")) == "self":
				if caster != null and not caster.is_dead:
					_add_shield(caster, int(e["amount"]))
			else:
				for u in targets:
					if not u.is_dead:
						_add_shield(u, int(e["amount"]))
		"shield_self_if_low":
			if caster != null and not caster.is_dead and not targets.is_empty():
				var t := targets[0]
				if float(t.hp) <= float(t.max_hp) * LOW_HP_RATIO:
					_add_shield(caster, int(e["amount"]))
		"heal":
			for u in targets:
				if u.is_dead:
					continue
				var amount := int(e["amount"])
				if e.has("bonus") and float(u.hp) <= float(u.max_hp) * LOW_HP_RATIO:
					amount += int(e["bonus"])
				_heal(u, amount)
		"stun":
			for u in targets:
				if u.is_dead:
					continue
				_fx_set(u, "stun", maxi(_fx(u, "stun"), int(e["turns"])))
				_float_for(u, "Оглушение", COL_STATUS)
		"charm":
			for u in targets:
				if u.is_dead:
					continue
				_fx_set(u, "charm", maxi(_fx(u, "charm"), int(e["turns"])))
				_float_for(u, "Очарование", COL_HEAL)
		"heal_front_ally":
			var ally := _front_alive_hero()
			if ally != null:
				_heal(ally, int(e["amount"]))
		"heal_self_per_target":
			if caster != null and not caster.is_dead:
				var hit_count := 0
				for u in targets:
					if not u.is_dead:
						hit_count += 1
				if hit_count > 0:
					_heal(caster, hit_count * int(e["per"]))
		"burn_tick_all":
			for u in targets:
				var power := _fx(u, "burn_power")
				if u.is_dead or _fx(u, "burn_turns") <= 0 or power <= 0:
					continue
				_hit(u, power)
		"surcharge_owner":
			if caster != null:
				var id := caster.data.id
				_pending_surcharge[id] = int(_pending_surcharge.get(id, 0)) + int(e["amount"])
		_:
			push_warning("CardBattle: неизвестный эффект: %s" % [e])

func _add_inei(unit: Unit, amount: int) -> void:
	var n := clampi(_fx(unit, "inei") + amount, 0, 99)
	_fx_set(unit, "inei", n)
	if amount > 0:
		_float_for(unit, "Иней +%d" % amount, COL_SHIELD)
	elif amount < 0:
		_float_for(unit, "Иней %d" % amount, COL_SHIELD)
	if n >= INEI_STUN_THRESHOLD and _fx(unit, "inei_latch") == 0:
		# Оглушение срабатывает один раз, пока Иней не упадёт ниже порога.
		_fx_set(unit, "stun", 1)
		_fx_set(unit, "inei_latch", 1)
		_float_for(unit, "Оглушён!", COL_STATUS)
	elif n < INEI_STUN_THRESHOLD:
		_fx_set(unit, "inei_latch", 0)

func _add_shield(unit: Unit, amount: int) -> void:
	_shields[unit] = int(_shields.get(unit, 0)) + amount
	_float_for(unit, "+%d щит" % amount, COL_SHIELD)

func _heal(unit: Unit, amount: int) -> void:
	if unit.is_dead or amount <= 0:
		return
	var before := unit.hp
	unit.hp = mini(unit.max_hp, unit.hp + amount)
	var gained := unit.hp - before
	_float_for(unit, "+%d HP" % gained, COL_HEAL)

## Удар с учётом Уязвимости.
func _hit(unit: Unit, base: int) -> void:
	_apply_damage(unit, _calc_damage(unit, base))

## Урон сначала съедает щит, остаток идёт в HP.
func _apply_damage(unit: Unit, amount: int) -> void:
	var shield := int(_shields.get(unit, 0))
	var absorbed := mini(shield, amount)
	if absorbed > 0:
		_shields[unit] = shield - absorbed
	var dmg := amount - absorbed
	var died := false
	if dmg > 0:
		died = unit.take_damage(dmg)

	var actor := _find_actor(unit)
	if actor != null:
		if dmg > 0:
			actor.flash_red()
		_refresh_actor(actor)
	if dmg > 0:
		_float_for(unit, "-%d" % dmg, COL_DAMAGE, 34)
	if absorbed > 0:
		_float_for(unit, "щит -%d" % absorbed, COL_SHIELD)
	if died and left_team.has(unit):
		_purge_cards_of(unit)

## Герой выбыл — его карты выходят из боя.
func _purge_cards_of(unit: Unit) -> void:
	var id := unit.data.id
	_deck.remove_owner_cards(id)
	for v in _hand_views.duplicate():
		if v.card.owner_id == id:
			_hand_views.erase(v)
			v.fly_to_and_free(_discard_pos())
	_layout_hand(true)
	_refresh_pile_buttons()
	_refresh_energy()

func _float_for(unit: Unit, text: String, color: Color, font_size: int = 26) -> void:
	var actor := _find_actor(unit)
	if actor == null:
		return
	var n := int(_float_stack.get(unit, 0))
	_float_stack[unit] = n + 1
	_spawn_float_text(actor.global_position + Vector2(-40, -240 - 34 * n), text, color, font_size)

func _spawn_float_text(pos: Vector2, text: String, color: Color, font_size: int = 26) -> void:
	var l := Label.new()
	l.text = text
	l.position = pos
	l.mouse_filter = Control.MOUSE_FILTER_IGNORE
	l.add_theme_font_size_override("font_size", font_size)
	l.add_theme_color_override("font_color", color)
	l.add_theme_color_override("font_outline_color", Color(0, 0, 0, 1))
	l.add_theme_constant_override("outline_size", 6)
	hud.add_child(l)
	var t := l.create_tween().set_parallel(true)
	t.tween_property(l, "position:y", pos.y - 70.0, 0.9)
	t.tween_property(l, "modulate:a", 0.0, 0.5).set_delay(0.4)
	t.chain().tween_callback(l.queue_free)

# --- Конец хода --------------------------------------------------------------

func _on_end_turn_pressed() -> void:
	if _busy or _ended or _dragging != null:
		return
	_busy = true

	# 1. Рука уходит в сброс.
	_clear_hand_views()
	await _wait(0.3)

	# 2. Горение жжёт в начале хода врагов — до их ударов.
	_float_stack.clear()
	var burned := false
	for enemy in _alive_enemies():
		var power := _fx(enemy, "burn_power")
		var turns := _fx(enemy, "burn_turns")
		if turns <= 0 or power <= 0:
			continue
		_hit(enemy, power)
		burned = true
		_fx_set(enemy, "burn_turns", turns - 1)
		if turns - 1 <= 0:
			_fx_set(enemy, "burn_power", 0)
	if burned:
		_refresh_all_actors()
		hint_label.text = "Горение жжёт врагов"
		await _wait(0.5)
		if _check_end():
			return

	# 3. Каждый живой враг бьёт переднего героя (если не оглушён).
	for enemy in _alive_enemies():
		_float_stack.clear()
		if _fx(enemy, "stun") > 0:
			hint_label.text = "%s оглушён и пропускает ход" % enemy.data.display_name
			await _wait(0.35)
			continue
		var target := _front_alive_hero()
		if target == null:
			break
		var amount := _effective_intent(enemy)
		var enemy_actor := _find_actor(enemy)
		if _fx(enemy, "charm") > 0:
			# Очарованный враг бьёт ближайшего союзника (следующего живого врага).
			var victim := _charm_victim(enemy)
			if victim == null:
				hint_label.text = "%s очарован, но бить некого" % enemy.data.display_name
				await _wait(0.35)
				continue
			if enemy_actor != null:
				enemy_actor.play_attack_bounce(-1)
			_float_stack.clear()
			_apply_damage(victim, amount)
			hint_label.text = "%s бьёт своего: %s на %d" % [enemy.data.display_name, victim.data.display_name, amount]
			await _wait(0.45)
			if _check_end():
				return
			continue
		if enemy_actor != null:
			enemy_actor.play_attack_bounce(-1)
		_apply_damage(target, amount)
		hint_label.text = "%s бьёт %s на %d" % [enemy.data.display_name, target.data.display_name, amount]
		await _wait(0.45)
		if _check_end():
			return

	# 4. Слабость, Уязвимость и оглушение отработали ход.
	for enemy in _alive_enemies():
		for key in ["weak", "vuln", "stun", "charm"]:
			_fx_set(enemy, key, maxi(0, _fx(enemy, key) - 1))

	# 5. Щиты сгорают, новый ход: энергия, новые намерения, новая рука.
	if SHIELD_EXPIRES_ON_NEW_TURN:
		_shields.clear()
	await _begin_player_turn()

# --- Окончание боя -----------------------------------------------------------

## Та же проверка, что в старом бою: нет живых слева/справа -> поражение/победа/ничья.
## Возвращает true, если дальше ход продолжать нельзя (переход в комнату или конец боя).
func _check_end() -> bool:
	if _ended:
		return true
	var left_alive := _front_alive_hero() != null
	var right_alive := _front_alive_enemy() != null
	if left_alive and right_alive:
		return false

	# Комната зачищена, но это не последняя — идём дальше.
	if left_alive and not right_alive and _room_index < ROOMS.size() - 1:
		_busy = true
		_advance_room()
		return true

	_ended = true
	_busy = true
	if not left_alive and not right_alive:
		_end_victory = false
		_end_is_draw = true
		hint_label.text = "Ничья"
	elif not left_alive:
		_end_victory = false
		_end_is_draw = false
		hint_label.text = "Победил враг"
	else:
		_end_victory = true
		_end_is_draw = false
		hint_label.text = "Победил игрок"
	_refresh_all_actors()
	_show_end_overlay(_end_victory, _end_is_draw)
	return true

func _advance_room() -> void:
	hint_label.text = "Комната пройдена!"
	await _wait(0.9)
	_clear_hand_views()
	await _start_room(_room_index + 1)

func _show_end_overlay(victory: bool, is_draw: bool) -> void:
	end_overlay.visible = true
	if is_draw:
		end_text.text = "Ничья"
		end_image.texture = null
		end_button.text = "Продолжить"
		return
	if victory:
		end_text.text = "УФФ ПОЛЕГЧЕ, КОВБОЙ <3"
		end_image.texture = VICTORY_TEXTURE
		end_button.text = "КОНЧИТЬ"
	else:
		end_text.text = "ЧЁ ЗА ТЕНТАКЛИ КАКОЙ ХЕНТАЙ"
		end_image.texture = DEFEAT_TEXTURE
		end_button.text = "КОНЧИТЬ"

## В обычном бое без активного забега (и при поражении/ничьей) кнопка конца делает именно это.
func _on_end_button_pressed() -> void:
	if not _ended:
		return
	FarmState_.advance_day()
	DungRun.on_run_finished_refresh_shops()
	SceneRouter_.go_to_hub()

# --- Просмотр колоды и сброса ------------------------------------------------

func _build_pile_popup() -> void:
	_pile_popup = Control.new()
	_pile_popup.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_pile_popup.visible = false
	_pile_popup.z_index = 50
	hud.add_child(_pile_popup)

	var dim := ColorRect.new()
	dim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	dim.color = Color(0, 0, 0, 0.6)
	dim.mouse_filter = Control.MOUSE_FILTER_STOP
	dim.gui_input.connect(func(event: InputEvent) -> void:
		if event is InputEventMouseButton and event.pressed:
			_close_pile()
	)
	_pile_popup.add_child(dim)

	var center := CenterContainer.new()
	center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	center.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_pile_popup.add_child(center)

	var panel := PanelContainer.new()
	var sb := StyleBoxFlat.new()
	sb.bg_color = Color(0.16, 0.08, 0.20, 0.97)
	sb.corner_radius_top_left = 18
	sb.corner_radius_top_right = 18
	sb.corner_radius_bottom_left = 18
	sb.corner_radius_bottom_right = 18
	sb.border_width_left = 4
	sb.border_width_right = 4
	sb.border_width_top = 4
	sb.border_width_bottom = 4
	sb.border_color = Color(0.56, 0.44, 0.60, 1.0)
	sb.content_margin_left = 28
	sb.content_margin_right = 28
	sb.content_margin_top = 22
	sb.content_margin_bottom = 22
	panel.add_theme_stylebox_override("panel", sb)
	center.add_child(panel)

	var vbox := VBoxContainer.new()
	vbox.add_theme_constant_override("separation", 16)
	panel.add_child(vbox)

	_pile_title = Label.new()
	_pile_title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_pile_title.add_theme_font_size_override("font_size", 30)
	vbox.add_child(_pile_title)

	var scroll := ScrollContainer.new()
	scroll.custom_minimum_size = Vector2(1040, 700)
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	vbox.add_child(scroll)

	# Отступы, чтобы значки цены на краях карт не обрезались областью прокрутки.
	var margin := MarginContainer.new()
	margin.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	margin.add_theme_constant_override("margin_left", 16)
	margin.add_theme_constant_override("margin_top", 16)
	margin.add_theme_constant_override("margin_right", 16)
	margin.add_theme_constant_override("margin_bottom", 16)
	scroll.add_child(margin)

	_pile_flow = HFlowContainer.new()
	_pile_flow.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_pile_flow.add_theme_constant_override("h_separation", 14)
	_pile_flow.add_theme_constant_override("v_separation", 14)
	margin.add_child(_pile_flow)

	var close := Button.new()
	close.text = "Закрыть"
	close.custom_minimum_size = Vector2(0, 52)
	close.add_theme_font_size_override("font_size", 24)
	close.pressed.connect(_close_pile)
	vbox.add_child(close)

func _open_pile(is_draw_pile: bool) -> void:
	if _dragging != null:
		return
	var cards: Array[CardInstance] = _deck.draw_pile if is_draw_pile else _deck.discard_pile
	_pile_title.text = "%s: %d" % ["Колода" if is_draw_pile else "Сброс", cards.size()]

	for c in _pile_flow.get_children():
		_pile_flow.remove_child(c)
		c.queue_free()

	if cards.is_empty():
		var empty := Label.new()
		empty.text = "Пусто"
		empty.add_theme_font_size_override("font_size", 24)
		_pile_flow.add_child(empty)
	else:
		# Сортируем по владельцу и названию, чтобы не показывать порядок добора.
		var sorted: Array[CardInstance] = []
		sorted.append_array(cards)
		sorted.sort_custom(func(a: CardInstance, b: CardInstance) -> bool:
			return (a.owner_id + a.title) < (b.owner_id + b.title)
		)
		for card in sorted:
			var view := CardView.new()
			view.setup(card, false)
			_pile_flow.add_child(view)

	_pile_popup.visible = true

func _close_pile() -> void:
	_pile_popup.visible = false

# --- Выход -------------------------------------------------------------------

func _on_exit_pressed() -> void:
	SceneRouter_.go_to_setup()

# --- Ультимейты --------------------------------------------------------------

func _hero_texture(u: Unit) -> Texture2D:
	var d: CharacterData = u.data
	if d.card_portrait != null:
		return d.card_portrait
	if d.icon != null:
		return d.icon
	return d.battle_texture

func _build_ult_buttons() -> void:
	if _ult_column != null:
		_ult_column.queue_free()
	_ult_buttons.clear()
	_ult_cards.clear()
	_ult_charge.clear()
	_ult_column = Control.new()
	_ult_column.name = "UltColumn"
	_ult_column.mouse_filter = Control.MOUSE_FILTER_IGNORE
	hud.add_child(_ult_column)

	var heroes: Array[Unit] = []
	for u in left_team:
		if u != null and CardLibrary.ult_for(u.data.id, u.data.display_name) != null:
			heroes.append(u)
	var total := float(heroes.size())
	for i in range(heroes.size()):
		var u := heroes[i]
		var ult := CardLibrary.ult_for(u.data.id, u.data.display_name)
		_ult_cards[u.data.id] = ult
		_ult_charge[u.data.id] = clampi(ULT_START_CHARGE, 0, maxi(1, ult.cost))
		var b := UltButton.new()
		b.name = "Ult_%s" % u.data.id
		b.setup(u, ult, _hero_texture(u))
		b.position = Vector2(ULT_COLUMN_X, ULT_COLUMN_CENTER_Y + (float(i) - (total - 1.0) * 0.5) * ULT_STEP_Y - UltButton.BUTTON_SIZE * 0.5)
		b.pressed.connect(_on_ult_pressed)
		_ult_column.add_child(b)
		_ult_buttons.append(b)
	_refresh_ults()

func _refresh_ults() -> void:
	for b in _ult_buttons:
		var id := b.unit.data.id
		b.set_state(int(_ult_charge.get(id, 0)), not b.unit.is_dead)

func _gain_ult_charge(owner_id: String) -> void:
	for id in _ult_cards.keys():
		if not ULT_CHARGE_FROM_ANY_CARD and id != owner_id:
			continue
		var hero := _hero_by_id(id)
		if hero == null or hero.is_dead:
			continue
		var ult: CardInstance = _ult_cards[id]
		_ult_charge[id] = mini(maxi(1, ult.cost), int(_ult_charge.get(id, 0)) + ULT_CHARGE_PER_CARD)

func _charm_victim(enemy: Unit) -> Unit:
	# Бьёт ближайшего живого соседа по строю.
	var idx := right_team.find(enemy)
	var best: Unit = null
	var best_dist := 999
	for i in range(right_team.size()):
		var u := right_team[i]
		if u == null or u == enemy or u.is_dead:
			continue
		var d := absi(i - idx)
		if d < best_dist:
			best_dist = d
			best = u
	return best

func _on_ult_pressed(btn: UltButton) -> void:
	if _busy or _ended or _dragging != null:
		return
	var hero := btn.unit
	if hero == null or hero.is_dead or not btn.is_ready():
		return
	var ult: CardInstance = _ult_cards.get(hero.data.id)
	if ult == null:
		return
	var targets: Array[Unit] = []
	match ult.target:
		CardInstance.Target.ALL_ENEMIES:
			targets.assign(_alive_enemies())
		CardInstance.Target.SELF:
			targets.append(hero)
		_:
			var front := _front_alive_enemy()
			if front != null:
				targets.append(front)
	if targets.is_empty() and ult.target != CardInstance.Target.SELF:
		return

	_ult_charge[hero.data.id] = 0
	_float_stack.clear()
	_show_ult_banner(hero, ult)
	for e in ult.effects:
		_run_effect(e, hero, targets)
	_refresh_all_actors()
	hint_label.text = "%s: %s" % [hero.data.display_name, ult.title]
	_check_end()

func _show_ult_banner(hero: Unit, ult: CardInstance) -> void:
	var l := Label.new()
	l.text = "%s — %s" % [hero.data.display_name, ult.title]
	l.mouse_filter = Control.MOUSE_FILTER_IGNORE
	l.position = Vector2(560, 300)
	l.size = Vector2(800, 80)
	l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	l.pivot_offset = l.size * 0.5
	l.add_theme_font_size_override("font_size", 52)
	l.add_theme_color_override("font_color", ult.color.lightened(0.45))
	l.add_theme_color_override("font_outline_color", Color(0, 0, 0, 1))
	l.add_theme_constant_override("outline_size", 10)
	l.scale = Vector2(1.5, 1.5)
	l.modulate.a = 0.0
	hud.add_child(l)
	var t := l.create_tween()
	t.tween_property(l, "modulate:a", 1.0, 0.12)
	t.parallel().tween_property(l, "scale", Vector2.ONE, 0.18)
	t.tween_interval(0.7)
	t.tween_property(l, "modulate:a", 0.0, 0.3)
	t.tween_callback(l.queue_free)
