extends Panel
class_name CardView
## Прямоугольник-карта. Сам ничего не решает: при нажатии шлёт сигнал,
## перетаскиванием и розыгрышем занимается CardBattle.

signal pressed(view: CardView)

const CARD_SIZE := Vector2(150, 210)

var card: CardInstance
var interactive: bool = true
var dragging: bool = false
## Место в руке, куда карта возвращается, если её не удалось разыграть.
var home_position: Vector2 = Vector2.ZERO

var _move_tween: Tween
var _hover: bool = false
var _affordable: bool = true
var _cost_label: Label

func setup(c: CardInstance, is_interactive: bool = true) -> void:
	card = c
	interactive = is_interactive
	custom_minimum_size = CARD_SIZE
	size = CARD_SIZE
	pivot_offset = CARD_SIZE * 0.5
	mouse_filter = Control.MOUSE_FILTER_STOP if interactive else Control.MOUSE_FILTER_IGNORE

	var sb := StyleBoxFlat.new()
	sb.bg_color = c.color
	sb.corner_radius_top_left = 12
	sb.corner_radius_top_right = 12
	sb.corner_radius_bottom_left = 12
	sb.corner_radius_bottom_right = 12
	sb.border_width_left = 3
	sb.border_width_right = 3
	sb.border_width_top = 3
	sb.border_width_bottom = 3
	sb.border_color = c.color.lightened(0.55)
	add_theme_stylebox_override("panel", sb)

	add_child(_make_label(c.title, 15 if c.title.length() <= 11 else 13, Vector2(24, 12), Vector2(CARD_SIZE.x - 30, 26)))

	var desc_label := _make_label(c.description, 14, Vector2(10, 46), Vector2(CARD_SIZE.x - 20, 130), true)
	desc_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_LEFT
	desc_label.add_theme_constant_override("outline_size", 3)
	add_child(desc_label)

	var owner_label := _make_label(c.owner_name, 14, Vector2(0, 182), Vector2(CARD_SIZE.x, 22))
	owner_label.add_theme_color_override("font_color", Color(1, 1, 1, 0.8))
	add_child(owner_label)

	add_child(_make_cost_badge(c.cost))

	if interactive:
		mouse_entered.connect(_on_mouse_entered)
		mouse_exited.connect(_on_mouse_exited)

func _make_cost_badge(cost: int) -> Panel:
	var badge := Panel.new()
	badge.position = Vector2(-12, -12)
	badge.size = Vector2(36, 36)
	badge.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var sb := StyleBoxFlat.new()
	sb.bg_color = Color(0.12, 0.10, 0.22, 1.0)
	sb.corner_radius_top_left = 18
	sb.corner_radius_top_right = 18
	sb.corner_radius_bottom_left = 18
	sb.corner_radius_bottom_right = 18
	sb.border_width_left = 3
	sb.border_width_right = 3
	sb.border_width_top = 3
	sb.border_width_bottom = 3
	sb.border_color = Color(1.0, 0.92, 0.45, 1.0)
	badge.add_theme_stylebox_override("panel", sb)
	_cost_label = _make_label(str(cost), 22, Vector2.ZERO, Vector2(36, 36))
	_cost_label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	badge.add_child(_cost_label)
	return badge

func _make_label(text: String, font_size: int, pos: Vector2, label_size: Vector2, wrap: bool = false) -> Label:
	var l := Label.new()
	# Перенос включаем ДО текста и размера, иначе Label растягивается под всю строку.
	if wrap:
		l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	l.text = text
	l.position = pos
	l.size = label_size
	l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	l.mouse_filter = Control.MOUSE_FILTER_IGNORE
	l.add_theme_font_size_override("font_size", font_size)
	l.add_theme_color_override("font_color", Color.WHITE)
	l.add_theme_color_override("font_outline_color", Color(0, 0, 0, 1))
	l.add_theme_constant_override("outline_size", 4)
	return l

func _gui_input(event: InputEvent) -> void:
	if not interactive:
		return
	if event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT and event.pressed:
		accept_event()
		pressed.emit(self)

func _on_mouse_entered() -> void:
	_hover = true
	_update_tint()

func _on_mouse_exited() -> void:
	_hover = false
	_update_tint()

## Текущая цена (с учётом надбавок). Красным — если дороже базовой.
func set_cost_text(value: int, raised: bool) -> void:
	if _cost_label == null:
		return
	_cost_label.text = str(value)
	_cost_label.add_theme_color_override("font_color", Color(1.0, 0.45, 0.4) if raised else Color.WHITE)

## Карты, на которые не хватает энергии, затемняются.
func set_affordable(value: bool) -> void:
	_affordable = value
	_update_tint()

func _update_tint() -> void:
	if dragging or not interactive:
		self_modulate = Color.WHITE
	elif not _affordable:
		self_modulate = Color(0.5, 0.5, 0.55, 1.0)
	elif _hover:
		self_modulate = Color(1.15, 1.15, 1.15, 1.0)
	else:
		self_modulate = Color.WHITE

# --- Движение и анимации -----------------------------------------------------

func _kill_move() -> void:
	if _move_tween != null and _move_tween.is_valid():
		_move_tween.kill()
	_move_tween = null

func move_to(pos: Vector2, duration: float = 0.18) -> void:
	_kill_move()
	_move_tween = create_tween()
	_move_tween.tween_property(self, "position", pos, duration).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_OUT)

func appear() -> void:
	scale = Vector2(0.4, 0.4)
	modulate.a = 0.0
	var t := create_tween().set_parallel(true)
	t.tween_property(self, "scale", Vector2.ONE, 0.18)
	t.tween_property(self, "modulate:a", 1.0, 0.12)

func begin_drag() -> void:
	_kill_move()
	dragging = true
	_hover = false
	z_index = 100
	scale = Vector2(1.08, 1.08)
	_update_tint()

func end_drag() -> void:
	dragging = false
	z_index = 0
	scale = Vector2.ONE
	_update_tint()

## Карта улетает в точку (обычно к кнопке сброса) и удаляется.
func fly_to_and_free(target: Vector2) -> void:
	_kill_move()
	dragging = false
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	z_index = 20
	var t := create_tween().set_parallel(true)
	t.tween_property(self, "position", target, 0.22).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN)
	t.tween_property(self, "scale", Vector2(0.35, 0.35), 0.22)
	t.tween_property(self, "modulate:a", 0.0, 0.14).set_delay(0.08)
	t.chain().tween_callback(queue_free)
