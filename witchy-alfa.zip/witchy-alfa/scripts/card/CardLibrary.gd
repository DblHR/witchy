extends RefCounted
class_name CardLibrary
## Каталог карт прототипа: филлеры и по 4 карты на героя (без ультимейтов).
## Каждый вызов создаёт НОВЫЕ экземпляры.
##
## Эффекты (type): damage, damage_per_inei, weak, vuln, burn, burn_extend, burning_bonus,
## nazhim, nazhim_cash_heal, inei, inei_clear, shield, shield_self_if_low, heal, surcharge_owner.

const COLOR_FILLER := Color(0.45, 0.45, 0.50, 1.0)
const COLOR_WITCH := Color(0.58, 0.30, 0.76, 1.0)
const COLOR_WARRIOR := Color(0.78, 0.22, 0.25, 1.0)
const COLOR_FUFU := Color(0.20, 0.56, 0.58, 1.0)
const COLOR_AKI := Color(0.88, 0.42, 0.64, 1.0)
const COLOR_LUISA := Color(0.36, 0.60, 0.88, 1.0)

static func _card(p_id: String, p_title: String, p_cost: int, p_target: CardInstance.Target, p_color: Color, p_desc: String, p_effects: Array) -> CardInstance:
	var c := CardInstance.new()
	c.id = p_id
	c.title = p_title
	c.cost = p_cost
	c.target = p_target
	c.color = p_color
	c.description = p_desc
	c.effects.assign(p_effects)
	return c

## Общие карты. Слабее карт героев.
static func filler_cards(attack_count: int, shield_count: int) -> Array[CardInstance]:
	var out: Array[CardInstance] = []
	for i in range(attack_count):
		out.append(_card("filler_strike", "Удар", 1, CardInstance.Target.FRONT_ENEMY, COLOR_FILLER,
			"3 урона переднему врагу.",
			[{"type": "damage", "amount": 3}]))
	for i in range(shield_count):
		out.append(_card("filler_shield", "Щит", 1, CardInstance.Target.CHOSEN_ALLY, COLOR_FILLER,
			"+3 щита выбранному герою.",
			[{"type": "shield", "to": "target", "amount": 3}]))
	return out

## 4 карты героя. Для неизвестного id возвращается пустой список.
static func hero_cards(hero_id: String, hero_name: String) -> Array[CardInstance]:
	var out: Array[CardInstance] = []
	match hero_id:
		"witch":
			out.append(_card("witch_spark", "Искра", 1, CardInstance.Target.FRONT_ENEMY, COLOR_WITCH,
				"4 урона переднему.\nГорение 1 (3 хода).",
				[{"type": "damage", "amount": 4}, {"type": "burn", "power": 1, "turns": 3}]))
			out.append(_card("witch_rain", "Дождь искр", 2, CardInstance.Target.ALL_ENEMIES, COLOR_WITCH,
				"3 урона всем.\nГорение 1 (3 хода) всем.",
				[{"type": "damage", "amount": 3}, {"type": "burn", "power": 1, "turns": 3}]))
			out.append(_card("witch_fan", "Раздуть пламя", 2, CardInstance.Target.ALL_ENEMIES, COLOR_WITCH,
				"+2 хода всему горению на врагах.",
				[{"type": "burn_extend", "turns": 2}]))
			out.append(_card("witch_wall", "Огненный вал", 3, CardInstance.Target.ALL_ENEMIES, COLOR_WITCH,
				"7 урона всем.\nГорящие: Уязвимость и +1 ход горения.",
				[{"type": "damage", "amount": 7}, {"type": "burning_bonus", "vuln_turns": 2, "extend": 1}]))
		"warrior":
			out.append(_card("warrior_lunge", "Выпад", 1, CardInstance.Target.FRONT_ENEMY, COLOR_WARRIOR,
				"4 урона, +2 за каждый Нажим.\n+1 Нажим.",
				[{"type": "damage", "amount": 4, "per_nazhim": 2}, {"type": "nazhim", "amount": 1}]))
			out.append(_card("warrior_press", "Давление", 1, CardInstance.Target.FRONT_ENEMY, COLOR_WARRIOR,
				"+2 Нажима и Уязвимость переднему.\nКарты воина: +1 к цене в след. ход.",
				[{"type": "nazhim", "amount": 2}, {"type": "vuln", "turns": 2}, {"type": "surcharge_owner", "amount": 1}]))
			out.append(_card("warrior_chop", "Рубящий удар", 2, CardInstance.Target.FRONT_ENEMY, COLOR_WARRIOR,
				"8 урона переднему.\n+1 Нажим.",
				[{"type": "damage", "amount": 8}, {"type": "nazhim", "amount": 1}]))
			out.append(_card("warrior_release", "Сброс нажима", 3, CardInstance.Target.FRONT_ENEMY, COLOR_WARRIOR,
				"Снять весь Нажим с переднего.\nЛечит воина на 3 за стак.",
				[{"type": "nazhim_cash_heal", "per": 3}]))
		"fufu":
			out.append(_card("fufu_ram", "Таран", 1, CardInstance.Target.FRONT_ENEMY, COLOR_FUFU,
				"3 урона переднему.\nСлабость.",
				[{"type": "damage", "amount": 3}, {"type": "weak", "turns": 1}]))
			out.append(_card("fufu_poke", "Тычок", 1, CardInstance.Target.CHOSEN_ENEMY, COLOR_FUFU,
				"3 урона выбранному.\nЕсли у цели ≤50% HP: +4 щита себе.",
				[{"type": "damage", "amount": 3}, {"type": "shield_self_if_low", "amount": 4}]))
			out.append(_card("fufu_fort", "Крепость", 2, CardInstance.Target.SELF, COLOR_FUFU,
				"+10 щита себе.",
				[{"type": "shield", "to": "self", "amount": 10}]))
			out.append(_card("fufu_charge", "Рывок", 3, CardInstance.Target.FRONT_ENEMY, COLOR_FUFU,
				"6 урона переднему.\nСлабость.\n+6 щита себе.",
				[{"type": "damage", "amount": 6}, {"type": "weak", "turns": 1}, {"type": "shield", "to": "self", "amount": 6}]))
		"aki":
			out.append(_card("aki_care", "Забота", 1, CardInstance.Target.CHOSEN_ALLY, COLOR_AKI,
				"Лечит выбранного на 6.",
				[{"type": "heal", "amount": 6}]))
			out.append(_card("aki_hug", "Объятие", 2, CardInstance.Target.CHOSEN_ALLY, COLOR_AKI,
				"Лечит на 6.\nЕсли у цели ≤50% HP: ещё +6.",
				[{"type": "heal", "amount": 6, "bonus": 6}]))
			out.append(_card("aki_slap", "Липкий шлепок", 1, CardInstance.Target.CHOSEN_ENEMY, COLOR_AKI,
				"Слабость выбранному врагу.",
				[{"type": "weak", "turns": 1}]))
			out.append(_card("aki_grip", "Хватка", 2, CardInstance.Target.CHOSEN_ENEMY, COLOR_AKI,
				"Слабость и Уязвимость выбранному врагу.",
				[{"type": "weak", "turns": 1}, {"type": "vuln", "turns": 2}]))
		"luisa":
			out.append(_card("luisa_frost", "Иней", 1, CardInstance.Target.FRONT_ENEMY, COLOR_LUISA,
				"3 урона переднему.\n+1 Иней.",
				[{"type": "damage", "amount": 3}, {"type": "inei", "amount": 1}]))
			out.append(_card("luisa_chill", "Стужа", 1, CardInstance.Target.FRONT_ENEMY, COLOR_LUISA,
				"+2 Инея переднему.",
				[{"type": "inei", "amount": 2}]))
			out.append(_card("luisa_brittle", "Хрупкость", 1, CardInstance.Target.FRONT_ENEMY, COLOR_LUISA,
				"−1 Иней.\nУязвимость переднему.",
				[{"type": "inei", "amount": -1}, {"type": "vuln", "turns": 2}]))
			out.append(_card("luisa_shatter", "Раскол", 2, CardInstance.Target.FRONT_ENEMY, COLOR_LUISA,
				"3 урона за каждый Иней.\nИней сбрасывается.",
				[{"type": "damage_per_inei", "per_inei": 3}, {"type": "inei_clear"}]))
	for c in out:
		c.owner_id = hero_id
		c.owner_name = hero_name
	return out

## Ульта героя. cost — размер шкалы заряда (а не энергия хода). Играется кликом по кнопке.
## Для неизвестного id возвращается null.
static func ult_for(hero_id: String, hero_name: String) -> CardInstance:
	var c: CardInstance = null
	match hero_id:
		"witch":
			c = _card("witch_ult", "Пожар", 6, CardInstance.Target.ALL_ENEMIES, COLOR_WITCH,
				"Горение тикает по всем врагам сразу (и остаётся).\nВсе получают Уязвимость.",
				[{"type": "burn_tick_all"}, {"type": "vuln", "turns": 2}])
		"warrior":
			c = _card("warrior_ult", "Тяжёлый нажим", 4, CardInstance.Target.FRONT_ENEMY, COLOR_WARRIOR,
				"+4 Нажима переднему.\nКарты воина: +1 к цене в след. ход.",
				[{"type": "nazhim", "amount": 4}, {"type": "surcharge_owner", "amount": 1}])
		"fufu":
			c = _card("fufu_ult", "Большие тити", 5, CardInstance.Target.ALL_ENEMIES, COLOR_FUFU,
				"5 урона всем врагам, Слабость всем.\nЛечит Фуфу на 2 за каждого задетого.",
				[{"type": "damage", "amount": 5}, {"type": "weak", "turns": 1}, {"type": "heal_self_per_target", "per": 2}])
		"aki":
			c = _card("aki_ult", "Очарование", 5, CardInstance.Target.FRONT_ENEMY, COLOR_AKI,
				"Лечит переднего союзника на 10.\nОчаровывает переднего врага: он бьёт своих.",
				[{"type": "heal_front_ally", "amount": 10}, {"type": "charm", "turns": 1}])
		"luisa":
			c = _card("luisa_ult", "Ледяной раскол", 7, CardInstance.Target.FRONT_ENEMY, COLOR_LUISA,
				"Оглушает переднего.\n3 урона за каждый Иней, Иней сбрасывается.",
				[{"type": "stun", "turns": 1}, {"type": "damage_per_inei", "per_inei": 3}, {"type": "inei_clear"}])
	if c != null:
		c.owner_id = hero_id
		c.owner_name = hero_name
	return c
