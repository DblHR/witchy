extends RefCounted
class_name CardInstance
## Экземпляр карты в бою (данные, без UI).
## Эффекты описаны списком словарей и разбираются в CardBattle._run_effect().
## Каталог карт — в CardLibrary.

enum Target {
	FRONT_ENEMY,   ## передний враг, играется перетаскиванием в центр
	ALL_ENEMIES,   ## все враги, играется перетаскиванием в центр
	SELF,          ## сам владелец карты, играется перетаскиванием в центр
	CHOSEN_ENEMY,  ## враг на выбор: перетащить на него
	CHOSEN_ALLY,   ## союзник на выбор: перетащить на него
}

var id: String = ""
var title: String = ""
var description: String = ""
var cost: int = 1
var target: Target = Target.FRONT_ENEMY
var color: Color = Color(0.45, 0.45, 0.5, 1.0)
## Кто владеет картой: id героя (например "witch") или "" для общих карт.
var owner_id: String = ""
var owner_name: String = "Общая"
var effects: Array[Dictionary] = []

## Нужна ли карте «зона розыгрыша» в центре (нет выбора цели).
func uses_play_zone() -> bool:
	return target == Target.FRONT_ENEMY or target == Target.ALL_ENEMIES or target == Target.SELF
