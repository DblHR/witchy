extends Control
class_name FarmPot

signal pressed(slot_index: int)

@export var slot_index: int = 0
@export var use_catalog_pot_texture: bool = true

@onready var pot_sprite: TextureRect = $PotSprite
@onready var plant_anchor: Control = $PlantAnchor
@onready var plant_sprite: TextureRect = $PlantAnchor/PlantSprite
@onready var seed_bag_sprite: TextureRect = $SeedBagSprite
@onready var hover_glow: ColorRect = $HoverGlow
@onready var click_button: Button = $ClickButton
@onready var water_glow: ColorRect = $WaterGlow

var _hovered := false
var _water_tween: Tween
var _seed_base_modulate: Color = Color(1, 1, 1, 1)
var _plant_base_modulate: Color = Color(1, 1, 1, 1)

func _ready() -> void:
	click_button.pressed.connect(_on_pressed)
	click_button.mouse_entered.connect(_on_mouse_entered)
	click_button.mouse_exited.connect(_on_mouse_exited)
	hover_glow.visible = true
	hover_glow.modulate.a = 0.0
	water_glow.visible = true
	water_glow.modulate.a = 0.0
	_apply_catalog_assets()
	refresh()

func _apply_catalog_assets() -> void:
	if AssetCatalog_ == null:
		return
	if use_catalog_pot_texture:
		var pot_tex := AssetCatalog_.get_farm_pot_texture(slot_index)
		if pot_tex != null:
			pot_sprite.texture = pot_tex

func refresh() -> void:
	_apply_catalog_assets()
	var slot := FarmState_.get_slot(slot_index)
	var stage := int(slot.get("stage", FarmState.PlantStage.EMPTY))
	var needs_water := FarmState_.can_water_slot(slot_index)
	var seed_item_id := String(slot.get("seed_item_id", ""))
	var plant_item_id := String(slot.get("plant_item_id", ""))
	plant_sprite.visible = false
	seed_bag_sprite.visible = stage != FarmState.PlantStage.EMPTY
	seed_bag_sprite.texture = AssetCatalog_.get_farm_texture(FarmState_.get_seed_texture_key(slot)) if (AssetCatalog_ != null and seed_item_id != "") else (Inventory_.get_item_icon(seed_item_id) if seed_item_id != "" else null)
	match stage:
		FarmState.PlantStage.EMPTY:
			pass
		FarmState.PlantStage.SEED:
			pass
		FarmState.PlantStage.SPROUT:
			plant_sprite.visible = true
			plant_sprite.texture = AssetCatalog_.get_farm_texture("sprout") if AssetCatalog_ != null else null
		FarmState.PlantStage.FLOWER:
			plant_sprite.visible = true
			plant_sprite.texture = AssetCatalog_.get_farm_texture(FarmState_.get_plant_texture_key(slot)) if (AssetCatalog_ != null and plant_item_id != "") else (Inventory_.get_item_icon(plant_item_id) if plant_item_id != "" else null)

	_seed_base_modulate = Color(0.58, 0.58, 0.58, 1.0) if stage == FarmState.PlantStage.SEED and needs_water else Color(1, 1, 1, 1)
	_plant_base_modulate = Color(0.58, 0.58, 0.58, 1.0) if stage == FarmState.PlantStage.SPROUT and needs_water else Color(1, 1, 1, 1)

	var can_interact := FarmState_.can_interact(slot_index)
	click_button.disabled = not can_interact
	click_button.mouse_default_cursor_shape = Control.CURSOR_POINTING_HAND if can_interact else Control.CURSOR_ARROW
	click_button.tooltip_text = _build_tooltip(slot)
	_apply_hover_visual()

func _build_tooltip(slot: Dictionary) -> String:
	var stage := int(slot.get("stage", FarmState.PlantStage.EMPTY))
	if stage == FarmState.PlantStage.EMPTY:
		var available := FarmState_.get_available_seed_ids()
		if available.is_empty():
			return "Нет доступных семян."
		var names: Array[String] = []
		for seed_id in available:
			names.append(RunItems.get_item_name(seed_id))
		return "Выберите мешочек с семенами: %s" % ", ".join(names)
	if stage == FarmState.PlantStage.SEED:
		return "Посажено: %s\nНужно полить." % FarmState_.get_stage_label(slot)
	if stage == FarmState.PlantStage.SPROUT:
		return "Росток: %s\nНужно полить ещё раз." % FarmState_.get_stage_label(slot)
	if stage == FarmState.PlantStage.FLOWER:
		return "Созрел урожай: %s" % FarmState_.get_stage_label(slot)
	return ""

func play_water_flash() -> void:
	if _water_tween != null and _water_tween.is_valid():
		_water_tween.kill()
	water_glow.modulate = Color(0.50, 0.82, 1.0, 0.0)
	_water_tween = create_tween()
	_water_tween.tween_property(water_glow, "modulate:a", 0.62, 0.10)
	_water_tween.tween_interval(0.12)
	_water_tween.tween_property(water_glow, "modulate:a", 0.0, 0.28)
	await _water_tween.finished
	water_glow.modulate.a = 0.0
	_apply_hover_visual()

func _on_pressed() -> void:
	pressed.emit(slot_index)

func _on_mouse_entered() -> void:
	_hovered = true
	_apply_hover_visual()

func _on_mouse_exited() -> void:
	_hovered = false
	_apply_hover_visual()

func _apply_hover_visual() -> void:
	var highlight := _hovered and FarmState_.can_interact(slot_index)
	hover_glow.modulate.a = 0.95 if highlight else 0.0
	var highlight_tint := Color(1, 1, 1, 1)
	if highlight:
		highlight_tint = Color(1.15, 1.08, 0.95, 1.0)
	pot_sprite.modulate = highlight_tint
	seed_bag_sprite.modulate = Color(
		_seed_base_modulate.r * highlight_tint.r,
		_seed_base_modulate.g * highlight_tint.g,
		_seed_base_modulate.b * highlight_tint.b,
		_seed_base_modulate.a
	)
	plant_sprite.modulate = Color(
		_plant_base_modulate.r * highlight_tint.r,
		_plant_base_modulate.g * highlight_tint.g,
		_plant_base_modulate.b * highlight_tint.b,
		_plant_base_modulate.a
	)
