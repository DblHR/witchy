extends Control

const ENTRY_BUTTON_SCENE := preload("res://scenes/ui/inventory/InventoryEntryButton.tscn")

enum Section {
	ITEMS,
	RECIPES,
	LORE,
	CHARACTERS,
	GALLERY,
}

const SECTION_TITLES := {
	Section.ITEMS: "Все предметы",
	Section.RECIPES: "Рецепты алхимии",
	Section.LORE: "Лорные записи ведьмочки",
	Section.CHARACTERS: "Открытые персонажи",
	Section.GALLERY: "Галерея",
}

@onready var gold_label: Label = %GoldLabel
@onready var xp_label: Label = %XpLabel
@onready var level_label: Label = %LevelLabel
@onready var section_title_label: Label = %SectionTitleLabel
@onready var entries_scroll: ScrollContainer = %EntriesScroll
@onready var grid_container: GridContainer = %EntryGrid
@onready var detail_title_label: Label = %DetailTitleLabel
@onready var detail_hint_label: Label = %DetailHintLabel
@onready var save_button: Button = %SaveButton
@onready var back_button: TextureButton = %BackButton
@onready var alchemy_button: TextureButton = %AlchemyButton
@onready var general_button: TextureButton = %GeneralButton
@onready var lore_button: TextureButton = %LoreButton
@onready var characters_button: TextureButton = %CharactersButton
@onready var gallery_button: TextureButton = %GalleryButton
@onready var item_detail: Control = %ItemDetail
@onready var item_icon: TextureRect = %ItemIcon
@onready var item_name: Label = %ItemName
@onready var item_kind: Label = %ItemKind
@onready var item_desc: RichTextLabel = %ItemDescription
@onready var character_detail: Control = %CharacterDetail
@onready var character_sprite: TextureRect = %CharacterSprite
@onready var character_name: Label = %CharacterName
@onready var character_stats: RichTextLabel = %CharacterStats
@onready var lore_detail: Control = %LoreDetail
@onready var lore_body: RichTextLabel = %LoreBody
@onready var placeholder_detail: Control = %PlaceholderDetail
@onready var placeholder_text_label: Label = %PlaceholderText
@onready var footer_label: Label = %FooterLabel
@onready var lore_database: LoreDatabase = %LoreDatabase

var current_section: int = Section.ITEMS
var selected_entry_by_section: Dictionary = {}

func _ready() -> void:
	UIThemeHelper.apply_pink_theme(self)
	get_tree().paused = false
	_save_default_selection_ids()
	_save_button_connections()
	_subscribe_state()
	_select_section(Section.ITEMS)

func _exit_tree() -> void:
	if DungRun != null and DungRun.changed.is_connected(_refresh_header):
		DungRun.changed.disconnect(_refresh_header)
	if Inventory_ != null and Inventory_.changed.is_connected(_refresh_current_section):
		Inventory_.changed.disconnect(_refresh_current_section)
	if UnitRoster_ != null and UnitRoster_.changed.is_connected(_refresh_current_section):
		UnitRoster_.changed.disconnect(_refresh_current_section)

func _save_default_selection_ids() -> void:
	for section in [Section.ITEMS, Section.RECIPES, Section.LORE, Section.CHARACTERS, Section.GALLERY]:
		selected_entry_by_section[section] = ""

func _save_button_connections() -> void:
	save_button.pressed.connect(_on_save_pressed)
	back_button.pressed.connect(func() -> void:
		SceneRouter_.go_to_hub()
	)
	general_button.pressed.connect(func() -> void: _select_section(Section.ITEMS))
	alchemy_button.pressed.connect(func() -> void: _select_section(Section.RECIPES))
	lore_button.pressed.connect(func() -> void: _select_section(Section.LORE))
	characters_button.pressed.connect(func() -> void: _select_section(Section.CHARACTERS))
	gallery_button.pressed.connect(func() -> void: _select_section(Section.GALLERY))
	gallery_button.disabled = true
	gallery_button.tooltip_text = "Галерея будет добавлена позже."
	general_button.tooltip_text = "Все предметы на одной вкладке"
	alchemy_button.tooltip_text = "Список рецептов для алхимии"
	lore_button.tooltip_text = "Лорные записи"
	characters_button.tooltip_text = "Персонажи"
	back_button.tooltip_text = "Назад в хаб"

func _subscribe_state() -> void:
	if DungRun != null and not DungRun.changed.is_connected(_refresh_header):
		DungRun.changed.connect(_refresh_header)
	if Inventory_ != null and not Inventory_.changed.is_connected(_refresh_current_section):
		Inventory_.changed.connect(_refresh_current_section)
	if UnitRoster_ != null and not UnitRoster_.changed.is_connected(_refresh_current_section):
		UnitRoster_.changed.connect(_refresh_current_section)
	_refresh_header()

func _on_save_pressed() -> void:
	SaveManager_.save_game()
	footer_label.text = "Сохранение записано."

func _refresh_header() -> void:
	gold_label.text = "%d" % int(DungRun.gold)
	xp_label.text = "Опыт: %d / %d" % [int(DungRun.xp), int(DungRun.xp_to_next_level())]
	level_label.text = "Уровень группы: %d" % int(DungRun.party_level)

func _refresh_current_section() -> void:
	_select_section(current_section, false)

func _select_section(section: int, reset_status: bool = true) -> void:
	current_section = section
	section_title_label.text = SECTION_TITLES.get(section, "Инвентарь")
	general_button.button_pressed = section == Section.ITEMS
	alchemy_button.button_pressed = section == Section.RECIPES
	lore_button.button_pressed = section == Section.LORE
	characters_button.button_pressed = section == Section.CHARACTERS
	gallery_button.button_pressed = section == Section.GALLERY
	if reset_status:
		footer_label.text = ""
	_rebuild_entry_grid()

func _rebuild_entry_grid() -> void:
	for child in grid_container.get_children():
		child.queue_free()
	var entries := _build_entries_for_section(current_section)
	grid_container.columns = _get_columns_for_section(current_section)
	entries_scroll.scroll_vertical = 0
	if entries.is_empty():
		_show_empty_detail_for_section()
		return
	var selected_id := String(selected_entry_by_section.get(current_section, ""))
	if selected_id == "" or not _entries_have_id(entries, selected_id):
		selected_id = String(entries[0].get("id", ""))
		selected_entry_by_section[current_section] = selected_id
	for entry in entries:
		var button: InventoryEntryButton = ENTRY_BUTTON_SCENE.instantiate()
		entry["selected"] = String(entry.get("id", "")) == selected_id
		grid_container.add_child(button)
		button.setup(entry)
		button.entry_pressed.connect(_on_entry_pressed)
	_show_entry_detail(selected_id)

func _entries_have_id(entries: Array[Dictionary], entry_id: String) -> bool:
	for entry in entries:
		if String(entry.get("id", "")) == entry_id:
			return true
	return false

func _on_entry_pressed(entry_id: String) -> void:
	selected_entry_by_section[current_section] = entry_id
	_rebuild_entry_grid()

func _build_entries_for_section(section: int) -> Array[Dictionary]:
	match section:
		Section.ITEMS:
			return _build_item_entries()
		Section.RECIPES:
			return _build_recipe_entries()
		Section.LORE:
			return _build_lore_entries()
		Section.CHARACTERS:
			return _build_character_entries()
		Section.GALLERY:
			return []
	return []

func _build_item_entries() -> Array[Dictionary]:
	var out: Array[Dictionary] = []
	if Inventory_ == null:
		return out
	for entry in Inventory_.get_sorted_item_entries():
		out.append({
			"id": String(entry.get("id", "")),
			"title": String(entry.get("name", "")),
			"subtitle": RunItems.get_item_kind_label(String(entry.get("id", ""))),
			"count": int(entry.get("count", 0)),
			"icon": entry.get("icon", null),
			"compact": true,
		})
	return out

func _build_recipe_entries() -> Array[Dictionary]:
	var out: Array[Dictionary] = []
	for recipe_id in AlchemyDB.get_recipe_ids():
		var result_item_id := AlchemyDB.get_result_item_id(recipe_id)
		out.append({
			"id": recipe_id,
			"title": AlchemyDB.get_recipe_name(recipe_id),
			"subtitle": RunItems.get_item_name(result_item_id),
			"count": -1,
			"icon": Inventory_.get_item_icon(result_item_id) if Inventory_ != null else null,
			"compact": true,
		})
	return out

func _build_lore_entries() -> Array[Dictionary]:
	var out: Array[Dictionary] = []
	if lore_database == null:
		return out
	for entry: LoreEntryData in lore_database.get_entries():
		if entry == null:
			continue
		out.append({
			"id": entry.id,
			"title": entry.title,
			"subtitle": _excerpt(entry.body),
			"icon": entry.icon,
			"count": -1,
			"compact": false,
		})
	return out

func _build_character_entries() -> Array[Dictionary]:
	var out: Array[Dictionary] = []
	if UnitRoster_ == null or CharDB == null:
		return out
	for unit_id in UnitRoster_.get_unlocked_unit_ids():
		var data: CharacterData = CharDB.get_by_id(unit_id)
		if data == null:
			continue
		out.append({
			"id": unit_id,
			"title": data.display_name,
			"subtitle": "",
			"icon": _get_character_avatar(data),
			"count": -1,
			"compact": true,
		})
	return out

func _get_columns_for_section(section: int) -> int:
	match section:
		Section.LORE:
			return 1
		Section.CHARACTERS:
			return 4
		_:
			return 4

func _show_entry_detail(entry_id: String) -> void:
	_match_detail_visibility(false, false, false, false)
	match current_section:
		Section.ITEMS:
			_show_item_detail(entry_id)
		Section.RECIPES:
			_show_recipe_detail(entry_id)
		Section.LORE:
			_show_lore_detail(entry_id)
		Section.CHARACTERS:
			_show_character_detail(entry_id)
		Section.GALLERY:
			_show_gallery_placeholder()

func _show_empty_detail_for_section() -> void:
	_match_detail_visibility(false, false, false, true)
	detail_title_label.text = SECTION_TITLES.get(current_section, "Инвентарь")
	detail_hint_label.text = ""
	var placeholder_text := "Пока здесь пусто."
	if current_section == Section.GALLERY:
		placeholder_text = "Галерея пока не подключена."
	elif current_section == Section.CHARACTERS:
		placeholder_text = "Персонажи ещё не открыты."
	placeholder_text_label.text = placeholder_text

func _show_item_detail(item_id: String) -> void:
	_match_detail_visibility(true, false, false, false)
	detail_title_label.text = "Карточка предмета"
	detail_hint_label.text = "На этой вкладке лежат все типы предметов: посохи, еда, зелья, ингредиенты и семена."
	item_icon.texture = Inventory_.get_item_icon(item_id)
	item_name.text = RunItems.get_item_name(item_id)
	var rarity := RunItems.get_item_rarity_label(item_id)
	item_kind.text = RunItems.get_item_kind_label(item_id) if rarity == "" else "%s • %s" % [RunItems.get_item_kind_label(item_id), rarity]
	item_desc.text = "%s\n\nКоличество: %d" % [RunItems.get_item_desc(item_id), Inventory_.get_item_count(item_id)]

func _show_recipe_detail(recipe_id: String) -> void:
	_match_detail_visibility(true, false, false, false)
	detail_title_label.text = "Карточка рецепта"
	detail_hint_label.text = "Вкладка рецептов показывает требования и позволяет быстро сверить наличие ингредиентов."
	var result_item_id := AlchemyDB.get_result_item_id(recipe_id)
	item_icon.texture = Inventory_.get_item_icon(result_item_id)
	item_name.text = AlchemyDB.get_recipe_name(recipe_id)
	item_kind.text = "Рецепт → %s" % RunItems.get_item_name(result_item_id)
	var ingredient_lines: Array[String] = []
	for ingredient_id in AlchemyDB.get_ingredients(recipe_id).keys():
		var need := int(AlchemyDB.get_ingredients(recipe_id)[ingredient_id])
		var have := Inventory_.get_item_count(String(ingredient_id)) if Inventory_ != null else 0
		ingredient_lines.append("• %s: %d / %d" % [RunItems.get_item_name(String(ingredient_id)), have, need])
	ingredient_lines.sort()
	item_desc.text = "%s\n\nИнгредиенты:\n%s\n\nМожно создать сейчас: %s" % [
		RunItems.get_item_desc(result_item_id),
		"\n".join(ingredient_lines),
		("да" if AlchemyDB.can_craft(recipe_id) else "нет"),
	]

func _show_lore_detail(entry_id: String) -> void:
	if lore_database == null:
		return
	_match_detail_visibility(false, false, true, false)
	detail_title_label.text = "Лорные записи ведьмочки"
	detail_hint_label.text = "Позже сюда можно добавить выделения, картинки и пометки."
	for entry: LoreEntryData in lore_database.get_entries():
		if entry != null and entry.id == entry_id:
			lore_body.text = "[center][b]%s[/b][/center]\n\n%s" % [entry.title, entry.body]
			return
	lore_body.text = "пока здесь пусто"

func _show_character_detail(unit_id: String) -> void:
	_match_detail_visibility(false, true, false, false)
	detail_title_label.text = "Карточка персонажа"
	detail_hint_label.text = "Слева — открытые персонажи, справа — подробности по выбранному."
	var data: CharacterData = CharDB.get_by_id(unit_id)
	if data == null:
		_show_empty_detail_for_section()
		return
	var stats := data.stats_for_level(max(1, int(DungRun.party_level)))
	character_sprite.texture = data.battle_texture if data.battle_texture != null else _get_character_avatar(data)
	character_name.text = data.display_name
	var desc := data.codex_description.strip_edges()
	if desc == "":
		desc = _build_default_character_description(data)
	var notes := data.codex_notes.strip_edges()
	if notes == "":
		notes = "Позже здесь можно добавить личное описание персонажа, реплики и интересные факты."
	character_stats.text = "[b]Класс:[/b] %s\n[b]HP:[/b] %d\n[b]Урон:[/b] %d\n[b]APS:[/b] %.2f\n[b]Энергия:[/b] %d\n\n[b]Описание:[/b]\n%s\n\n[b]Способности:[/b]\n• %s\n• %s\n\n[b]Заметки:[/b]\n%s" % [
		data.unit_class,
		int(stats.get("max_hp", data.base_hp)),
		int(stats.get("damage", data.base_damage)),
		float(stats.get("aps", data.base_aps)),
		data.max_energy,
		desc,
		_get_ability_name(data.skill_ability, data.skill_name),
		_get_ability_name(data.ult_ability, "Ульта"),
		notes,
	]

func _show_gallery_placeholder() -> void:
	_show_empty_detail_for_section()

func _match_detail_visibility(show_item: bool, show_character: bool, show_lore: bool, show_placeholder: bool) -> void:
	item_detail.visible = show_item
	character_detail.visible = show_character
	lore_detail.visible = show_lore
	placeholder_detail.visible = show_placeholder

func _excerpt(text: String, max_len: int = 80) -> String:
	var clean := text.replace("\n", " ").strip_edges()
	if clean.length() <= max_len:
		return clean
	return clean.substr(0, max_len - 1) + "…"

func _get_character_avatar(data: CharacterData) -> Texture2D:
	if data.card_portrait != null:
		return data.card_portrait
	if data.icon != null:
		return data.icon
	return data.battle_texture

func _build_default_character_description(data: CharacterData) -> String:
	return "%s — %s. Базовое описание пока не заполнено, но раздел уже готов для ручной доработки через ресурсы персонажей." % [data.display_name, data.unit_class]

func _get_ability_name(ability: Ability, fallback_name: String) -> String:
	if ability != null and ability.name.strip_edges() != "":
		return ability.name
	return fallback_name
