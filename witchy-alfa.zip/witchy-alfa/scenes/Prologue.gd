extends Control

const PROLOGUE_DIR := "res://assets/pics/bigPics/prologue"
const SCENE_COUNT := 12

@onready var image_rect: TextureRect = %ImageRect
@onready var hint_label: Label = %HintLabel
@onready var fallback_label: Label = %FallbackLabel

var _textures: Array[Texture2D] = []
var _index: int = 0

func _ready() -> void:
	UIThemeHelper.apply_pink_theme(self)
	mouse_filter = Control.MOUSE_FILTER_STOP
	_load_textures()
	_show_current()

func _gui_input(event: InputEvent) -> void:
	if event is InputEventMouseButton and event.pressed and event.button_index == MOUSE_BUTTON_LEFT:
		_advance()
		accept_event()
	elif event is InputEventScreenTouch and event.pressed:
		_advance()
		accept_event()

func _load_textures() -> void:
	_textures.clear()
	for i in range(1, SCENE_COUNT + 1):
		var path := "%s/scene%d.png" % [PROLOGUE_DIR, i]
		if ResourceLoader.exists(path):
			var tex := load(path) as Texture2D
			if tex != null:
				_textures.append(tex)

func _show_current() -> void:
	var has_images := not _textures.is_empty()
	image_rect.visible = has_images
	fallback_label.visible = not has_images
	hint_label.text = "Нажмите в любом месте" if (_index < max(_textures.size(), 1) - 1) else "Нажмите в любом месте, чтобы начать обучение"
	if has_images:
		image_rect.texture = _textures[_index]
	else:
		fallback_label.text = """Пролог подготовлен, но изображения не найдены по пути:
%s

Как только scene1.png ... scene12.png появятся в проекте, экран начнёт показывать их автоматически.""" % PROLOGUE_DIR

func _advance() -> void:
	var max_count = max(_textures.size(), 1)
	_index += 1
	if _index >= max_count:
		if StoryState_ != null:
			StoryState_.intro_played = true
			StoryState_.tutorial_battle_pending = true
			StoryState_.changed.emit()
		SceneRouter_.go_to_tutorial_battle()
		return
	_show_current()
